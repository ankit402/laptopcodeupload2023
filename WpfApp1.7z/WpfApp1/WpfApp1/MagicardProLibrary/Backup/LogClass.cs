﻿// Decompiled with JetBrains decompiler
// Type: MagicardProLibrary.LogClass
// Assembly: MagicardProLibrary, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 42330D39-DB7D-4E8E-8BCF-74ADB991FF4A
// Assembly location: D:\Shared Folder\Magicard tool\MagicardProLibrary.dll

using Microsoft.Win32;
using System;
using System.Diagnostics;
using System.IO;
using System.Net.NetworkInformation;
using System.Security.Principal;

namespace MagicardProLibrary
{
  internal class LogClass
  {
    public string file_path = "C:\\Program Files\\OMA Emirates\\NanoPerso\\Logs";
    private byte[] pSerial = new byte[8];
    private StreamWriter log;
    private DAL objPrinterDAL;

    public void LogFile(string msg, int isDBtrue = 0)
    {
      this.writeLog(this.file_path + "\\" + "RioPro" + "-" + DateTime.Now.ToString("ddMMyyyy") + ".log", string.Format(new StackTrace().GetFrame(1).GetMethod().Name), msg, isDBtrue);
    }

    public void writeLog(string logfile, string mtd_name, string message, int isDBTrue)
    {
      this.objPrinterDAL = new DAL();
      try
      {
        if (!Directory.Exists(this.file_path))
          Directory.CreateDirectory(this.file_path);
        this.log = File.Exists(logfile) ? File.AppendText(logfile) : File.CreateText(logfile);
        if (isDBTrue == 1)
          this.objPrinterDAL.InsertLogRecord(DateTime.Now, this.getBranchID("BRANCH"), this.getBranchID("BRANCHNAME"), this.getmacAddress(), "0", mtd_name, message);
        this.log.WriteLine(DateTime.Now.ToString() + "\t||" + this.getmacAddress() + "\t||" + this.getBranchID("BRANCH") + "\t||" + mtd_name + "\t||" + message);
        this.log.Close();
      }
      catch (Exception ex)
      {
        this.log.WriteLine(DateTime.Now.ToString() + "\t||" + mtd_name + "\t|| Exception Occured in Log Writing: " + ex.Message);
        this.log.Close();
      }
    }

    public string getmacAddress()
    {
      NetworkInterface.GetAllNetworkInterfaces()[0].GetPhysicalAddress();
      return WindowsIdentity.GetCurrent().Name;
    }

    private string getBranchID(string value)
    {
      RegistryKey registryKey = Registry.LocalMachine.OpenSubKey("SOFTWARE\\NanoCritiX\\");
      string str1 = string.Empty;
      if (value == "BRANCH")
      {
        string str2 = registryKey.GetValue("BRANCH").ToString();
        if (str2 == "" || str2 == null)
          str2 = registryKey.GetValue("BRANCHID").ToString();
        str1 = str2;
      }
      if (value == "BRANCHNAME")
        str1 = registryKey.GetValue("BRANCHNAME").ToString();
      if (value == "STATIONID")
        str1 = registryKey.GetValue("STATIONID").ToString();
      return str1;
    }
  }
}
