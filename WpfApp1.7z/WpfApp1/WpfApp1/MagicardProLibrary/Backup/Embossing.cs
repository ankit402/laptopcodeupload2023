﻿// Decompiled with JetBrains decompiler
// Type: MagicardProLibrary.Embossing
// Assembly: MagicardProLibrary, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 42330D39-DB7D-4E8E-8BCF-74ADB991FF4A
// Assembly location: D:\Shared Folder\Magicard tool\MagicardProLibrary.dll

using NCX.GenericLibrary;
using System;
using System.Data;
using System.IO;
using System.Threading;

namespace MagicardProLibrary
{
  public class Embossing : iEmbossing
  {
    private bool bPrinterConnected = true;
    private LogClass Log = new LogClass();
    private LogClass log = new LogClass();
    private int hSession_val = 0;
    private IntPtr hSession = IntPtr.Zero;
    private RioPro objPrinter;
    private DAL objPrinterDAL;
    private CustomTraceListener objCustomTracetLogging;

    public bool Connect()
    {
      if (this.objPrinter == null)
        this.objPrinter = new RioPro();
      return this.objPrinter.connect();
    }

    public int connect_ptr()
    {
      if (this.objPrinter == null)
        this.objPrinter = new RioPro();
      return this.objPrinter.connect_ptr();
    }

    public bool Reset()
    {
      if (this.objPrinter == null)
        this.objPrinter = new RioPro();
      return this.objPrinter.Reset();
    }

    public bool Reset(string profileID)
    {
      if (this.objPrinter == null)
        this.objPrinter = new RioPro();
      return this.objPrinter.Reset();
    }

    public bool EjectCard()
    {
      if (this.objPrinter == null)
        this.objPrinter = new RioPro();
      return this.objPrinter.EjectCard();
    }

    public bool Status()
    {
      if (this.objPrinter == null)
        this.objPrinter = new RioPro();
      return this.objPrinter.Status();
    }

    public bool FeedCard()
    {
      if (this.objPrinter == null)
        this.objPrinter = new RioPro();
      return this.objPrinter.Feed_Card();
    }

    public string PrintCards(string BranchID, string ProfileID, int PrintID)
    {
      string sMsg = string.Empty;
      if (!this.Status())
        this.connect_ptr();
      this.Log.LogFile("Print Cards Called for Branch[" + BranchID + "] Print ID [" + (object) PrintID + "] and ProfileID[" + ProfileID + "]", 0);
      this.objPrinterDAL = new DAL();
      try
      {
        this.Log.LogFile("Calling GetPrintingProfileDetails for ProfileID[" + ProfileID + "]", 0);
        DataSet printingProfileDetails = this.objPrinterDAL.GetPrintingProfileDetails(ProfileID);
        this.Log.LogFile("Calling GetPrintingRecords for Branch[" + BranchID + "] and Profile ID[" + ProfileID + "] Print ID [" + (object) PrintID + "]", 0);
        DataSet printingRecords = this.objPrinterDAL.GetPrintingRecords(BranchID, ProfileID, PrintID);
        DataSet dataSet = new DataSet();
        DataSet dsMagData = new DataSet();
        bool bEnableChip = (bool) printingProfileDetails.Tables[0].Rows[0]["Chip"];
        bool bEnableMagstripe = (bool) printingProfileDetails.Tables[0].Rows[0]["Mag"];
        bool bEnablePrinting = (bool) printingProfileDetails.Tables[0].Rows[0]["Print"];
        bool ChipStatus = false;
        bool MagDone = false;
        bool PrintDone = false;
        int num1 = 0;
        int num2 = 0;
        bool flag1 = false;
        if (bEnableChip)
          num2 = (int) printingProfileDetails.Tables[0].Rows[0]["ChipWait"];
        this.objPrinter = new RioPro(bEnableChip, bEnableMagstripe, bEnablePrinting);
        if (!this.objPrinter.connect())
        {
          this.Log.LogFile("Printer Not Connected", 0);
          if (this.objPrinterDAL.ReadErrorMsg("Printer Not Connected") == "")
            return "Printer Not Connected";
          return this.objPrinterDAL.ReadErrorMsg("Printer Not Connected");
        }
        if (!this.objPrinter.connect())
          return "Error: Printer Not Connected";
        if (!this.objPrinter.Feed_Card())
        {
          this.Log.LogFile("Feedcard Failed", 0);
          return this.objPrinterDAL.ReadErrorMsg("Feedcard Failed");
        }
        if (this.objPrinter.Feed_Card())
        {
          this.Log.LogFile("Total Lines to be Printed [" + (object) printingRecords.Tables[0].Rows.Count + "]", 0);
          if (printingRecords.Tables[0].Rows.Count > 0)
          {
            foreach (DataRow row in (InternalDataCollectionBase) printingRecords.Tables[0].Rows)
            {
              bool flag2 = false;
              DataSet printingRecordData = this.objPrinterDAL.GetPrintingRecordData(row[nameof (ProfileID)].ToString(), row[nameof (PrintID)].ToString());
              this.Log.LogFile("ProfileID : " + row[nameof (PrintID)].ToString() + "PrintID : " + row[nameof (ProfileID)].ToString(), 0);
              if (bEnableMagstripe)
                dsMagData = this.objPrinterDAL.GetEncodingRecordData(row[nameof (ProfileID)].ToString(), row[nameof (PrintID)].ToString());
              int num3 = 0;
              if (bEnableChip)
              {
                num3 = this.objPrinter.PersonalizeChip(printingRecordData, ref sMsg);
                this.Log.LogFile("Reply from PersonalizeChip[" + (object) num3 + "] and sMsg[" + sMsg + "]", 0);
                if (num3 == -123)
                {
                  this.Log.LogFile("No Card Inside the printer.Please insert the card", 0);
                  if (this.objPrinterDAL.ReadErrorMsg("No Card in the Feeder") == "")
                    return sMsg;
                  return this.objPrinterDAL.ReadErrorMsg("No Card in the Feeder");
                }
                while (num2 >= num1)
                {
                  if (this.objPrinterDAL.ReadChipStatus(row[nameof (PrintID)].ToString()) == "0")
                  {
                    flag2 = true;
                    ChipStatus = true;
                    break;
                  }
                  num1 += 1000;
                  this.Log.LogFile("Going to sleep for 1 Sec", 0);
                  Thread.Sleep(1000);
                }
                this.Log.LogFile("Check For Chip : " + num1.ToString() + " and Chip Status : " + this.objPrinterDAL.ReadChipStatus(row[nameof (PrintID)].ToString()), 0);
                if (this.objPrinterDAL.ReadChipStatus(row[nameof (PrintID)].ToString()) == "0" && !ChipStatus)
                {
                  flag1 = true;
                  break;
                }
                this.Log.LogFile("Exit from While Loop", 0);
                if (!flag2)
                {
                  this.objPrinter.EjectCard();
                  this.Log.LogFile("PrintID[" + row[nameof (PrintID)].ToString() + "] CycleCount[" + num1.ToString() + "]", 0);
                  if (num3 == 0)
                    num3 = 153;
                }
              }
              else
                num3 = 0;
              if (num3 == 0)
              {
                this.Log.LogFile("Print Card called with Encoding Data[" + (object) dsMagData.Tables[0].Rows.Count + "] Printing Data[" + (object) printingRecordData.Tables[0].Rows.Count + "]", 0);
                num3 = this.objPrinter.PrintCard(printingRecordData, dsMagData, ref sMsg, ref MagDone, ref PrintDone);
                this.Log.LogFile("Print Card Reply[" + (object) num3 + "]", 0);
              }
              else
              {
                DateTime dateTime = DateTime.Today;
                dateTime = dateTime.Date;
                if (File.Exists("C:\\Program Files\\OMA Emirates\\NanoPerso\\Smart Factory\\" + dateTime.ToString("ddMM") + "\\SmartFactoryLastError.Log"))
                {
                  dateTime = DateTime.Today;
                  dateTime = dateTime.Date;
                  string str = dateTime.ToString("ddMM");
                  foreach (string readAllLine in File.ReadAllLines("C:\\Program Files\\OMA Emirates\\NanoPerso\\Smart Factory\\" + str + "\\SmartFactoryLastError.Log"))
                  {
                    if (readAllLine.StartsWith("Message : "))
                      sMsg = "Printing failed : " + readAllLine.Replace("Message : ", "Chip personalization failed, ") + "\n";
                    else if (readAllLine.StartsWith("Detail : "))
                      sMsg = sMsg + readAllLine.Replace("Detail : ", "") + "\n";
                    else if (readAllLine.StartsWith("Recommendation : "))
                      sMsg = sMsg + readAllLine.Replace("Recommendation : ", "") + "\n";
                  }
                }
                else
                  sMsg = "Chip personalization Failed\nTimeOut occurred during personalization.\nPlease Contact with OMA S/W Support or Check Smart factory Log";
              }
              if (num3 == 0)
              {
                this.Log.LogFile("Print ID[" + row[nameof (PrintID)].ToString() + "] Bool Reply[" + num3.ToString() + "] sMsg[" + sMsg + "] Chip[" + ChipStatus.ToString() + "] Mag[" + MagDone.ToString() + "] Print[" + PrintDone.ToString() + "]", 0);
                this.objPrinterDAL.UpdatePrintRecord(row[nameof (PrintID)].ToString(), num3.ToString(), sMsg, ChipStatus, MagDone, PrintDone);
                this.Log.LogFile("Print record Updated", 0);
                if (!this.objPrinter.EjectCard())
                {
                  this.objPrinter.Reset();
                  this.Log.LogFile("Card Not Ejected Successfully", 0);
                  this.Log.LogFile("***********************************Printed Successfully but Failed to Eject***********************************", 0);
                }
                else
                {
                  this.Log.LogFile("Calling Eject Method", 0);
                  this.Log.LogFile("Card Ejected Successfully", 0);
                  this.Log.LogFile("***********************************Printed Successfully***********************************", 0);
                }
              }
              else
              {
                this.Log.LogFile("Printing failed:" + sMsg, 0);
                this.Log.LogFile("***********************************Printing Failed***********************************", 0);
                this.objPrinter.EjectCard();
                if (this.objPrinterDAL.ReadErrorMsg(sMsg) == "")
                  return sMsg;
                return this.objPrinterDAL.ReadErrorMsg(sMsg);
              }
            }
          }
          else
          {
            sMsg = "Error: No Records found for Printing.\n\nPlease Check the Records and try to print again.";
            this.Log.LogFile(sMsg, 0);
            return sMsg;
          }
        }
        this.Log.LogFile("Printing Success", 0);
        return "Printing Success";
      }
      catch (Exception ex)
      {
        this.Log.LogFile("Message: " + sMsg + "- Exception: " + ex.ToString(), 0);
        return sMsg;
      }
    }
  }
}
