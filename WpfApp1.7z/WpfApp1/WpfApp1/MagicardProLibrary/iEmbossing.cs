﻿// Decompiled with JetBrains decompiler
// Type: MagicardProLibrary.iEmbossing
// Assembly: MagicardProLibrary, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 42330D39-DB7D-4E8E-8BCF-74ADB991FF4A
// Assembly location: D:\Shared Folder\Magicard tool\MagicardProLibrary.dll

namespace MagicardProLibrary
{
  internal interface iEmbossing
  {
    bool Connect();

    int connect_ptr();

    bool Reset();

    string PrintCards(string BranchID, string ProfileID, int PrintId);
  }
}
