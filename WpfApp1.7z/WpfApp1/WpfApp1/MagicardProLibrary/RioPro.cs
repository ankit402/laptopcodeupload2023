﻿// Decompiled with JetBrains decompiler
// Type: MagicardProLibrary.RioPro
// Assembly: MagicardProLibrary, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 42330D39-DB7D-4E8E-8BCF-74ADB991FF4A
// Assembly location: D:\Shared Folder\Magicard tool\MagicardProLibrary.dll
using SDKShim;
using System;
using System.Collections.Generic;
using System.Data;
using System.Diagnostics;
using System.Drawing;
using System.Drawing.Printing;
using System.IO;
using System.Threading;
using System.Windows.Forms;

namespace MagicardProLibrary
{
  public class RioPro
  {
    private static IntPtr hSession = IntPtr.Zero;
    private static IntPtr hDC = IntPtr.Zero;
    private static PrinterSettings ps = new PrinterSettings();
    private static PrintDialog pd = new PrintDialog();
    private bool bChip = false;
    private bool bMag = false;
    private bool bPrint = false;
    private LogClass Log = new LogClass();
    private DAL objPrinterDAL = new DAL();
    private SDK.MagData MagData = new SDK.MagData();
    private int rc = 0;
    private string path = System.IO.Path.GetDirectoryName(System.Reflection.Assembly.GetEntryAssembly().Location) + @"\RioProError.txt";
    private static Graphics g;
    private string Connection_Mode;
    private string Printer_IP;

    public RioPro()
    {
      try
      {
        //objCustomTracetLogging = new CustomTraceListener("Log.Logfiles\\RioPro-" + DateTime.Now.ToString("yyyyMMdd") + ".log");
        //objReadConfig = new ReadConfig();
        //if (objReadConfig.ReturnValue("PRINTER_CONNECTION_MODE", false) != null)
        //{
        //  Connection_Mode = objReadConfig.ReturnValue("PRINTER_CONNECTION_MODE", true);
        //  if (Connection_Mode != "USB")
        //    Printer_IP = objReadConfig.ReturnValue("PRINTER_IP", false);
        //  else
        //    Log.LogFile("Printer Connected Mode " + Connection_Mode, 0);
       // }
        Log.LogFile("RioPro Object created ...", 0);
      }
      catch (Exception ex)
      {
        Log.LogFile("Exception on creating Rio Pro Object. Exception: " + ex.ToString() + ex.StackTrace, 1);
      }
    }

    public RioPro(bool bEnableChip, bool bEnableMagstripe, bool bEnablePrinting)
    {
      try
      {
        //objReadConfig = new ReadConfig();
        //if (objReadConfig.ReturnValue("PRINTER_CONNECTION_MODE", false) != null)
        //{
        //  Connection_Mode = objReadConfig.ReturnValue("PRINTER_CONNECTION_MODE", true);
        //  if (Connection_Mode != "USB")
        //  {
        //    Printer_IP = objReadConfig.ReturnValue("PRINTER_IP", false);
        //    Log.LogFile("PrinterIP" + Printer_IP, 0);
        //  }
        //  else
        //    Log.LogFile("Printer Connected Mode " + Connection_Mode, 0);
        //}
        //bChip = bEnableChip;
        //bMag = bEnableMagstripe;
        //bPrint = bEnablePrinting;
        //Log.LogFile("Chip[" + bChip.ToString() + "]  Magstripe[" + bMag.ToString() + "]  Print[" + bPrint.ToString() + "]", 0);
        //Log.LogFile("RioPro Object created ...", 0);
      }
      catch (Exception ex)
      {
        //objCustomTracetLogging.WriteLine("Exception: " + ex.ToString() + ex.StackTrace);
      }
    }

    public bool connect()
    {
      int num1 = 0;
      RioPro.ps = RioPro.pd.PrinterSettings;
      RioPro.g = RioPro.ps.CreateMeasurementGraphics();
      RioPro.hDC = RioPro.g.GetHdc();
      SDK.Config key = new KeyValuePair<SDK.Config, string>(SDK.Config.Normal, "Normal").Key;
      SDK.Return return1 = SDK.ID_OpenSession(RioPro.hDC, out RioPro.hSession, key);
      num1 = (int) RioPro.hSession;
      if ((uint) return1 > 0U)
      {
        int num2 = (int) SDK.ID_CloseSession(RioPro.hSession);
        connect();
      }
      else if (SDK.ID_PrinterType(RioPro.hSession) != SDK.PrinterType.Enduro)
      {
        int num2 = (int) MessageBox.Show("Use with DTC Only", "Invalid Printer", MessageBoxButtons.OK);
        int num3 = (int) SDK.ID_CloseSession(RioPro.hSession);
        Log.LogFile("Prnter session close", 0);
      }
      else
      {
        Cursor.Current = Cursors.WaitCursor;
        if (PrinterIsReady() && SDK.ID_PrinterType(RioPro.hSession) == SDK.PrinterType.Enduro)
        {
          SDK.PrinterInfo prninfo = new SDK.PrinterInfo();
          SDK.Return return2 = SDK.ID_PrinterInfo(RioPro.hSession, prninfo);
          if ((uint) return2 > 0U)
          {
            int num2 = (int) SDK.ID_CloseSession(RioPro.hSession);
            Log.LogFile("Printer Session closed try to initialization", 0);
            GetPrinterConnectiontype();
            Log.LogFile("Getprtinterconnectiontype", 0);
            return false;
          }
          Log.LogFile("Open - GetPrinterInfo [" + (object) return2 + "]", 0);
          GetPrinterConnectiontype();
          Log.LogFile("PrinterConnected : [" + prninfo.bPrinterConnected.ToString() + "]Model No. [" + (object) prninfo.eModel + "] Model: [" + prninfo.sModel + "] PrinterSerial: [" + prninfo.sPrinterSerial + "] PrintheadSerial: [" + prninfo.sPrintheadSerial + "] PCBSerial: [" + prninfo.sPCBSerial + "] FirmwareVersion: [" + prninfo.Firmware.Version + "]", 0);
        }
      }
      return true;
    }

    public int connect_ptr()
    {
      RioPro.hSession = IntPtr.Zero;
      RioPro.ps = RioPro.pd.PrinterSettings;
      RioPro.g = RioPro.ps.CreateMeasurementGraphics();
      RioPro.hDC = RioPro.g.GetHdc();
      SDK.Config key = new KeyValuePair<SDK.Config, string>(SDK.Config.Normal, "Normal").Key;
      SDK.Return return1 = SDK.ID_OpenSession(RioPro.hDC, out RioPro.hSession, key);
      int hSession = (int) RioPro.hSession;
      if ((uint) return1 > 0U)
      {
        int num = (int) SDK.ID_CloseSession(RioPro.hSession);
        connect_ptr();
        Log.LogFile("OpenSession" + (object) return1, 0);
      }
      else if (SDK.ID_PrinterType(RioPro.hSession) != SDK.PrinterType.Enduro)
      {
        int num1 = (int) MessageBox.Show("Use with DTC Only", "Invalid Printer", MessageBoxButtons.OK);
        int num2 = (int) SDK.ID_CloseSession(RioPro.hSession);
      }
      else
      {
        Cursor.Current = Cursors.WaitCursor;
        if (PrinterIsReady() && SDK.ID_PrinterType(RioPro.hSession) == SDK.PrinterType.Enduro)
        {
          SDK.PrinterInfo prninfo = new SDK.PrinterInfo();
          SDK.Return return2 = SDK.ID_PrinterInfo(RioPro.hSession, prninfo);
          if ((uint) return2 > 0U)
          {
            Log.LogFile("Open - GetPrinterInfo [" + (object) return2 + "]", 0);
            Log.LogFile("PrinterConnected : [" + prninfo.bPrinterConnected.ToString() + "]Model No. [" + (object) prninfo.eModel + "] Model: [" + prninfo.sModel + "] PrinterSerial: [" + prninfo.sPrinterSerial + "] PrintheadSerial: [" + prninfo.sPrintheadSerial + "] PCBSerial: [" + prninfo.sPCBSerial + "] FirmwareVersion: [" + prninfo.Firmware.Version + "]", 0);
          }
          else
          {
            Log.LogFile("[Open - GetPrinterInfo]" + (object) return2, 0);
            Log.LogFile("PrinterConnected : [" + prninfo.bPrinterConnected.ToString() + "]Model No. [" + (object) prninfo.eModel + "] Model: [" + prninfo.sModel + "] PrinterSerial: [" + prninfo.sPrinterSerial + "] PrintheadSerial: [" + prninfo.sPrintheadSerial + "] PCBSerial: [" + prninfo.sPCBSerial + "] FirmwareVersion: [" + prninfo.Firmware.Version + "]", 0);
          }
        }
      }
      if ((uint) hSession > 0U)
        return hSession;
      return 0;
    }

    private bool PrinterIsReady()
    {
      return SDK.ID_PrinterStatus(RioPro.hSession) == SDK.PrinterStatus.Ready;
    }

    public bool Reset()
    {
      bool flag1 = connect();
      if (flag1)
      {
        bool flag2 = Status();
        if (flag2)
        {
          SDK.ID_RestartPrinter(RioPro.hSession);
          WaitForPrinterToFinish();
          Log.LogFile("Printer Reset Successfully", 0);
          return flag2;
        }
        if (ClearResponse())
        {
          Log.LogFile("Printer Reset Sucess", 0);
          return flag2;
        }
        Log.LogFile("Printer Reset Failed", 0);
        return flag2;
      }
      Log.LogFile("Printer connection not found", 0);
      RioPro.hSession = IntPtr.Zero;
      return flag1;
    }

    public bool ClearResponse()
    {
      SDK.Return result = SDK.ID_CleanPrinter(RioPro.hSession);
      if ((uint) result > 0U)
      {
        HandleError("CleanPrinter", result);
        return false;
      }
      WaitForPrinterToFinish();
      return true;
    }

    public bool EjectCard()
    {
      SDK.Return @return = SDK.ID_EjectCard(RioPro.hSession);
      if ((uint) @return > 0U)
      {
        Log.LogFile("Card Ejected failed [" + (object) @return + "]", 0);
        return false;
      }
      WaitForPrinterToFinish();
      if (!Status())
        return false;
      Log.LogFile("Card Eject Success", 0);
      return true;
    }

    public bool Status()
    {
      string str;
      switch (SDK.ID_PrinterStatus(RioPro.hSession))
      {
        case SDK.PrinterStatus.Ready:
          str = "Printer is READY";
          break;
        case SDK.PrinterStatus.Busy:
          str = "Printer is in Busy";
          break;
        case SDK.PrinterStatus.Error:
          str = "Printer is in ERROR";
          break;
        case SDK.PrinterStatus.Offline:
          str = "Printer is OFFLINE";
          break;
        default:
          str = "Unknown Printer Status";
          break;
      }
      return str == "Printer is READY";
    }

    public int PersonalizeChip(DataSet dsPrintingData, ref string sMsg)
    {
      sMsg = string.Empty;
      int index = 0;
      Log.LogFile("Moving card to Chip Module...", 0);
      if (bChip)
      {
        Log.LogFile("Preparing Chip Data ...", 0);
        Log.LogFile("Personalizing Chip...", 0);
        string empty = string.Empty;
        int millisecondsTimeout = 0;
        for (; dsPrintingData.Tables[0].Rows.Count != index; ++index)
        {
          if (dsPrintingData.Tables[0].Rows[index]["FIELDNAME"].ToString().ToUpper() == "CARD NUMBER")
          {
            empty = dsPrintingData.Tables[0].Rows[index]["VALUE"].ToString();
            Log.LogFile("CardNumber[" + empty.Substring(0, 7) + "** **** " + empty.Substring(15, 4) + "]", 1);
            if (empty == "")
            {
              sMsg = "Card Number Empty";
              return 153;
            }
            millisecondsTimeout = (int) dsPrintingData.Tables[0].Rows[index]["ChipWaitTime"];
            break;
          }
        }
    //chip perso
      }
      return 0;
    }

    private void HandleError(string action, SDK.Return result)
    {
      string str;
      switch (result)
      {
        case SDK.Return.InvalidSession:
          str = "ID_INVALID_SESSION";
          break;
        case SDK.Return.ParamError:
          str = "ID_PARAM_ERROR";
          break;
        case SDK.Return.LocalCommInUse:
          str = "ID_LOCALCOMM_IN_USE";
          break;
        case SDK.Return.RemoteCommInUse:
          str = "ID_REMOTECOMM_IN_USE";
          break;
        case SDK.Return.SpoolerNotEmpty:
          str = "ID_SPOOLER_NOT_EMPTY";
          break;
        case SDK.Return.LocalCommError:
          str = "ID_LOCALCOMM_ERROR";
          break;
        case SDK.Return.RemoteCommError:
          str = "ID_REMOTECOMM_ERROR";
          break;
        case SDK.Return.OpenPrinterError:
          str = "ID_OPENPRINTER_ERROR";
          break;
        case SDK.Return.DriverNotCompliant:
          str = "ID_DRIVER_NOTCOMPLIANT";
          break;
        case SDK.Return.PrinterError:
          str = "ID_PRINTER_ERROR";
          break;
        case SDK.Return.Error:
          str = "ID_ERROR";
          break;
        case SDK.Return.Timeout:
          str = "ID_TIMEOUT";
          break;
        default:
          str = "Unknown API Error - " + (object) result;
          break;
      }
      int num = (int) MessageBox.Show(action + ": " + str);
    }

    public bool Flip_Card()
    {
      SDK.Return @return = SDK.ID_FlipCard(RioPro.hSession);
      if ((uint) @return > 0U)
      {
        Log.LogFile("Card flip Failed " + (object) @return, 0);
      }
      else
      {
        WaitForPrinterToFinish();
        Log.LogFile("Card flip Successfully", 0);
      }
      return true;
    }

    public string LogErrorandMsg(string Msg)
    {
      string str1 = "";
      string str2;
      try
      {
        if (!File.Exists("Log.Logfiles\\RioProError.txt"))
          File.CreateText("Log.Logfiles\\RioProError.txt");
        str1 = File.ReadAllText("Log.Logfiles\\RioProError.txt");
        str2 = Msg;
      }
      catch (Exception ex)
      {
        str2 = "Unable to get response from Printer. Cause:" + ex.ToString();
      }
      return str2;
    }

    public bool Feed_Card()
    {
      SDK.FeedMode key = new KeyValuePair<SDK.FeedMode, string>(SDK.FeedMode.ChipCard, "ChipCard").Key;
      if ((uint) SDK.ID_FeedCard(RioPro.hSession, key, (byte) 0) > 0U)
      {
        Log.LogFile("Card feed Failed ", 0);
        return false;
      }
      if (WaitForPrinterToFinish())
        return true;
      Log.LogFile("Card feed Failed ", 0);
      return false;
    }

    public int PrintCard(
      DataSet dsPrintingData,
      DataSet dsMagData,
      ref string sMsg,
      ref bool MagDone,
      ref bool PrintDone)
    {
      SDK.TextDef TextDef = new SDK.TextDef();
      if (bMag)
      {
        Log.LogFile("Preparing Encoding Data...", 0);
        SDK.EjectMode key = new KeyValuePair<SDK.EjectMode, string>(SDK.EjectMode.Off, "Off").Key;
        SDK.ID_EjectMode(RioPro.hSession, SDK.Action.Write, ref key);
        bool flag = dsMagData.Tables[0].Rows[0]["COERCIVITY"].ToString() == "High";
        Log.LogFile("Coercitivity[" + dsMagData.Tables[0].Rows[0]["COERCIVITY"].ToString() + "-" + flag.ToString() + "]", 0);
        int num1 = EncodeMagstripe(0, dsMagData.Tables[0].Rows[0]["TRACK1"].ToString());
        if ((uint) num1 > 0U)
        {
          sMsg = "Error at track1 encoding\nMagstrip of card or MagData or Mag Encoder Head issue.\n\nPlease check the logs for exact error.";
          return num1;
        }
        int num2 = EncodeMagstripe(1, dsMagData.Tables[0].Rows[0]["TRACK2"].ToString());
        if ((uint) num2 > 0U)
        {
          sMsg = "Error at track2 encoding\nMagstrip of card or MagData or Mag Encoder Head issue.\n\nPlease check the logs for exact error.";
          return num2;
        }
        if (MagRead())
        {
          MagDone = true;
        }
        else
        {
          MagDone = false;
          int num3 = 1;
          sMsg = "Magdone Failed";
          sMsg += "\nError at track1 & track2 encoding\nMagstrip of card or MagData or Mag Encoder Head issue.\n\nPlease check the logs for exact error.";
          return num3;
        }
      }
      if (bPrint)
      {
        Log.LogFile("Preparing Printing Data...", 0);
        Log.LogFile("Printing Data Count [" + (object) dsPrintingData.Tables[0].Rows.Count + "]", 0);
        SDK.PrintSetting printSetting = new SDK.PrintSetting();
        SDK.PrintSetting PrintSetting1 = new SDK.PrintSetting();
        IntPtr hDC1;
        SDK.Return @return = SDK.ID_CanvasInit(RioPro.hSession, out hDC1, SDK.Canvas.Front);
        foreach (DataRow row in (InternalDataCollectionBase) dsPrintingData.Tables[0].Rows)
        {
          Log.LogFile("Printing Data Count [" + row["SIDE"].ToString().Trim() + "]", 0);
          if (row["SIDE"].ToString().Trim() == "Rear" || row["SIDE"].ToString().Trim() == "1")
          {
            SDK.CardSetting cardSetting = new SDK.CardSetting();
            SDK.CardSetting CardSetting1 = new SDK.CardSetting();
            @return = SDK.ID_CardSettings(RioPro.hSession, SDK.Action.Read, SDK.Side.Back, CardSetting1);
            SDK.CardSetting CardSetting2 = CardSetting1;
            @return = SDK.ID_CardSettings(RioPro.hSession, SDK.Action.Write, SDK.Side.Back, CardSetting2);
            IntPtr hDC2;
            @return = SDK.ID_CanvasInit(RioPro.hSession, out hDC2, SDK.Canvas.Back);
            TextDef.FontName = row["Font"].ToString();
            TextDef.FontSize = (int) row["size"];
            TextDef.FontStyle = (SDK.FontStyle) 0;
            TextDef.X = (int) row["X"];
            TextDef.Y = (int) row["Y"];
            TextDef.Angle = 0;
            TextDef.Text = row["value"].ToString();
            Log.LogFile("Value [" + row["value"].ToString() + "] Font [" + row["Font"].ToString() + "] X [" + row["X"].ToString() + "] Y [" + row["Y"].ToString() + "] Size [" + row["size"] + "]", 0);
            SDK.Return result = SDK.ID_DrawText(RioPro.hSession, SDK.Canvas.Back, TextDef);
            if ((uint) result > 0U)
            {
              HandleError("DrawTextback", result);
              break;
            }
          }
          if (row["SIDE"].ToString().Trim() == "Front" || row["SIDE"].ToString().Trim() == "0")
          {
            SDK.Return result1 = SDK.ID_PrintSettings(RioPro.hSession, SDK.Action.Read, PrintSetting1);
            if ((uint) result1 > 0U)
            {
              HandleError("OldPrintSettings", result1);
              break;
            }
            SDK.PrintSetting PrintSetting2 = PrintSetting1;
            PrintSetting2.Duplex = SDK.Duplex.Both;
            SDK.Return result2 = SDK.ID_PrintSettings(RioPro.hSession, SDK.Action.Write, PrintSetting2);
            if ((uint) result2 > 0U)
            {
              HandleError("WritePrintSettings", result2);
              break;
            }
            TextDef.FontName = row["Font"].ToString();
            TextDef.FontSize = (int) row["size"];
            TextDef.FontStyle = (SDK.FontStyle) 0;
            TextDef.X = (int) row["X"];
            TextDef.Y = (int) row["Y"];
            TextDef.Angle = 0;
            TextDef.Text = row["value"].ToString();
            try
            {
              Log.LogFile("Value [" + row["value"].ToString() + "] Font [" + row["Font"].ToString() + "] X [" + row["X"].ToString() + "] Y [" + row["Y"].ToString() + "] Size [" + row["size"] + "]", 0);
            }
            catch (Exception ex)
            {
              Log.LogFile(ex.ToString(), 0);
            }
            SDK.Return result3 = SDK.ID_DrawText(RioPro.hSession, SDK.Canvas.Front, TextDef);
            if ((uint) result3 > 0U)
            {
              Log.LogFile("Unable to Draw Text for Value [" + row["value"].ToString() + "]", 0);
              HandleError("DrawTextFront", result3);
              break;
            }
          }
        }
      }
      SDK.Return result4 = SDK.ID_PrintCard(RioPro.hSession);
      if ((uint) result4 > 0U)
      {
        PrintDone = false;
        HandleError(nameof (PrintCard), result4);
        Log.LogFile("Thermal Printing  Failed", 0);
      }
      else
      {
        PrintDone = true;
        Log.LogFile("Thermal Printing  Success", 0);
      }
      if (PrintDone)
      {
        sMsg = "";
        return 0;
      }
      sMsg = "Printing Error";
      return 1;
    }

    private bool WaitForPrinterToFinish()
    {
      Cursor.Current = Cursors.WaitCursor;
      SDK.Return @return;
      do
      {
        @return = SDK.ID_WaitForPrinter(RioPro.hSession);
      }
      while (@return == SDK.Return.Timeout);
      if ((uint) @return <= 0U)
        return true;
      Log.LogFile("Printer Response " + (object) @return, 0);
      return false;
    }

    public bool MagRead()
    {
      byte num = 0;
      SDK.EncodingSpec key = new KeyValuePair<SDK.EncodingSpec, string>(SDK.EncodingSpec.ISO, "ISO").Key;
      byte Tracks = (byte) ((uint) (byte) ((uint) num | 1U) | 2U);
      if (Tracks == (byte) 0 || (uint) SDK.ID_ReadMagTracks(RioPro.hSession, MagData, key, Tracks) > 0U)
        return false;
      string tk1 = MagData.tk1;
      string tk2 = MagData.tk2;
      string[] strArray1 = tk1.Split('^');
      string[] strArray2 = tk2.Split('=');
      string str1 = string.Empty;
      string str2 = string.Empty;
      string str3 = string.Empty;
      string str4 = string.Empty;
      string str5 = string.Empty;
      foreach (string str6 in strArray1)
      {
        str1 = strArray1[0].Substring(1, 7) + "** ****" + strArray1[0].Substring(13, 4) + "^";
        str2 = strArray1[1].Substring(0, 8) + "** ****" + strArray1[1].Substring(16, 4) + "^";
        str3 = strArray1[2].Substring(0, 12) + "** ****" + strArray1[2].Substring(13, 4);
      }
      string str7 = str1 + str2 + str3;
      foreach (string str6 in strArray2)
      {
        str4 = strArray2[0].Substring(0, 7) + "** ****" + strArray2[0].Substring(10, 4) + "=";
        str5 = strArray2[1].Substring(0, 7) + "** ****" + strArray2[1].Substring(13, 4);
      }
      Log.LogFile("Track1 Value [ " + str1 + str2 + str3 + " ] Track2 Value [ " + str4 + str5 + " ]", 0);
      Log.LogFile("(Track 1): " + (MagData.tk1_pass != 0 ? "PASS" : "FAIL"), 0);
      Log.LogFile("(Track 2): " + (MagData.tk2_pass != 0 ? "PASS" : "FAIL"), 0);
      return true;
    }

    public int EncodeMagstripe(int iTrackNumber, string sTrackData)
    {
      SDK.MagDef pMagDef = new SDK.MagDef();
      SDK.MagText magText = new SDK.MagText();
      pMagDef.Verify = SDK.Verify.On;
      pMagDef.Track[iTrackNumber].CharCount = (int) Decimal.ToByte((Decimal) sTrackData.Length);
      pMagDef.Track[iTrackNumber].Data = sTrackData;
      SDK.ID_EncodeMag(RioPro.hSession, pMagDef);
      SDK.EncodingSpec key = new KeyValuePair<SDK.EncodingSpec, string>(SDK.EncodingSpec.ISO, "ISO").Key;
      return (uint) SDK.ID_ReadMag(RioPro.hSession, MagData, key) <= 0U ? 0 : -1;
    }

    public void GetPrinterConnectiontype()
    {
      string str;
      switch (SDK.ID_ConnectionType(RioPro.hSession))
      {
        case SDK.ConnectionType.USB:
          str = "USB";
          break;
        case SDK.ConnectionType.Ethernet:
          str = "Ethernet";
          break;
        case SDK.ConnectionType.File:
          str = "File";
          break;
        default:
          str = "Unknown";
          break;
      }
      Log.LogFile("GetPrinterConnectiontype [" + str + "]", 0);
    }

    private enum RibbonType
    {
      YMCKO = 0,
      KO = 1,
      YMCKOK = 2,
      Mono = 4,
      MonoEx = 8,
      HYMCKO = 128, // 0x00000080
    }
  }
}
