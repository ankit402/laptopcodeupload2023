﻿// Decompiled with JetBrains decompiler
// Type: MagicardProLibrary.DAL
// Assembly: MagicardProLibrary, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 42330D39-DB7D-4E8E-8BCF-74ADB991FF4A
// Assembly location: D:\Shared Folder\Magicard tool\MagicardProLibrary.dll


using System;
using System.Data;
using System.Data.SqlClient;

namespace MagicardProLibrary
{
  internal class DAL
  {
    private LogClass log = new LogClass();

    public DataSet GetPrintingProfileDetails(string ProfileID)
    {
      DataSet dataSet1 = new DataSet();
      //DataSet dataSet2 = new DB().ExecuteDataset("PRT_ReadPrinterProfileDetails_SP", new SqlParameter("@riProfileId", (object) ProfileID));
      //if (dataSet2.Tables[0].Rows.Count == 0)
      //  this.log.LogFile("No data found from PRT_ReadPrinterProfileDetails_SP", 0);
      return dataSet1;
    }

    public DataSet GetPrintingRecords(string BranchID, string ProfileID)
    {
      DataSet dataSet1 = new DataSet();
      //DataSet dataSet2 = new DB().ExecuteDataset("PRT_ReadPrintingRecordData_SP", new SqlParameter("@BranchId", (object) BranchID), new SqlParameter("@ProfileId", (object) ProfileID));
      //if (dataSet2.Tables[0].Rows.Count == 0)
      //  this.log.LogFile("No data found from PRT_ReadPrintingRecordData_SP", 0);
      return dataSet1;
    }

    public DataSet GetPrintingRecords(string BranchID, string ProfileID, int PrintId)
    {
      DataSet dataSet2 = new DataSet();
      //DataSet dataSet2 = new DB().ExecuteDataset("PRT_ReadPrintingRecordData_SP", new SqlParameter("@BranchId", (object) BranchID), new SqlParameter("@ProfileId", (object) ProfileID), new SqlParameter("@PrintId", (object) PrintId));
      //if (dataSet2.Tables[0].Rows.Count == 0)
      //  this.log.LogFile("No data found from PRT_ReadPrintingRecordData_SP with Profile ID[" + ProfileID + "] Print ID[" + (object) PrintId + "]", 0);
      return dataSet2;
    }

    public DataSet GetPrintingRecordData(string ProfileID, string PrintID)
    {
      DataSet dataSet2 = new DataSet();
      //DataSet dataSet2 = new DB().ExecuteDataset("PRT_ReadPrintingData_SP", new SqlParameter("@ProfileID", (object) ProfileID), new SqlParameter("@PrintID", (object) PrintID));
      //if (dataSet2.Tables[0].Rows.Count == 0)
      //  this.log.LogFile("No data found from PRT_ReadPrintingData_SP", 0);
      return dataSet2;
    }

    public DataSet GetEncodingRecordData(string ProfileID, string PrintID)
    {
      DataSet dataSet2 = new DataSet();
      //DataSet dataSet2 = new DB().ExecuteDataset("PRT_ReadEncodingData_SP", new SqlParameter("@ProfileID", (object) ProfileID), new SqlParameter("@PrintID", (object) PrintID));
      //if (dataSet2.Tables[0].Rows.Count == 0)
      //  this.log.LogFile("No data found from PRT_ReadEncodingData_SP with Profile ID[" + ProfileID + "] Print ID[" + PrintID + "]", 0);
      return dataSet2;
    }

    public DataSet UpdatePrintRecord(
      string PrintID,
      string Status,
      string Description,
      bool ChipStatus,
      bool MagStatus,
      bool PrintStatus)
    {
      DataSet dataSet2 = new DataSet();
      //DataSet dataSet2 = new DB().ExecuteDataset("PRT_UpdatePrintRecord_SP", new SqlParameter("@PrintID", (object) PrintID), new SqlParameter("@Status", (object) Status), new SqlParameter("@Description", (object) Description), new SqlParameter("@ChipStatus", (object) ChipStatus), new SqlParameter("@MagStatus", (object) MagStatus), new SqlParameter("@PrintStatus", (object) PrintStatus));
      //if (dataSet2.Tables[0].Rows.Count == 0)
      //  this.log.LogFile("No data found from PRT_UpdatePrintRecord_SP", 0);
      return dataSet2;
    }

    public DataSet UpdatePrintRecord_JobIdEmbossID(
      string PrintID,
      string JobID,
      string EmbossID)
    {
      DataSet dataSet1 = new DataSet();
      //DataSet dataSet2 = new DB().ExecuteDataset("PRT_UpdatePrintRecord_JobIDEmbossID_SP", new SqlParameter("@PrintID", (object) PrintID), new SqlParameter("@JobID", (object) JobID), new SqlParameter("@EmbossID", (object) EmbossID));
      //if (dataSet2.Tables[0].Rows.Count == 0)
      //  this.log.LogFile("No data found from PRT_UpdatePrintRecord_SP", 0);
      return dataSet1;
    }

    public string ReadChipStatus(string PrintID)
    {
      DataSet dataSet1 = new DataSet();
      //DataSet dataSet2 = new DB().ExecuteDataset("PRT_ReadChipStatus_SP", new SqlParameter("@PrintID", (object) PrintID));
      //if (dataSet2.Tables[0].Rows.Count == 0)
      //  this.log.LogFile("No data found from PRT_ReadChipStatus_SP", 0);
      return dataSet1.Tables[0].Rows[0][0].ToString();
    }

    public string ReadErrorMsg(string Error)
    {
      DataSet dataSet1 = new DataSet();
     // DB db = new DB();
      Error = Error.Contains("[") ? Error.Replace("[", "[[") : Error;
      Error = Error.Contains("]") ? Error.Replace("]", "]]") : Error;
      SqlParameter sqlParameter = new SqlParameter("@ErrorMessage", (object) Error);
      //DataSet dataSet2 = db.ExecuteDataset("SM_ReadErrorDetail_SP", sqlParameter);
      //if (dataSet2.Tables[0].Rows.Count <= 0)
      //  return Error;
      //string str1 = "Failed: " + Error + "\n";
      //string str2 = dataSet2.Tables[0].Rows[0]["Error_Description"].ToString();
      //string str3 = dataSet2.Tables[0].Rows[0]["Recommendation"].ToString();
      //if (str3.StartsWith("Recommendation : "))
      //  str1 = str1 + str2 + "\n" + str3.Replace("Recommendation : ", "") + "\n";
      return "";
    }

    public void InsertLogRecord(
      DateTime logdatetime,
      string branchcode,
      string branchname,
      string systemname,
      string printerid,
      string methodname,
      string message)
    {
      //new DB().ExecuteScalar("LOG_InsertLogDetails_SP", new SqlParameter("@Logdatetime", (object) logdatetime), new SqlParameter("@BranchCode", (object) branchcode), new SqlParameter("@BranchName", (object) branchname), new SqlParameter("@SystemName", (object) systemname), new SqlParameter("@PrinterID", (object) printerid), new SqlParameter("@MethodName", (object) methodname), new SqlParameter("@LogMessage", (object) message));
    }
  }
}
