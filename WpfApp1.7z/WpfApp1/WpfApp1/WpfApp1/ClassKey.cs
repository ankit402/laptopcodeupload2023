﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Xml.Serialization;

namespace WpfApp1
{
    [XmlRoot(ElementName = "Set")]
    public class Set
    {
        [XmlAttribute(AttributeName = "Name")]
        public string Name { get; set; }
        [XmlAttribute(AttributeName = "ID")]
        public string ID { get; set; }
        [XmlAttribute(AttributeName = "Description")]
        public string Description { get; set; }
    }

    [XmlRoot(ElementName = "KeySet")]
    public class KeySet
    {
        [XmlElement(ElementName = "Set")]
        public List<Set> Set { get; set; }
    }

    [XmlRoot(ElementName = "Type")]
    public class Type
    {
        [XmlAttribute(AttributeName = "Name")]
        public string Name { get; set; }
        [XmlAttribute(AttributeName = "ID")]
        public string ID { get; set; }
        [XmlAttribute(AttributeName = "KeySet")]
        public string KeySet { get; set; }
        [XmlAttribute(AttributeName = "Description")]
        public string Description { get; set; }
    }

    [XmlRoot(ElementName = "KeyType")]
    public class KeyType
    {
        [XmlElement(ElementName = "Type")]
        public List<Type> Type { get; set; }
    }

    [XmlRoot(ElementName = "Key")]
    public class Key
    {
        [XmlAttribute(AttributeName = "ID")]
        public string ID { get; set; }
        [XmlAttribute(AttributeName = "Name")]
        public string Name { get; set; }
        [XmlAttribute(AttributeName = "CryptoID")]
        public string CryptoID { get; set; }
        [XmlAttribute(AttributeName = "KeyTypeID")]
        public string KeyTypeID { get; set; }
        [XmlAttribute(AttributeName = "Component")]
        public string Component { get; set; }
        [XmlAttribute(AttributeName = "KCV")]
        public string KCV { get; set; }
    }

    [XmlRoot(ElementName = "Keys")]
    public class Keys
    {
        [XmlElement(ElementName = "Key")]
        public List<Key> Key { get; set; }
        [XmlAttribute(AttributeName = "ID")]
        public string ID { get; set; }
        [XmlAttribute(AttributeName = "Name")]
        public string Name { get; set; }
        [XmlAttribute(AttributeName = "Description")]
        public string Description { get; set; }
        [XmlAttribute(AttributeName = "KeySetID")]
        public string KeySetID { get; set; }
    }

    [XmlRoot(ElementName = "KeyStores")]
    public class KeyStores
    {
        [XmlElement(ElementName = "Keys")]
        public List<Keys> Keys { get; set; }
    }

    [XmlRoot(ElementName = "KeyBank")]
    public class KeyBank
    {
        [XmlElement(ElementName = "KeySet")]
        public KeySet KeySet { get; set; }
        [XmlElement(ElementName = "KeyType")]
        public KeyType KeyType { get; set; }
     
        [XmlElement(ElementName = "KeyStores")]
        public KeyStores KeyStores { get; set; }
    }

}
