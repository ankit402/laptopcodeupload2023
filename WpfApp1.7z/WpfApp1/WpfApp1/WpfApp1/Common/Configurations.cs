﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Net.Pkcs11Interop.Tests;
using Net.Pkcs11Interop.Tests.HighLevelAPI;
using Net.Pkcs11Interop.Common;
using Net.Pkcs11Interop.HighLevelAPI;

namespace WpfApp1.Common
{
    public static class Configurations
    {
        public const int RETURN_NO = 3;

        public static bool loginStatus { get; set; }
        public static string hsm_password { get; set; }
        public static CKU user_type { get; set; }
        public static int default_slot = 1;
        public static string Pkcs11LibraryPath = @"C:\Program Files (x86)\SafeNet\Protect Toolkit C SDK\bin\hsm\cryptoki.dll";//C:\Program Files (x86)\SafeNet\Protect Toolkit C SDK\bin\hsm\cryptoki.dll
        public const string LMK_KEYNAME = "LMK_MASTER_KEY";
        public const bool isSwHsm = false;
       // public static string abc = ConfigurationManager
    }
}
