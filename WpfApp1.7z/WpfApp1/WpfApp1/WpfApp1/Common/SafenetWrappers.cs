﻿using WpfApp1.Crypto;
using Net.Pkcs11Interop.Common;
using Net.Pkcs11Interop.HighLevelAPI;
using Net.Pkcs11Interop.HighLevelAPI40;
using Net.Pkcs11Interop.Tests;
using Net.Pkcs11Interop.Tests.HighLevelAPI;
using Org.BouncyCastle.Asn1;
using Org.BouncyCastle.Asn1.Pkcs;
using System;
using System.Collections.Generic;
using System.Text;
using System.Windows.Forms;
using WpfApp1.Data;

namespace WpfApp1.Common
{
    public class SafenetWrappers
    {

        /********************************** GET CLEAR KEY *******************************/

        public static string doGenerateSecretKey3Des3KeyAndReturnClearKey()
        {
            return doGenerateSecretKey3DesAndReturnClearKey(CKM.CKM_DES3_KEY_GEN);
        }

        public static string doGenerateSecretKey3Des2KeyAndReturnClearKey()
        {
            return doGenerateSecretKey3DesAndReturnClearKey(CKM.CKM_DES2_KEY_GEN);
        }

        //public static string doGenerateSecretKey3Des1KeyAndReturnClearKey()
        //{
        //    return doGenerateSecretKey3DesAndReturnClearKey(CKM.CKM_DES_KEY_GEN);
        //}

        /********************************** GET CLEAR KEY and KCV *******************************/
        //Generate a 3 Des 3 Key
        public static string[] doGenerateSecretKey3Des3KeyAndReturnClearKeyAndKCV()
        {
            return doGenerateSecretKey3DesAndReturnClearKeyAndKCV(CKM.CKM_DES3_KEY_GEN);
        }

        //Generate a 3 Des 2 Key
        public static string[] doGenerateSecretKey3Des2KeyAndReturnCleaKeyAndKCV()
        {
            return doGenerateSecretKey3DesAndReturnClearKeyAndKCV(CKM.CKM_DES2_KEY_GEN);
        }

        //public static string[] doGenerateSecretKey3Des1KeyAndReturnClearKeyAndKCV()
        //{
        //    return doGenerateSecretKey3DesAndReturnClearKeyAndKCV(CKM.CKM_DES_KEY_GEN);
        //}


        /********************************** GET ENCRYPTD KEY UNDER LMK and KCV *******************************/

        public static KekKey doGenerateSecretKey3Des3KeyAndReturnEncryptedKeyAndKCV()
        {
            return doGenerateSecretKey3DesAndReturnEncryptedUnderLMKAndKCV(CKM.CKM_DES3_KEY_GEN);
        }

        public static KekKey doGenerateSecretKey3Des2KeyAndReturnEncryptedKeyAndKCV()
        {
            return doGenerateSecretKey3DesAndReturnEncryptedUnderLMKAndKCV(CKM.CKM_DES2_KEY_GEN);
        }

        //public static string[] doGenerateSecretKey3Des1KeyAndReturnEncryptedKeyAndKCV()
        //{
        //    return doGenerateSecretKey3DesAndReturnEncryptedUnderLMKAndKCV(CKM.CKM_DES_KEY_GEN);
        //}

        private static string doGenerateSecretKey3DesAndReturnClearKey(CKM keyType)
        {
            using (IPkcs11 pkcs11 = Settings.Factories.Pkcs11Factory.CreatePkcs11(Settings.Factories, Configurations.Pkcs11LibraryPath, Settings.AppType))
            {
                // Find first slot with token present
                ISlot slot = Helpers.GetUsableSlot(pkcs11, Configurations.default_slot);

                // Open RW session
                using (Net.Pkcs11Interop.HighLevelAPI.ISession session = slot.OpenSession(SessionType.ReadWrite))
                {
                    // Login as normal user
                    session.Login(Configurations.user_type, Configurations.hsm_password);

                    // Prepare attribute template of new key
                    List<IObjectAttribute> objectAttributes = new List<IObjectAttribute>();
                    objectAttributes.Add(Settings.Factories.ObjectAttributeFactory.CreateObjectAttribute(CKA.CKA_TOKEN, false)); //not stored in token
                    objectAttributes.Add(Settings.Factories.ObjectAttributeFactory.CreateObjectAttribute(CKA.CKA_CLASS, CKO.CKO_SECRET_KEY));
                    objectAttributes.Add(Settings.Factories.ObjectAttributeFactory.CreateObjectAttribute(CKA.CKA_KEY_TYPE, keyType == CKM.CKM_DES_KEY_GEN ? CKK.CKK_DES : CKK.CKK_DES3));
                    objectAttributes.Add(Settings.Factories.ObjectAttributeFactory.CreateObjectAttribute(CKA.CKA_ENCRYPT, true));
                    objectAttributes.Add(Settings.Factories.ObjectAttributeFactory.CreateObjectAttribute(CKA.CKA_DECRYPT, true));
                    objectAttributes.Add(Settings.Factories.ObjectAttributeFactory.CreateObjectAttribute(CKA.CKA_WRAP, true));
                    objectAttributes.Add(Settings.Factories.ObjectAttributeFactory.CreateObjectAttribute(CKA.CKA_UNWRAP, true));
                    objectAttributes.Add(Settings.Factories.ObjectAttributeFactory.CreateObjectAttribute(CKA.CKA_EXTRACTABLE, true));

                    // Specify key generation mechanism
                    IMechanism mechanism = Settings.Factories.MechanismFactory.CreateMechanism(keyType);

                    // Generate key
                    IObjectHandle secret_key = session.GenerateKey(mechanism, objectAttributes);

                    // Do something interesting with generated key

                    /****************** WRAP and Decrypt Key ***********************************/

                    // Prepare attribute template of new key
                    List<IObjectAttribute> objectAttributes_wrapper_key = new List<IObjectAttribute>();
                    objectAttributes_wrapper_key.Add(Settings.Factories.ObjectAttributeFactory.CreateObjectAttribute(CKA.CKA_TOKEN, false)); //not stored in token
                    objectAttributes_wrapper_key.Add(Settings.Factories.ObjectAttributeFactory.CreateObjectAttribute(CKA.CKA_CLASS, CKO.CKO_SECRET_KEY));
                    objectAttributes_wrapper_key.Add(Settings.Factories.ObjectAttributeFactory.CreateObjectAttribute(CKA.CKA_KEY_TYPE, keyType == CKM.CKM_DES_KEY_GEN ? CKK.CKK_DES : CKK.CKK_DES3));
                    //objectAttributes_wrapper_key.Add(Settings.Factories.ObjectAttributeFactory.CreateObjectAttribute(CKA.CKA_ENCRYPT, true));
                    objectAttributes_wrapper_key.Add(Settings.Factories.ObjectAttributeFactory.CreateObjectAttribute(CKA.CKA_DECRYPT, true));
                    //objectAttributes_wrapper_key.Add(Settings.Factories.ObjectAttributeFactory.CreateObjectAttribute(CKA.CKA_DERIVE, true));
                    //objectAttributes_wrapper_key.Add(Settings.Factories.ObjectAttributeFactory.CreateObjectAttribute(CKA.CKA_EXTRACTABLE, true));
                    objectAttributes_wrapper_key.Add(Settings.Factories.ObjectAttributeFactory.CreateObjectAttribute(CKA.CKA_WRAP, true));
                    //objectAttributes_wrapper_key.Add(Settings.Factories.ObjectAttributeFactory.CreateObjectAttribute(CKA.CKA_UNWRAP, true));

                    // Generate symmetric wrapper key
                    IObjectHandle wrapper_key = session.GenerateKey(mechanism, objectAttributes_wrapper_key);

                    IMechanism mechanism_wrap_decrypt = Settings.Factories.MechanismFactory.CreateMechanism(keyType == CKM.CKM_DES_KEY_GEN ? CKM.CKM_DES_ECB : CKM.CKM_DES3_ECB);

                    // Wrap key
                    byte[] wrappedKeyBytes = session.WrapKey(mechanism_wrap_decrypt, wrapper_key, secret_key);

                    // Do something interesting with wrapped key
                    if (wrappedKeyBytes == null)
                        throw new Exception("Fail wrapping key");

                    // Decrypt data
                    byte[] decryptedData = session.Decrypt(mechanism_wrap_decrypt, wrapper_key, wrappedKeyBytes);

                    // Destroy object
                    session.DestroyObject(wrapper_key);
                    session.DestroyObject(secret_key);
                    session.Logout();

                    return HelperFunctions.ByteArrayToString(decryptedData);
                }
            }
        }


        private static string[] doGenerateSecretKey3DesAndReturnClearKeyAndKCV(CKM keyType)
        {
            using (IPkcs11 pkcs11 = Settings.Factories.Pkcs11Factory.CreatePkcs11(Settings.Factories, Configurations.Pkcs11LibraryPath, Settings.AppType))
            {
                // Find first slot with token present
                ISlot slot = Helpers.GetUsableSlot(pkcs11, Configurations.default_slot);

                // Open RW session
                using (Net.Pkcs11Interop.HighLevelAPI.ISession session = slot.OpenSession(SessionType.ReadWrite))
                {
                    // Login as normal user
                    session.Login(Configurations.user_type, Configurations.hsm_password);

                    // Prepare attribute template of new key
                    List<IObjectAttribute> objectAttributes = new List<IObjectAttribute>();
                    objectAttributes.Add(Settings.Factories.ObjectAttributeFactory.CreateObjectAttribute(CKA.CKA_TOKEN, false)); //not stored in token
                    objectAttributes.Add(Settings.Factories.ObjectAttributeFactory.CreateObjectAttribute(CKA.CKA_CLASS, CKO.CKO_SECRET_KEY));
                    objectAttributes.Add(Settings.Factories.ObjectAttributeFactory.CreateObjectAttribute(CKA.CKA_KEY_TYPE, keyType == CKM.CKM_DES_KEY_GEN ? CKK.CKK_DES : CKK.CKK_DES3));
                    objectAttributes.Add(Settings.Factories.ObjectAttributeFactory.CreateObjectAttribute(CKA.CKA_ENCRYPT, true));
                    objectAttributes.Add(Settings.Factories.ObjectAttributeFactory.CreateObjectAttribute(CKA.CKA_DECRYPT, true));
                    objectAttributes.Add(Settings.Factories.ObjectAttributeFactory.CreateObjectAttribute(CKA.CKA_WRAP, true));
                    objectAttributes.Add(Settings.Factories.ObjectAttributeFactory.CreateObjectAttribute(CKA.CKA_UNWRAP, true));
                    objectAttributes.Add(Settings.Factories.ObjectAttributeFactory.CreateObjectAttribute(CKA.CKA_EXTRACTABLE, true));

                    // Specify key generation mechanism
                    IMechanism mechanism = Settings.Factories.MechanismFactory.CreateMechanism(keyType);

                    // Generate key
                    IObjectHandle secret_key = session.GenerateKey(mechanism, objectAttributes);

                    /****************** Compute KCV ***********************************/
                    byte[] iv = new byte[8];

                    IMechanism mechanism_wrap_encrypt_decrypt = Settings.Factories.MechanismFactory.CreateMechanism(keyType == CKM.CKM_DES_KEY_GEN ? CKM.CKM_DES_ECB : CKM.CKM_DES3_ECB);

                    // Encrypt data
                    byte[] kcvBytes = session.Encrypt(mechanism_wrap_encrypt_decrypt, secret_key, iv);


                    // Do something interesting with generated key

                    /****************** WRAP Key ***********************************/

                    // Prepare attribute template of new key
                    List<IObjectAttribute> objectAttributes_wrapper_key = new List<IObjectAttribute>();
                    objectAttributes_wrapper_key.Add(Settings.Factories.ObjectAttributeFactory.CreateObjectAttribute(CKA.CKA_TOKEN, false)); //not stored in token
                    objectAttributes_wrapper_key.Add(Settings.Factories.ObjectAttributeFactory.CreateObjectAttribute(CKA.CKA_CLASS, CKO.CKO_SECRET_KEY));
                    objectAttributes_wrapper_key.Add(Settings.Factories.ObjectAttributeFactory.CreateObjectAttribute(CKA.CKA_KEY_TYPE, keyType == CKM.CKM_DES_KEY_GEN ? CKK.CKK_DES : CKK.CKK_DES3));
                    //objectAttributes_wrapper_key.Add(Settings.Factories.ObjectAttributeFactory.CreateObjectAttribute(CKA.CKA_ENCRYPT, true));
                    objectAttributes_wrapper_key.Add(Settings.Factories.ObjectAttributeFactory.CreateObjectAttribute(CKA.CKA_DECRYPT, true));
                    //objectAttributes_wrapper_key.Add(Settings.Factories.ObjectAttributeFactory.CreateObjectAttribute(CKA.CKA_DERIVE, true));
                    //objectAttributes_wrapper_key.Add(Settings.Factories.ObjectAttributeFactory.CreateObjectAttribute(CKA.CKA_EXTRACTABLE, true));
                    objectAttributes_wrapper_key.Add(Settings.Factories.ObjectAttributeFactory.CreateObjectAttribute(CKA.CKA_WRAP, true));
                    //objectAttributes_wrapper_key.Add(Settings.Factories.ObjectAttributeFactory.CreateObjectAttribute(CKA.CKA_UNWRAP, true));

                    // Generate symmetric wrapper key
                    IObjectHandle wrapper_key = session.GenerateKey(mechanism, objectAttributes_wrapper_key);

                    // Wrap key
                    byte[] wrappedKeyBytes = session.WrapKey(mechanism_wrap_encrypt_decrypt, wrapper_key, secret_key);

                    // Do something interesting with wrapped key
                    if (wrappedKeyBytes == null)
                        throw new Exception("Fail wrapping key");

                    /****************** DECRYPT WRAPPED Key ***********************************/

                    // Decrypt data
                    byte[] decryptedData = session.Decrypt(mechanism_wrap_encrypt_decrypt, wrapper_key, wrappedKeyBytes);

                    string[] result = new string[2];
                    result[0] = HelperFunctions.ByteArrayToString(decryptedData);
                    result[1] = HelperFunctions.ByteArrayToString(kcvBytes).Substring(0, 6);

                    // Destroy object
                    session.DestroyObject(wrapper_key);
                    session.DestroyObject(secret_key);
                    session.Logout();

                    return result;
                }
            }
        }

        public static bool doSafenetLogin()
        {
            bool loginStatus = false;

            using (IPkcs11 pkcs11 = Settings.Factories.Pkcs11Factory.CreatePkcs11(Settings.Factories, Configurations.Pkcs11LibraryPath, Settings.AppType))
            {
                Configurations.Pkcs11LibraryPath = @"C:\Program Files\SafeNet\Protect Toolkit C SDK\bin\hsm\cryptoki.dll";
                Configurations.default_slot = 0;
            // Find first slot with token present
            ISlot slot = Helpers.GetUsableSlot(pkcs11, Configurations.default_slot);

                // Open RO session
                using (Net.Pkcs11Interop.HighLevelAPI.ISession session = slot.OpenSession(SessionType.ReadOnly))
                {
                    // Login as normal user
                    session.Login(Configurations.user_type, Configurations.hsm_password);

                    loginStatus = true;

                    //// Do something interesting as normal user
                    session.Logout();
                }
            }

            return loginStatus;
        }

        public static int findLMKKey(string LMK_keyname = Configurations.LMK_KEYNAME)
        {
            int foundObjectCounter = 0;

            using (IPkcs11 pkcs11 = Settings.Factories.Pkcs11Factory.CreatePkcs11(Settings.Factories, Configurations.Pkcs11LibraryPath, Settings.AppType))
            {
                // Find first slot with token present
                ISlot slot = Helpers.GetUsableSlot(pkcs11, Configurations.default_slot);

                // Open RW session
                using (ISession session = slot.OpenSession(SessionType.ReadWrite))
                {
                    // Login as normal user
                    session.Login(Configurations.user_type, Configurations.hsm_password);

                    IObjectHandle keyObj = findAKeyObject(LMK_keyname, session);

                    // Do something interesting with found objects

                    if (keyObj != null)
                        foundObjectCounter = 1;

                    session.Logout();
                }
            }

            return foundObjectCounter;
        }

        public static string getLMKKCV(string LMK_keyname = Configurations.LMK_KEYNAME)
        {
            byte[] kcvBytes = null;
            using (IPkcs11 pkcs11 = Settings.Factories.Pkcs11Factory.CreatePkcs11(Settings.Factories, Configurations.Pkcs11LibraryPath, Settings.AppType))
            {
                // Find first slot with token present
                ISlot slot = Helpers.GetUsableSlot(pkcs11, Configurations.default_slot);

                // Open RW session
                using (ISession session = slot.OpenSession(SessionType.ReadWrite))
                {
                    // Login as normal user
                    session.Login(Configurations.user_type, Configurations.hsm_password);

                    IObjectHandle keyObj = findAKeyObject(LMK_keyname, session);

                    // Do something interesting with found objects
                    /****************** Compute KCV ***********************************/
                    byte[] iv = new byte[8];

                   IMechanism mechanism_wrap_encrypt_decrypt = Settings.Factories.MechanismFactory.CreateMechanism(CKM.CKM_DES3_ECB);
                  

                    // Encrypt data
                    kcvBytes = session.Encrypt(mechanism_wrap_encrypt_decrypt, keyObj, iv);

                    session.Logout();
                }
            }

            return HelperFunctions.ByteArrayToString(kcvBytes).Substring(0, 6); ;
        }

        private static IObjectHandle findAKeyObject(string LMK_keyname = Configurations.LMK_KEYNAME, ISession session = null)
        {
            // Prepare attribute template that defines search criteria
            List<IObjectAttribute> objectAttributes = new List<IObjectAttribute>();
            objectAttributes.Add(Settings.Factories.ObjectAttributeFactory.CreateObjectAttribute(CKA.CKA_TOKEN, true)); //not stored in token
            objectAttributes.Add(Settings.Factories.ObjectAttributeFactory.CreateObjectAttribute(CKA.CKA_CLASS, CKO.CKO_SECRET_KEY));
            objectAttributes.Add(Settings.Factories.ObjectAttributeFactory.CreateObjectAttribute(CKA.CKA_LABEL, LMK_keyname));
            objectAttributes.Add(Settings.Factories.ObjectAttributeFactory.CreateObjectAttribute(CKA.CKA_ENCRYPT, true));
            objectAttributes.Add(Settings.Factories.ObjectAttributeFactory.CreateObjectAttribute(CKA.CKA_DECRYPT, true));
            objectAttributes.Add(Settings.Factories.ObjectAttributeFactory.CreateObjectAttribute(CKA.CKA_WRAP, true));
            objectAttributes.Add(Settings.Factories.ObjectAttributeFactory.CreateObjectAttribute(CKA.CKA_UNWRAP, true));
            objectAttributes.Add(Settings.Factories.ObjectAttributeFactory.CreateObjectAttribute(CKA.CKA_KEY_TYPE, CKK.CKK_DES3));

            // Find all objects that match provided attributes
            List<IObjectHandle> foundObjects = session.FindAllObjects(objectAttributes);

            return foundObjects.Count > 0 ? foundObjects[0] :null;
        }


        // generate 3 des key, return it Ciphered under LMK, return the KCV also
        private static KekKey doGenerateSecretKey3DesAndReturnEncryptedUnderLMKAndKCV(CKM keyType)
        {
            KekKey kek = null;

            try
            {
                using (IPkcs11 pkcs11 = Settings.Factories.Pkcs11Factory.CreatePkcs11(Settings.Factories, Configurations.Pkcs11LibraryPath, Settings.AppType))
                {
                    // Find first slot with token present
                    ISlot slot = Helpers.GetUsableSlot(pkcs11, Configurations.default_slot);

                    // Open RW session
                    using (Net.Pkcs11Interop.HighLevelAPI.ISession session = slot.OpenSession(SessionType.ReadWrite))
                    {
                        // Login as normal user
                        session.Login(Configurations.user_type, Configurations.hsm_password);

                        // Prepare attribute template of new key
                        List<IObjectAttribute> objectAttributes = new List<IObjectAttribute>();
                        objectAttributes.Add(Settings.Factories.ObjectAttributeFactory.CreateObjectAttribute(CKA.CKA_TOKEN, false)); //not stored in token
                        objectAttributes.Add(Settings.Factories.ObjectAttributeFactory.CreateObjectAttribute(CKA.CKA_CLASS, CKO.CKO_SECRET_KEY));
                        objectAttributes.Add(Settings.Factories.ObjectAttributeFactory.CreateObjectAttribute(CKA.CKA_KEY_TYPE, keyType == CKM.CKM_DES_KEY_GEN ? CKK.CKK_DES : CKK.CKK_DES3));
                        objectAttributes.Add(Settings.Factories.ObjectAttributeFactory.CreateObjectAttribute(CKA.CKA_ENCRYPT, true));
                        objectAttributes.Add(Settings.Factories.ObjectAttributeFactory.CreateObjectAttribute(CKA.CKA_DECRYPT, true));
                        objectAttributes.Add(Settings.Factories.ObjectAttributeFactory.CreateObjectAttribute(CKA.CKA_WRAP, true));
                        objectAttributes.Add(Settings.Factories.ObjectAttributeFactory.CreateObjectAttribute(CKA.CKA_UNWRAP, true));
                        objectAttributes.Add(Settings.Factories.ObjectAttributeFactory.CreateObjectAttribute(CKA.CKA_EXTRACTABLE, true));

                        // Specify key generation mechanism
                        IMechanism mechanism = Settings.Factories.MechanismFactory.CreateMechanism(keyType);

                        // Generate key
                        IObjectHandle secret_key = session.GenerateKey(mechanism, objectAttributes);

                        /****************** Compute KCV ***********************************/
                        byte[] iv = new byte[8];

                        //IMechanism mechanism_wrap_encrypt_decrypt = Settings.Factories.MechanismFactory.CreateMechanism(keyType == CKM.CKM_DES_KEY_GEN ? CKM.CKM_DES_ECB : CKM.CKM_DES3_ECB);

                        IMechanism mechanism_wrap_encrypt_decrypt = Settings.Factories.MechanismFactory.CreateMechanism(keyType == CKM.CKM_DES_KEY_GEN ? CKM.CKM_DES_ECB : CKM.CKM_DES3_ECB);

                        // Encrypt data
                        byte[] kcvBytes = session.Encrypt(mechanism_wrap_encrypt_decrypt, secret_key, iv);

                        // Do something interesting with generated key

                        /****************** WRAP Key ***********************************/
                        IObjectHandle hLMKKey = findAKeyObject(Configurations.LMK_KEYNAME, session);

                        // Wrap key
                        byte[] wrappedKeyBytes = session.WrapKey(mechanism_wrap_encrypt_decrypt, hLMKKey, secret_key);

                        // Do something interesting with wrapped key
                        if (wrappedKeyBytes == null)
                            throw new Exception("Fail wrapping key");

                        /****************** Get Clear Key ***********************************/

                        // Wrap key
                        byte[] clearKeyBytes = session.Decrypt(mechanism_wrap_encrypt_decrypt, hLMKKey, wrappedKeyBytes);

                        // Do something interesting with wrapped key
                        if (clearKeyBytes == null)
                            throw new Exception("Fail getting clear key");

                        /****************** RETURN WRAPPED Key + KCV ***********************************/

                        kek = new KekKey();
                        kek.KeyValueClear = HelperFunctions.ByteArrayToString(clearKeyBytes);
                        kek.KeyKCV = HelperFunctions.ByteArrayToString(kcvBytes).Substring(0, 6);
                        kek.KeyValueEncryptedUnderLMK = HelperFunctions.ByteArrayToString(wrappedKeyBytes);

                        // Destroy object
                        session.DestroyObject(secret_key);
                        session.Logout();

                        return kek;
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                throw ex;
            }
        }

        //Generate LMK key and return wrapped key
        public static string[] doGenerateLMKReturnWrappedKey()
        {
            using (IPkcs11 pkcs11 = Settings.Factories.Pkcs11Factory.CreatePkcs11(Settings.Factories, Configurations.Pkcs11LibraryPath, Settings.AppType))
            {
                // Find first slot with token present
                ISlot slot = Helpers.GetUsableSlot(pkcs11, Configurations.default_slot);

                // Open RW session
                using (Net.Pkcs11Interop.HighLevelAPI.ISession session = slot.OpenSession(SessionType.ReadWrite))
                {
                    // Login as normal user
                    session.Login(Configurations.user_type, Configurations.hsm_password);

                    IObjectHandle keyObj = findAKeyObject(Configurations.LMK_KEYNAME, session);

                    if (keyObj != null) //already exists
                    {
                        session.Logout();

                        return null;
                    }

                    // Prepare attribute template of new key
                    List<IObjectAttribute> objectAttributes = new List<IObjectAttribute>();
                    objectAttributes.Add(Settings.Factories.ObjectAttributeFactory.CreateObjectAttribute(CKA.CKA_TOKEN, true)); // stored in token
                    objectAttributes.Add(Settings.Factories.ObjectAttributeFactory.CreateObjectAttribute(CKA.CKA_CLASS, CKO.CKO_SECRET_KEY));
                    objectAttributes.Add(Settings.Factories.ObjectAttributeFactory.CreateObjectAttribute(CKA.CKA_LABEL, Configurations.LMK_KEYNAME));
                    objectAttributes.Add(Settings.Factories.ObjectAttributeFactory.CreateObjectAttribute(CKA.CKA_ENCRYPT, true));
                    objectAttributes.Add(Settings.Factories.ObjectAttributeFactory.CreateObjectAttribute(CKA.CKA_DECRYPT, true));
                    objectAttributes.Add(Settings.Factories.ObjectAttributeFactory.CreateObjectAttribute(CKA.CKA_WRAP, true));
                    objectAttributes.Add(Settings.Factories.ObjectAttributeFactory.CreateObjectAttribute(CKA.CKA_UNWRAP, true));
                    objectAttributes.Add(Settings.Factories.ObjectAttributeFactory.CreateObjectAttribute(CKA.CKA_KEY_TYPE, CKK.CKK_DES3));

                    // Specify key generation mechanism
                    IMechanism mechanism = Settings.Factories.MechanismFactory.CreateMechanism(CKM.CKM_DES3_KEY_GEN);

                    // Generate key
                    IObjectHandle secret_key = session.GenerateKey(mechanism, objectAttributes);

                    /****************** Compute KCV ***********************************/
                    byte[] iv = new byte[8];

                    IMechanism mechanism_wrap_encrypt_decrypt = Settings.Factories.MechanismFactory.CreateMechanism(CKM.CKM_DES3_ECB);

                    // Encrypt data
                    byte[] kcvBytes = session.Encrypt(mechanism_wrap_encrypt_decrypt, secret_key, iv);


                    /****************** WRAP Key ***********************************/

                    // Prepare attribute template of new key
                    List<IObjectAttribute> objectAttributes_wrapper_key = new List<IObjectAttribute>();
                    objectAttributes_wrapper_key.Add(Settings.Factories.ObjectAttributeFactory.CreateObjectAttribute(CKA.CKA_TOKEN, false)); //not stored in token
                    objectAttributes_wrapper_key.Add(Settings.Factories.ObjectAttributeFactory.CreateObjectAttribute(CKA.CKA_CLASS, CKO.CKO_SECRET_KEY));
                    objectAttributes_wrapper_key.Add(Settings.Factories.ObjectAttributeFactory.CreateObjectAttribute(CKA.CKA_KEY_TYPE, CKK.CKK_DES3));
                    //objectAttributes_wrapper_key.Add(Settings.Factories.ObjectAttributeFactory.CreateObjectAttribute(CKA.CKA_ENCRYPT, true));
                    objectAttributes_wrapper_key.Add(Settings.Factories.ObjectAttributeFactory.CreateObjectAttribute(CKA.CKA_DECRYPT, true));
                    //objectAttributes_wrapper_key.Add(Settings.Factories.ObjectAttributeFactory.CreateObjectAttribute(CKA.CKA_DERIVE, true));
                    //objectAttributes_wrapper_key.Add(Settings.Factories.ObjectAttributeFactory.CreateObjectAttribute(CKA.CKA_EXTRACTABLE, true));
                    objectAttributes_wrapper_key.Add(Settings.Factories.ObjectAttributeFactory.CreateObjectAttribute(CKA.CKA_WRAP, true));
                    //objectAttributes_wrapper_key.Add(Settings.Factories.ObjectAttributeFactory.CreateObjectAttribute(CKA.CKA_UNWRAP, true));

                    // Generate symmetric wrapper key
                    IObjectHandle wrapper_key = session.GenerateKey(mechanism, objectAttributes_wrapper_key);

                    // Wrap key
                    byte[] wrappedKeyBytes = session.WrapKey(mechanism_wrap_encrypt_decrypt, wrapper_key, secret_key);

                    // Do something interesting with wrapped key
                    if (wrappedKeyBytes == null)
                        throw new Exception("Fail wrapping key");

                    /****************** RETURN WRAPPED Key ***********************************/
                    string[] result = new string[2];
                    result[0] = HelperFunctions.ByteArrayToString(wrappedKeyBytes);
                    result[1] = HelperFunctions.ByteArrayToString(kcvBytes).Substring(0, 6);

                    // Destroy object
                    session.DestroyObject(wrapper_key);
                    session.Logout();

                    return result;
                }
            }
        }

        //Generate LMK key and return wrapped key
        public static string[] doGenerateLMKReturnClearKey()
        {
            using (IPkcs11 pkcs11 = Settings.Factories.Pkcs11Factory.CreatePkcs11(Settings.Factories, Configurations.Pkcs11LibraryPath, Settings.AppType))
            {
                // Find first slot with token present
                ISlot slot = Helpers.GetUsableSlot(pkcs11, Configurations.default_slot);

                // Open RW session
                using (Net.Pkcs11Interop.HighLevelAPI.ISession session = slot.OpenSession(SessionType.ReadWrite))
                {
                    // Login as normal user
                    session.Login(Configurations.user_type, Configurations.hsm_password);

                    IObjectHandle keyObj = findAKeyObject(Configurations.LMK_KEYNAME, session);

                    if (keyObj != null) //already exists
                    {
                        session.Logout();

                        return null;
                    }

                    // Prepare attribute template of new key
                    List<IObjectAttribute> objectAttributes = new List<IObjectAttribute>();
                    objectAttributes.Add(Settings.Factories.ObjectAttributeFactory.CreateObjectAttribute(CKA.CKA_TOKEN, true)); // stored in token
                    objectAttributes.Add(Settings.Factories.ObjectAttributeFactory.CreateObjectAttribute(CKA.CKA_CLASS, CKO.CKO_SECRET_KEY));
                    objectAttributes.Add(Settings.Factories.ObjectAttributeFactory.CreateObjectAttribute(CKA.CKA_LABEL, Configurations.LMK_KEYNAME));
                    objectAttributes.Add(Settings.Factories.ObjectAttributeFactory.CreateObjectAttribute(CKA.CKA_ENCRYPT, true));
                    objectAttributes.Add(Settings.Factories.ObjectAttributeFactory.CreateObjectAttribute(CKA.CKA_DECRYPT, true));
                    objectAttributes.Add(Settings.Factories.ObjectAttributeFactory.CreateObjectAttribute(CKA.CKA_WRAP, true));
                    objectAttributes.Add(Settings.Factories.ObjectAttributeFactory.CreateObjectAttribute(CKA.CKA_UNWRAP, true));
                    objectAttributes.Add(Settings.Factories.ObjectAttributeFactory.CreateObjectAttribute(CKA.CKA_KEY_TYPE, CKK.CKK_DES3));

                    // Specify key generation mechanism
                    IMechanism mechanism = Settings.Factories.MechanismFactory.CreateMechanism(CKM.CKM_DES3_KEY_GEN);

                    // Generate key
                    IObjectHandle secret_key = session.GenerateKey(mechanism, objectAttributes);

                    /****************** Compute KCV ***********************************/
                    byte[] iv = new byte[8];

                    IMechanism mechanism_wrap_encrypt_decrypt = Settings.Factories.MechanismFactory.CreateMechanism(CKM.CKM_DES3_ECB);

                    // Encrypt data
                    byte[] kcvBytes = session.Encrypt(mechanism_wrap_encrypt_decrypt, secret_key, iv);


                    /****************** WRAP Key ***********************************/

                    // Prepare attribute template of new key
                    List<IObjectAttribute> objectAttributes_wrapper_key = new List<IObjectAttribute>();
                    objectAttributes_wrapper_key.Add(Settings.Factories.ObjectAttributeFactory.CreateObjectAttribute(CKA.CKA_TOKEN, false)); //not stored in token
                    objectAttributes_wrapper_key.Add(Settings.Factories.ObjectAttributeFactory.CreateObjectAttribute(CKA.CKA_CLASS, CKO.CKO_SECRET_KEY));
                    objectAttributes_wrapper_key.Add(Settings.Factories.ObjectAttributeFactory.CreateObjectAttribute(CKA.CKA_KEY_TYPE, CKK.CKK_DES3));
                    //objectAttributes_wrapper_key.Add(Settings.Factories.ObjectAttributeFactory.CreateObjectAttribute(CKA.CKA_ENCRYPT, true));
                    objectAttributes_wrapper_key.Add(Settings.Factories.ObjectAttributeFactory.CreateObjectAttribute(CKA.CKA_DECRYPT, true));
                    //objectAttributes_wrapper_key.Add(Settings.Factories.ObjectAttributeFactory.CreateObjectAttribute(CKA.CKA_DERIVE, true));
                    //objectAttributes_wrapper_key.Add(Settings.Factories.ObjectAttributeFactory.CreateObjectAttribute(CKA.CKA_EXTRACTABLE, true));
                    objectAttributes_wrapper_key.Add(Settings.Factories.ObjectAttributeFactory.CreateObjectAttribute(CKA.CKA_WRAP, true));
                    //objectAttributes_wrapper_key.Add(Settings.Factories.ObjectAttributeFactory.CreateObjectAttribute(CKA.CKA_UNWRAP, true));

                    // Generate symmetric wrapper key
                    IObjectHandle wrapper_key = session.GenerateKey(mechanism, objectAttributes_wrapper_key);

                    // Wrap key
                    byte[] wrappedKeyBytes = session.WrapKey(mechanism_wrap_encrypt_decrypt, wrapper_key, secret_key);

                    // Do something interesting with wrapped key
                    if (wrappedKeyBytes == null)
                        throw new Exception("Fail wrapping key");

                    /****************** DECRYPT Key ***********************************/

                    byte[] decryptedData = session.Decrypt(mechanism_wrap_encrypt_decrypt, wrapper_key, wrappedKeyBytes);

                    /****************** RETURN CLEAR Key ***********************************/
                    string[] result = new string[2];
                    result[0] = HelperFunctions.ByteArrayToString(decryptedData);
                    result[1] = HelperFunctions.ByteArrayToString(kcvBytes).Substring(0, 6);

                    // Destroy object
                    session.DestroyObject(wrapper_key);
                    session.Logout();

                    return result;
                }
            }
        }

        public static RsaKey doGenerateKeyPairReturnClearRSAKey(string lengthInBitsStr, string publicModulus)
        {
            byte[] pubMod = HelperFunctions.StringToByteArray(publicModulus);
            ulong lengthInBits = Convert.ToUInt32(lengthInBitsStr);

            RsaKey result = null;

            try
            {
                using (IPkcs11 pkcs11 = Settings.Factories.Pkcs11Factory.CreatePkcs11(Settings.Factories, Configurations.Pkcs11LibraryPath, Settings.AppType))
                {
                    // Find first slot with token present
                    ISlot slot = Helpers.GetUsableSlot(pkcs11, Configurations.default_slot);

                    // Open RW session
                    using (ISession session = slot.OpenSession(SessionType.ReadWrite))
                    {
                        // Login as normal user
                        session.Login(Configurations.user_type, Configurations.hsm_password);

                        // The CKA_ID attribute is intended as a means of distinguishing multiple key pairs held by the same subject
                        byte[] ckaId = session.GenerateRandom(20);

                        // Prepare attribute template of new public key
                        List<IObjectAttribute> publicKeyAttributes = new List<IObjectAttribute>();
                        publicKeyAttributes.Add(Settings.Factories.ObjectAttributeFactory.CreateObjectAttribute(CKA.CKA_TOKEN, false));
                        publicKeyAttributes.Add(Settings.Factories.ObjectAttributeFactory.CreateObjectAttribute(CKA.CKA_PRIVATE, false));
                        publicKeyAttributes.Add(Settings.Factories.ObjectAttributeFactory.CreateObjectAttribute(CKA.CKA_LABEL, Settings.ApplicationName));
                        publicKeyAttributes.Add(Settings.Factories.ObjectAttributeFactory.CreateObjectAttribute(CKA.CKA_ID, ckaId));
                        publicKeyAttributes.Add(Settings.Factories.ObjectAttributeFactory.CreateObjectAttribute(CKA.CKA_ENCRYPT, true));
                        publicKeyAttributes.Add(Settings.Factories.ObjectAttributeFactory.CreateObjectAttribute(CKA.CKA_VERIFY, true));
                        publicKeyAttributes.Add(Settings.Factories.ObjectAttributeFactory.CreateObjectAttribute(CKA.CKA_VERIFY_RECOVER, true));
                        publicKeyAttributes.Add(Settings.Factories.ObjectAttributeFactory.CreateObjectAttribute(CKA.CKA_WRAP, true));
                        publicKeyAttributes.Add(Settings.Factories.ObjectAttributeFactory.CreateObjectAttribute(CKA.CKA_MODULUS_BITS, lengthInBits));
                        publicKeyAttributes.Add(Settings.Factories.ObjectAttributeFactory.CreateObjectAttribute(CKA.CKA_PUBLIC_EXPONENT, pubMod));

                        // Prepare attribute template of new private key
                        List<IObjectAttribute> privateKeyAttributes = new List<IObjectAttribute>();
                        privateKeyAttributes.Add(Settings.Factories.ObjectAttributeFactory.CreateObjectAttribute(CKA.CKA_TOKEN, false));
                        privateKeyAttributes.Add(Settings.Factories.ObjectAttributeFactory.CreateObjectAttribute(CKA.CKA_PRIVATE, true));
                        privateKeyAttributes.Add(Settings.Factories.ObjectAttributeFactory.CreateObjectAttribute(CKA.CKA_LABEL, Settings.ApplicationName));
                        privateKeyAttributes.Add(Settings.Factories.ObjectAttributeFactory.CreateObjectAttribute(CKA.CKA_ID, ckaId));
                        privateKeyAttributes.Add(Settings.Factories.ObjectAttributeFactory.CreateObjectAttribute(CKA.CKA_SENSITIVE, true));
                        privateKeyAttributes.Add(Settings.Factories.ObjectAttributeFactory.CreateObjectAttribute(CKA.CKA_DECRYPT, true));
                        privateKeyAttributes.Add(Settings.Factories.ObjectAttributeFactory.CreateObjectAttribute(CKA.CKA_SIGN, true));
                        privateKeyAttributes.Add(Settings.Factories.ObjectAttributeFactory.CreateObjectAttribute(CKA.CKA_SIGN_RECOVER, true));
                        privateKeyAttributes.Add(Settings.Factories.ObjectAttributeFactory.CreateObjectAttribute(CKA.CKA_UNWRAP, true));

                        // Specify key generation mechanism
                        IMechanism mechanism = Settings.Factories.MechanismFactory.CreateMechanism(CKM.CKM_RSA_PKCS_KEY_PAIR_GEN);

                        // Generate key pair
                        IObjectHandle publicKeyHandle = null;
                        IObjectHandle privateKeyHandle = null;
                        session.GenerateKeyPair(mechanism, publicKeyAttributes, privateKeyAttributes, out publicKeyHandle, out privateKeyHandle);

                        /****************** WRAP Key ***********************************/
                        // Specify wrapping mechanism
                        IMechanism mechanism_wrap = Settings.Factories.MechanismFactory.CreateMechanism(CKM.CKM_DES3_ECB);

                        // Prepare attribute template of new key
                        List<IObjectAttribute> objectAttributes_wrapper_key = new List<IObjectAttribute>();
                        objectAttributes_wrapper_key.Add(Settings.Factories.ObjectAttributeFactory.CreateObjectAttribute(CKA.CKA_TOKEN, false)); //not stored in token
                        objectAttributes_wrapper_key.Add(Settings.Factories.ObjectAttributeFactory.CreateObjectAttribute(CKA.CKA_CLASS, CKO.CKO_SECRET_KEY));
                        objectAttributes_wrapper_key.Add(Settings.Factories.ObjectAttributeFactory.CreateObjectAttribute(CKA.CKA_KEY_TYPE, CKK.CKK_DES3));
                        //objectAttributes_wrapper_key.Add(Settings.Factories.ObjectAttributeFactory.CreateObjectAttribute(CKA.CKA_ENCRYPT, true));
                        objectAttributes_wrapper_key.Add(Settings.Factories.ObjectAttributeFactory.CreateObjectAttribute(CKA.CKA_DECRYPT, true));
                        //objectAttributes_wrapper_key.Add(Settings.Factories.ObjectAttributeFactory.CreateObjectAttribute(CKA.CKA_DERIVE, true));
                        //objectAttributes_wrapper_key.Add(Settings.Factories.ObjectAttributeFactory.CreateObjectAttribute(CKA.CKA_EXTRACTABLE, true));
                        objectAttributes_wrapper_key.Add(Settings.Factories.ObjectAttributeFactory.CreateObjectAttribute(CKA.CKA_WRAP, true));
                        //objectAttributes_wrapper_key.Add(Settings.Factories.ObjectAttributeFactory.CreateObjectAttribute(CKA.CKA_UNWRAP, true));

                        IObjectHandle hLMKKey = findAKeyObject(Configurations.LMK_KEYNAME, session);

                        // Wrap key
                        byte[] wrappedPublicKeyBytes = session.WrapKey(mechanism_wrap, hLMKKey, publicKeyHandle);
                        byte[] wrappedPrivateKeyBytes = session.WrapKey(mechanism_wrap, hLMKKey, privateKeyHandle);

                        // Do something interesting with wrapped key
                        if (wrappedPublicKeyBytes == null || wrappedPrivateKeyBytes == null)
                            throw new Exception("Fail wrapping key");

                        // Decrypt data
                        byte[] decryptedPrivateKeyBytes = session.Decrypt(mechanism_wrap, hLMKKey, wrappedPrivateKeyBytes);
                        byte[] decryptedPublicKeyBytes = session.Decrypt(mechanism_wrap, hLMKKey, wrappedPublicKeyBytes);

                        byte[] decryptedPrivateKeyBytesClean = WpfApp1.Crypto.DESCryptoLib2018.RemoveZeroTrailer(decryptedPrivateKeyBytes);
                        byte[] decryptedPublicKeyBytesClean = WpfApp1.Crypto.DESCryptoLib2018.RemoveZeroTrailer(decryptedPublicKeyBytes);

                        var obj = Asn1Sequence.FromByteArray(decryptedPrivateKeyBytesClean);
                        Asn1Sequence seq = Asn1Sequence.GetInstance(obj);
                        Asn1OctetString obcSeq = (Asn1OctetString)seq[2];
                        byte[] octByte = obcSeq.GetOctets();

                        Asn1Object octObj = Asn1Sequence.FromByteArray(octByte);
                        Asn1Sequence seqPrivKey = Asn1Sequence.GetInstance(octObj);

                        RsaPrivateKeyStructure rsaPrivKey = RsaPrivateKeyStructure.GetInstance(seqPrivKey);
                        RsaKey rsa = new RsaKey();
                        rsa.publicModulus = WpfApp1.Crypto.DESCryptoLib2018.RemoveZeroHead(rsaPrivKey.Modulus.ToByteArray());
                        rsa.publicExponent = WpfApp1.Crypto.DESCryptoLib2018.RemoveZeroHead(rsaPrivKey.PublicExponent.ToByteArray());
                        rsa.privateExponent = rsaPrivKey.PrivateExponent.ToByteArray();
                        rsa.prime1 = WpfApp1.Crypto.DESCryptoLib2018.RemoveZeroHead(rsaPrivKey.Prime1.ToByteArray());
                        rsa.prime2 = WpfApp1.Crypto.DESCryptoLib2018.RemoveZeroHead(rsaPrivKey.Prime2.ToByteArray());
                        rsa.exponent1 = WpfApp1.Crypto.DESCryptoLib2018.RemoveZeroHead(rsaPrivKey.Exponent1.ToByteArray());
                        rsa.exponent2 = WpfApp1.Crypto.DESCryptoLib2018.RemoveZeroHead(rsaPrivKey.Exponent2.ToByteArray());
                        rsa.coefficient = WpfApp1.Crypto.DESCryptoLib2018.RemoveZeroHead(rsaPrivKey.Coefficient.ToByteArray());
                        rsa.asn1PubKey = WpfApp1.Crypto.DESCryptoLib2018.RemoveZeroHead(decryptedPublicKeyBytesClean);
                        rsa.asn1PrivKey = WpfApp1.Crypto.DESCryptoLib2018.RemoveZeroHead(decryptedPrivateKeyBytesClean);

                        // Destroy keys
                        session.DestroyObject(publicKeyHandle);
                        session.DestroyObject(privateKeyHandle);

                        session.Logout();

                        return rsa;
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                throw ex;
            }

        }


        public static string[] doGenerateKeyPairReturnClear(string lengthInBitsStr, string publicModulus)
        {
            byte[] pubMod = HelperFunctions.StringToByteArray(publicModulus);
            ulong lengthInBits = Convert.ToUInt32(lengthInBitsStr);

            using (IPkcs11 pkcs11 = Settings.Factories.Pkcs11Factory.CreatePkcs11(Settings.Factories, Configurations.Pkcs11LibraryPath, Settings.AppType))
            {
                // Find first slot with token present
                ISlot slot = Helpers.GetUsableSlot(pkcs11, Configurations.default_slot);

                // Open RW session
                using (ISession session = slot.OpenSession(SessionType.ReadWrite))
                {
                    // Login as normal user
                    session.Login(Configurations.user_type, Configurations.hsm_password);

                    // The CKA_ID attribute is intended as a means of distinguishing multiple key pairs held by the same subject
                    byte[] ckaId = session.GenerateRandom(20);

                    // Prepare attribute template of new public key
                    List<IObjectAttribute> publicKeyAttributes = new List<IObjectAttribute>();
                    publicKeyAttributes.Add(Settings.Factories.ObjectAttributeFactory.CreateObjectAttribute(CKA.CKA_TOKEN, false));
                    publicKeyAttributes.Add(Settings.Factories.ObjectAttributeFactory.CreateObjectAttribute(CKA.CKA_PRIVATE, false));
                    publicKeyAttributes.Add(Settings.Factories.ObjectAttributeFactory.CreateObjectAttribute(CKA.CKA_LABEL, Settings.ApplicationName));
                    publicKeyAttributes.Add(Settings.Factories.ObjectAttributeFactory.CreateObjectAttribute(CKA.CKA_ID, ckaId));
                    publicKeyAttributes.Add(Settings.Factories.ObjectAttributeFactory.CreateObjectAttribute(CKA.CKA_ENCRYPT, true));
                    publicKeyAttributes.Add(Settings.Factories.ObjectAttributeFactory.CreateObjectAttribute(CKA.CKA_VERIFY, true));
                    publicKeyAttributes.Add(Settings.Factories.ObjectAttributeFactory.CreateObjectAttribute(CKA.CKA_VERIFY_RECOVER, true));
                    publicKeyAttributes.Add(Settings.Factories.ObjectAttributeFactory.CreateObjectAttribute(CKA.CKA_WRAP, true));
                    publicKeyAttributes.Add(Settings.Factories.ObjectAttributeFactory.CreateObjectAttribute(CKA.CKA_MODULUS_BITS, lengthInBits));
                    publicKeyAttributes.Add(Settings.Factories.ObjectAttributeFactory.CreateObjectAttribute(CKA.CKA_PUBLIC_EXPONENT, pubMod));

                    // Prepare attribute template of new private key
                    List<IObjectAttribute> privateKeyAttributes = new List<IObjectAttribute>();
                    privateKeyAttributes.Add(Settings.Factories.ObjectAttributeFactory.CreateObjectAttribute(CKA.CKA_TOKEN, false));
                    privateKeyAttributes.Add(Settings.Factories.ObjectAttributeFactory.CreateObjectAttribute(CKA.CKA_PRIVATE, true));
                    privateKeyAttributes.Add(Settings.Factories.ObjectAttributeFactory.CreateObjectAttribute(CKA.CKA_LABEL, Settings.ApplicationName));
                    privateKeyAttributes.Add(Settings.Factories.ObjectAttributeFactory.CreateObjectAttribute(CKA.CKA_ID, ckaId));
                    privateKeyAttributes.Add(Settings.Factories.ObjectAttributeFactory.CreateObjectAttribute(CKA.CKA_SENSITIVE, true));
                    privateKeyAttributes.Add(Settings.Factories.ObjectAttributeFactory.CreateObjectAttribute(CKA.CKA_DECRYPT, true));
                    privateKeyAttributes.Add(Settings.Factories.ObjectAttributeFactory.CreateObjectAttribute(CKA.CKA_SIGN, true));
                    privateKeyAttributes.Add(Settings.Factories.ObjectAttributeFactory.CreateObjectAttribute(CKA.CKA_SIGN_RECOVER, true));
                    privateKeyAttributes.Add(Settings.Factories.ObjectAttributeFactory.CreateObjectAttribute(CKA.CKA_UNWRAP, true));

                    // Specify key generation mechanism
                    IMechanism mechanism = Settings.Factories.MechanismFactory.CreateMechanism(CKM.CKM_RSA_PKCS_KEY_PAIR_GEN);

                    // Generate key pair
                    IObjectHandle publicKeyHandle = null;
                    IObjectHandle privateKeyHandle = null;
                    session.GenerateKeyPair(mechanism, publicKeyAttributes, privateKeyAttributes, out publicKeyHandle, out privateKeyHandle);

                    /****************** WRAP Key ***********************************/
                    IMechanism mechanism_key_gen = Settings.Factories.MechanismFactory.CreateMechanism(CKM.CKM_DES3_KEY_GEN);
                    // Specify wrapping mechanism
                    IMechanism mechanism_wrap_decrypt = Settings.Factories.MechanismFactory.CreateMechanism(CKM.CKM_DES3_ECB);

                    // Prepare attribute template of new key
                    List<IObjectAttribute> objectAttributes_wrapper_key = new List<IObjectAttribute>();
                    objectAttributes_wrapper_key.Add(Settings.Factories.ObjectAttributeFactory.CreateObjectAttribute(CKA.CKA_TOKEN, false)); //not stored in token
                    objectAttributes_wrapper_key.Add(Settings.Factories.ObjectAttributeFactory.CreateObjectAttribute(CKA.CKA_CLASS, CKO.CKO_SECRET_KEY));
                    objectAttributes_wrapper_key.Add(Settings.Factories.ObjectAttributeFactory.CreateObjectAttribute(CKA.CKA_KEY_TYPE, CKK.CKK_DES3));
                    //objectAttributes_wrapper_key.Add(Settings.Factories.ObjectAttributeFactory.CreateObjectAttribute(CKA.CKA_ENCRYPT, true));
                    objectAttributes_wrapper_key.Add(Settings.Factories.ObjectAttributeFactory.CreateObjectAttribute(CKA.CKA_DECRYPT, true));
                    //objectAttributes_wrapper_key.Add(Settings.Factories.ObjectAttributeFactory.CreateObjectAttribute(CKA.CKA_DERIVE, true));
                    //objectAttributes_wrapper_key.Add(Settings.Factories.ObjectAttributeFactory.CreateObjectAttribute(CKA.CKA_EXTRACTABLE, true));
                    objectAttributes_wrapper_key.Add(Settings.Factories.ObjectAttributeFactory.CreateObjectAttribute(CKA.CKA_WRAP, true));
                    //objectAttributes_wrapper_key.Add(Settings.Factories.ObjectAttributeFactory.CreateObjectAttribute(CKA.CKA_UNWRAP, true));

                    // Generate symmetric wrapper key
                    IObjectHandle wrapper_key = session.GenerateKey(mechanism_key_gen, objectAttributes_wrapper_key);

                    // Wrap key
                    byte[] wrappedPublicKeyBytes = session.WrapKey(mechanism_wrap_decrypt, wrapper_key, publicKeyHandle);
                    byte[] wrappedPrivateKeyBytes = session.WrapKey(mechanism_wrap_decrypt, wrapper_key, privateKeyHandle);

                    // Do something interesting with wrapped key
                    if (wrappedPublicKeyBytes == null || wrappedPrivateKeyBytes == null)
                        throw new Exception("Fail wrapping key");

                    // Decrypt data
                    byte[] decryptedPubKeyBytes = session.Decrypt(mechanism_wrap_decrypt, wrapper_key, wrappedPublicKeyBytes);
                    byte[] decryptedPrivKeyBytes = session.Decrypt(mechanism_wrap_decrypt, wrapper_key, wrappedPrivateKeyBytes);

                    // Destroy keys
                    session.DestroyObject(wrapper_key);
                    session.DestroyObject(publicKeyHandle);
                    session.DestroyObject(privateKeyHandle);

                    session.Logout();

                    string[] result = new string[2];
                    result[0] = HelperFunctions.ByteArrayToString(decryptedPubKeyBytes);
                    result[1] = HelperFunctions.ByteArrayToString(decryptedPrivKeyBytes);

                    return result;
                }
            }
        }

        private static IObjectHandle getUnwrappedKeyFromWrappedKey(byte[] WrappedKey, String keyNameInHsm = Configurations.LMK_KEYNAME)
        {
            IObjectHandle theKey = null;

            using (IPkcs11 pkcs11 = Settings.Factories.Pkcs11Factory.CreatePkcs11(Settings.Factories, Configurations.Pkcs11LibraryPath, Settings.AppType))
            {
                // Find first slot with token present
                ISlot slot = Helpers.GetUsableSlot(pkcs11, Configurations.default_slot);

                // Open RW session
                using (ISession session = slot.OpenSession(SessionType.ReadWrite))
                {
                    // Login as normal user
                    session.Login(Configurations.user_type, Configurations.hsm_password);

                    IObjectHandle lmkKey = findAKeyObject(Configurations.LMK_KEYNAME, session);

                    IMechanism mechanism_wrap_encrypt_decrypt = Settings.Factories.MechanismFactory.CreateMechanism(CKM.CKM_DES3_ECB);

                    // Prepare attribute template of new key
                    List<IObjectAttribute> objectAttributes = new List<IObjectAttribute>();
                    objectAttributes.Add(Settings.Factories.ObjectAttributeFactory.CreateObjectAttribute(CKA.CKA_TOKEN, true)); // stored in token
                    objectAttributes.Add(Settings.Factories.ObjectAttributeFactory.CreateObjectAttribute(CKA.CKA_CLASS, CKO.CKO_SECRET_KEY));
                    objectAttributes.Add(Settings.Factories.ObjectAttributeFactory.CreateObjectAttribute(CKA.CKA_LABEL, Configurations.LMK_KEYNAME));
                    objectAttributes.Add(Settings.Factories.ObjectAttributeFactory.CreateObjectAttribute(CKA.CKA_ENCRYPT, true));
                    objectAttributes.Add(Settings.Factories.ObjectAttributeFactory.CreateObjectAttribute(CKA.CKA_DECRYPT, true));
                    objectAttributes.Add(Settings.Factories.ObjectAttributeFactory.CreateObjectAttribute(CKA.CKA_WRAP, true));
                    objectAttributes.Add(Settings.Factories.ObjectAttributeFactory.CreateObjectAttribute(CKA.CKA_UNWRAP, true));
                    objectAttributes.Add(Settings.Factories.ObjectAttributeFactory.CreateObjectAttribute(CKA.CKA_EXTRACTABLE, true));
                    objectAttributes.Add(Settings.Factories.ObjectAttributeFactory.CreateObjectAttribute(CKA.CKA_SENSITIVE, false));
                    objectAttributes.Add(Settings.Factories.ObjectAttributeFactory.CreateObjectAttribute(CKA.CKA_KEY_TYPE, CKK.CKK_DES3));

                    // Do Unwrap key
                    theKey = session.UnwrapKey(mechanism_wrap_encrypt_decrypt, lmkKey, WrappedKey, objectAttributes);

                    // Destroy keys
                    session.Logout();
                }
            }

            return theKey;
        }

        public static string safnetGenRandomString(int strLen)
        {
            byte[] random = null;

            using (IPkcs11 pkcs11 = Settings.Factories.Pkcs11Factory.CreatePkcs11(Settings.Factories, Configurations.Pkcs11LibraryPath, Settings.AppType))
            {
                // Find first slot with token present
                // Find first slot with token present
                ISlot slot = Helpers.GetUsableSlot(pkcs11, Configurations.default_slot);

                // Open RW session
                using (ISession session = slot.OpenSession(SessionType.ReadWrite))
                {
                    // Mix additional seed material into the token's random number generator
                    byte[] seed = ConvertUtils.Utf8StringToBytes(DateTime.Now.ToString("h:mm:ss tt"));
                    session.SeedRandom(seed);

                    random = new byte[strLen];
                    random = session.GenerateRandom(strLen);
                }
            }

            return HelperFunctions.ByteArrayToString(random);
        }

        public static byte[] safenetGenRandomBytes(int strLen)
        {
            byte[] random = null;

            using (IPkcs11 pkcs11 = Settings.Factories.Pkcs11Factory.CreatePkcs11(Settings.Factories, Configurations.Pkcs11LibraryPath, Settings.AppType))
            {
                // Find first slot with token present
                // Find first slot with token present
                ISlot slot = Helpers.GetUsableSlot(pkcs11, Configurations.default_slot);

                // Open RW session
                using (ISession session = slot.OpenSession(SessionType.ReadWrite))
                {
                    // Mix additional seed material into the token's random number generator
                    byte[] seed = ConvertUtils.Utf8StringToBytes(DateTime.Now.ToString("h:mm:ss tt"));
                    session.SeedRandom(seed);

                    random = new byte[strLen];
                    random = session.GenerateRandom(strLen);
                }
            }

            return random;
        }


        // wrap a clear key value (string) under LMK
        public static string importClear3DesKeyValueAndWrapUnderLMK(string plainKeyValue, string keyKCV)
        {
            using (IPkcs11 pkcs11 = Settings.Factories.Pkcs11Factory.CreatePkcs11(Settings.Factories, Configurations.Pkcs11LibraryPath, Settings.AppType))
            {
                // Find first slot with token present
                ISlot slot = Helpers.GetUsableSlot(pkcs11, Configurations.default_slot);

                // Open RW session
                using (Net.Pkcs11Interop.HighLevelAPI.ISession session = slot.OpenSession(SessionType.ReadWrite))
                {
                    // Login as normal user
                    session.Login(Configurations.user_type, Configurations.hsm_password);

                    byte[] plainKeyValueBytes = Common.HelperFunctions.StringToByteArray(plainKeyValue);

                    CKK keyType;
                    CKM keyTypeCKM;

                    if (plainKeyValue.Length == 8 * 2 * 3)
                    {
                        keyType = CKK.CKK_DES3;
                        keyTypeCKM = CKM.CKM_DES3_ECB;
                    }
                    else if (plainKeyValue.Length == 8 * 2 * 2)
                    {
                        keyType = CKK.CKK_DES2;
                        keyTypeCKM = CKM.CKM_DES3_ECB;
                    }
                    else if (plainKeyValue.Length == 8 * 2)
                    {
                        keyType = CKK.CKK_DES;
                        keyTypeCKM = CKM.CKM_DES_ECB;
                    }
                    else
                        throw new Exception("Wrong Key Length");
                    
                    List<IObjectAttribute> objectAttributes = new List<IObjectAttribute>();
                    objectAttributes.Add(Settings.Factories.ObjectAttributeFactory.CreateObjectAttribute(CKA.CKA_TOKEN, false)); //not stored in token
                    objectAttributes.Add(Settings.Factories.ObjectAttributeFactory.CreateObjectAttribute(CKA.CKA_CLASS, CKO.CKO_SECRET_KEY));
                    objectAttributes.Add(Settings.Factories.ObjectAttributeFactory.CreateObjectAttribute(CKA.CKA_KEY_TYPE, keyType));
                    objectAttributes.Add(Settings.Factories.ObjectAttributeFactory.CreateObjectAttribute(CKA.CKA_LABEL, "TmpKekKey"));
                    objectAttributes.Add(Settings.Factories.ObjectAttributeFactory.CreateObjectAttribute(CKA.CKA_ENCRYPT, true));
                    objectAttributes.Add(Settings.Factories.ObjectAttributeFactory.CreateObjectAttribute(CKA.CKA_DECRYPT, true));
                    objectAttributes.Add(Settings.Factories.ObjectAttributeFactory.CreateObjectAttribute(CKA.CKA_WRAP, true));
                    objectAttributes.Add(Settings.Factories.ObjectAttributeFactory.CreateObjectAttribute(CKA.CKA_UNWRAP, true));
                    objectAttributes.Add(Settings.Factories.ObjectAttributeFactory.CreateObjectAttribute(CKA.CKA_EXTRACTABLE, true));
                    objectAttributes.Add(Settings.Factories.ObjectAttributeFactory.CreateObjectAttribute(CKA.CKA_SENSITIVE, false));
                    objectAttributes.Add(Settings.Factories.ObjectAttributeFactory.CreateObjectAttribute(CKA.CKA_VALUE, plainKeyValueBytes));

                    IObjectHandle importedKey = session.CreateObject(objectAttributes);

                    // Check if key was successfully created
                    if (importedKey == null)
                        throw new Exception("Fail creating key object");

                    IMechanism mechanism_wrap_encrypt_decrypt = Settings.Factories.MechanismFactory.CreateMechanism(keyTypeCKM);

                    /****************** Compute KCV ***********************************/
                    if (!string.IsNullOrEmpty(keyKCV))
                    {
                        byte[] iv = new byte[8];

                        // Encrypt data
                        byte[] kcvBytes = session.Encrypt(mechanism_wrap_encrypt_decrypt, importedKey, iv);
                        byte[] refKcvBytes = Common.HelperFunctions.StringToByteArray(keyKCV);

                        for (int i = 0; i < refKcvBytes.Length; i++)
                        {
                            if (kcvBytes[i] != refKcvBytes[i])
                            {
                                throw new Exception("KCV is incorrect");
                            }
                        }
                    }

                    /****************** WRAP Key ***********************************/
                    IObjectHandle hLMKKey = findAKeyObject(Configurations.LMK_KEYNAME, session);

                    // Wrap key
                    byte[] wrappedKeyBytes = session.WrapKey(mechanism_wrap_encrypt_decrypt, hLMKKey, importedKey);

                    // Do something interesting with wrapped key
                    if (wrappedKeyBytes == null)
                        throw new Exception("Fail wrapping key");

                    //// Destroy object
                    session.DestroyObject(importedKey);
                    session.Logout();

                    return HelperFunctions.ByteArrayToString(wrappedKeyBytes);

                }
            }
        }


        // wrap a clear key value (string) under LMK
        public static String ImportAKeyUnderZCMKAndStoreItUnderLMK(String encryptedKey, String EncryptedKeyKCV, string encryptedZcmkUnderLMK, string keyKCV)
        {
            using (IPkcs11 pkcs11 = Settings.Factories.Pkcs11Factory.CreatePkcs11(Settings.Factories, Configurations.Pkcs11LibraryPath, Settings.AppType))
            {
                // Find first slot with token present
                ISlot slot = Helpers.GetUsableSlot(pkcs11, Configurations.default_slot);

                // Open RW session
                using (Net.Pkcs11Interop.HighLevelAPI.ISession session = slot.OpenSession(SessionType.ReadWrite))
                {
                    // Login as normal user
                    session.Login(Configurations.user_type, Configurations.hsm_password);

                    byte[] encryptedZCMKKeyValuesInBytes = Common.HelperFunctions.StringToByteArray(encryptedZcmkUnderLMK);

                    CKK keyType;
                    CKM keyTypeCKM;

                    if (encryptedZcmkUnderLMK.Length == 8 * 2 * 3)
                    {
                        keyType = CKK.CKK_DES3;
                        keyTypeCKM = CKM.CKM_DES3_ECB;
                    }
                    else if (encryptedZcmkUnderLMK.Length == 8 * 2 * 2)
                    {
                        keyType = CKK.CKK_DES2;
                        keyTypeCKM = CKM.CKM_DES3_ECB;
                    }
                    else if (encryptedZcmkUnderLMK.Length == 8 * 2)
                    {
                        keyType = CKK.CKK_DES;
                        keyTypeCKM = CKM.CKM_DES_ECB;
                    }
                    else
                        throw new Exception("Wrong Key Length");

                    List<IObjectAttribute> objectAttributes = new List<IObjectAttribute>();
                    objectAttributes.Add(Settings.Factories.ObjectAttributeFactory.CreateObjectAttribute(CKA.CKA_TOKEN, false)); //not stored in token
                    objectAttributes.Add(Settings.Factories.ObjectAttributeFactory.CreateObjectAttribute(CKA.CKA_CLASS, CKO.CKO_SECRET_KEY));
                    objectAttributes.Add(Settings.Factories.ObjectAttributeFactory.CreateObjectAttribute(CKA.CKA_KEY_TYPE, keyType));
                    objectAttributes.Add(Settings.Factories.ObjectAttributeFactory.CreateObjectAttribute(CKA.CKA_LABEL, "TmpKekKey"));
                    objectAttributes.Add(Settings.Factories.ObjectAttributeFactory.CreateObjectAttribute(CKA.CKA_ENCRYPT, true));
                    objectAttributes.Add(Settings.Factories.ObjectAttributeFactory.CreateObjectAttribute(CKA.CKA_DECRYPT, true));
                    objectAttributes.Add(Settings.Factories.ObjectAttributeFactory.CreateObjectAttribute(CKA.CKA_WRAP, true));
                    objectAttributes.Add(Settings.Factories.ObjectAttributeFactory.CreateObjectAttribute(CKA.CKA_UNWRAP, true));
                    objectAttributes.Add(Settings.Factories.ObjectAttributeFactory.CreateObjectAttribute(CKA.CKA_EXTRACTABLE, true));
                    objectAttributes.Add(Settings.Factories.ObjectAttributeFactory.CreateObjectAttribute(CKA.CKA_SENSITIVE, false));
                    //objectAttributes.Add(Settings.Factories.ObjectAttributeFactory.CreateObjectAttribute(CKA.CKA_VALUE, plainKeyValueBytes));

                    //IObjectHandle importedKey = session.CreateObject(objectAttributes);

                    //// Check if key was successfully created
                    //if (importedKey == null)
                    //    throw new Exception("Fail creating key object");

                    IMechanism mechanism_wrap_encrypt_decrypt = Settings.Factories.MechanismFactory.CreateMechanism(keyTypeCKM);

                    /****************** WRAP Key ***********************************/
                    IObjectHandle hLMKKey = findAKeyObject(Configurations.LMK_KEYNAME, session);

                    // Unwrap key
                    IObjectHandle ZCMKKeyHandle = session.UnwrapKey(mechanism_wrap_encrypt_decrypt, hLMKKey, encryptedZCMKKeyValuesInBytes, objectAttributes);

                    // Do something interesting with wrapped key
                    if (ZCMKKeyHandle == null)
                        throw new Exception("Fail Unwrapping key");


                    /****************** Compute KCV ***********************************/
                    if (!string.IsNullOrEmpty(keyKCV))
                    {
                        byte[] iv = new byte[8];

                        // Encrypt data
                        byte[] kcvBytes = session.Encrypt(mechanism_wrap_encrypt_decrypt, ZCMKKeyHandle, iv);
                        byte[] refKcvBytes = Common.HelperFunctions.StringToByteArray(keyKCV);

                        for (int i = 0; i < refKcvBytes.Length; i++)
                        {
                            if (kcvBytes[i] != refKcvBytes[i])
                            {
                                throw new Exception("ZCMK KCV is incorrect");
                            }
                        }
                    }

                    //////////////////////////////////////////////////////////////////////////////////////

                    byte[] encryptedKeyValuesInBytes = Common.HelperFunctions.StringToByteArray(encryptedKey);
                    byte[] encryptedKcvValuesInBytes = Common.HelperFunctions.StringToByteArray(EncryptedKeyKCV);

                    // Unwrap Key under ZCMK
                    IObjectHandle ImportKeyHandle = session.UnwrapKey(mechanism_wrap_encrypt_decrypt, 
                        ZCMKKeyHandle, encryptedKeyValuesInBytes, objectAttributes);

                    /****************** Compute KCV ***********************************/
                    if (!string.IsNullOrEmpty(EncryptedKeyKCV))
                    {
                        byte[] iv = new byte[8];

                        // Encrypt data
                        byte[] kcvBytes = session.Encrypt(mechanism_wrap_encrypt_decrypt, ImportKeyHandle, iv);
                        byte[] refKcvBytes = Common.HelperFunctions.StringToByteArray(keyKCV);

                        for (int i = 0; i < refKcvBytes.Length; i++)
                        {
                            if (kcvBytes[i] != refKcvBytes[i])
                            {
                                throw new Exception("IMPORT KCV is incorrect");
                            }
                        }
                    }

                    // wrap key under LMK and return it
                    // Wrap key
                    byte[] wrappedKeyBytes = session.WrapKey(mechanism_wrap_encrypt_decrypt, hLMKKey, ImportKeyHandle);

                    // Do something interesting with wrapped key
                    if (wrappedKeyBytes == null)
                        throw new Exception("Fail wrapping key");

                    //// Destroy object
                    session.DestroyObject(ImportKeyHandle);
                    session.DestroyObject(ZCMKKeyHandle);
                    session.Logout();

                    return HelperFunctions.ByteArrayToString(wrappedKeyBytes);
                }
            }
        }



        public static string generateAndCreateKeyObj()
        {
            using (IPkcs11 pkcs11 = Settings.Factories.Pkcs11Factory.CreatePkcs11(Settings.Factories, Configurations.Pkcs11LibraryPath, Settings.AppType))
            {
                // Find first slot with token present
                ISlot slot = Helpers.GetUsableSlot(pkcs11, Configurations.default_slot);

                // Open RW session
                using (Net.Pkcs11Interop.HighLevelAPI.ISession session = slot.OpenSession(SessionType.ReadWrite))
                {
                    // Login as normal user
                    //session.Login(Configurations.user_type, "1234");
                    session.Login(Configurations.user_type, Configurations.hsm_password);

                    // Prepare attribute template of new key
                    List<IObjectAttribute> objectAttributes = new List<IObjectAttribute>();
                    objectAttributes.Add(Settings.Factories.ObjectAttributeFactory.CreateObjectAttribute(CKA.CKA_TOKEN, false)); //not stored in token
                    objectAttributes.Add(Settings.Factories.ObjectAttributeFactory.CreateObjectAttribute(CKA.CKA_CLASS, CKO.CKO_SECRET_KEY));
                    objectAttributes.Add(Settings.Factories.ObjectAttributeFactory.CreateObjectAttribute(CKA.CKA_KEY_TYPE, CKK.CKK_DES3));
                    objectAttributes.Add(Settings.Factories.ObjectAttributeFactory.CreateObjectAttribute(CKA.CKA_ENCRYPT, true));
                    objectAttributes.Add(Settings.Factories.ObjectAttributeFactory.CreateObjectAttribute(CKA.CKA_DECRYPT, true));
                    objectAttributes.Add(Settings.Factories.ObjectAttributeFactory.CreateObjectAttribute(CKA.CKA_WRAP, true));
                    objectAttributes.Add(Settings.Factories.ObjectAttributeFactory.CreateObjectAttribute(CKA.CKA_UNWRAP, true));
                    objectAttributes.Add(Settings.Factories.ObjectAttributeFactory.CreateObjectAttribute(CKA.CKA_EXTRACTABLE, true));

                    // Specify key generation mechanism
                    IMechanism mechanism = Settings.Factories.MechanismFactory.CreateMechanism(CKM.CKM_DES3_KEY_GEN);

                    // Generate key
                    IObjectHandle secret_key = session.GenerateKey(mechanism, objectAttributes);


                    ////////////////////////////////////////////////////////////////////////////////////////

                    // Export the key
                    byte[] plainKeyValue = null;
                    List<IObjectAttribute> readAttrs = session.GetAttributeValue(secret_key, new List<CKA>() { CKA.CKA_VALUE });
                    if (readAttrs[0].CannotBeRead)
                        throw new Exception("Key cannot be exported");
                    else
                        plainKeyValue = readAttrs[0].GetValueAsByteArray();

                    plainKeyValue = Common.HelperFunctions.StringToByteArray("112233445566778899001122334455665566998844335511");

                    // Prepare attribute template of new key
                    List<IObjectAttribute> oa = new List<IObjectAttribute>();
                    oa.Add(Settings.Factories.ObjectAttributeFactory.CreateObjectAttribute(CKA.CKA_LABEL, "Imported key"));
                    oa.Add(Settings.Factories.ObjectAttributeFactory.CreateObjectAttribute(CKA.CKA_CLASS, CKO.CKO_SECRET_KEY));
                    oa.Add(Settings.Factories.ObjectAttributeFactory.CreateObjectAttribute(CKA.CKA_KEY_TYPE, CKK.CKK_DES3));
                    oa.Add(Settings.Factories.ObjectAttributeFactory.CreateObjectAttribute(CKA.CKA_TOKEN, true));
                    oa.Add(Settings.Factories.ObjectAttributeFactory.CreateObjectAttribute(CKA.CKA_ENCRYPT, true));
                    oa.Add(Settings.Factories.ObjectAttributeFactory.CreateObjectAttribute(CKA.CKA_DECRYPT, true));
                    oa.Add(Settings.Factories.ObjectAttributeFactory.CreateObjectAttribute(CKA.CKA_VALUE, plainKeyValue));


                    IObjectHandle importedKey = session.CreateObject(oa);


                    // Test encryption with generated key and decryption with imported key
                    using (IMechanism mechanismx = Settings.Factories.MechanismFactory.CreateMechanism(CKM.CKM_DES3_CBC, session.GenerateRandom(8)))
                    {
                        byte[] sourceData = ConvertUtils.Utf8StringToBytes("Our new password");
                        byte[] encryptedData = session.Encrypt(mechanismx, secret_key, sourceData);
                        byte[] decryptedData = session.Decrypt(mechanismx, importedKey, encryptedData);
                        if (Convert.ToBase64String(sourceData) != Convert.ToBase64String(decryptedData))
                            throw new Exception("Encryption test failed");
                    }
                    // Destroy object
                    session.DestroyObject(importedKey);
                    session.DestroyObject(secret_key);
                    session.Logout();

                    return HelperFunctions.ByteArrayToString(plainKeyValue);
                }
            }
        }

        public static void createKeyObj()
        {
            using (IPkcs11 pkcs11 = Settings.Factories.Pkcs11Factory.CreatePkcs11(Settings.Factories, Configurations.Pkcs11LibraryPath, Settings.AppType))
            {

                // Find first slot with token present
                ISlot slot = Helpers.GetUsableSlot(pkcs11);

                // Open RW session
                using (ISession session = slot.OpenSession(SessionType.ReadWrite))
                {
                    // Login as normal user
                    //session.Login(Configurations.user_type, "1234");
                    session.Login(Configurations.user_type, Configurations.hsm_password);

                    // Prepare attribute template of new data object
                    List<IObjectAttribute> objectAttributes = new List<IObjectAttribute>();
                    objectAttributes.Add(Settings.Factories.ObjectAttributeFactory.CreateObjectAttribute(CKA.CKA_CLASS, CKO.CKO_DATA));
                    objectAttributes.Add(Settings.Factories.ObjectAttributeFactory.CreateObjectAttribute(CKA.CKA_TOKEN, true));
                    objectAttributes.Add(Settings.Factories.ObjectAttributeFactory.CreateObjectAttribute(CKA.CKA_APPLICATION, Settings.ApplicationName));
                    objectAttributes.Add(Settings.Factories.ObjectAttributeFactory.CreateObjectAttribute(CKA.CKA_LABEL, Settings.ApplicationName));
                    objectAttributes.Add(Settings.Factories.ObjectAttributeFactory.CreateObjectAttribute(CKA.CKA_VALUE, "Data object content"));

                    // Create object
                    IObjectHandle objectHandle = session.CreateObject(objectAttributes);

                    // Do something interesting with new object

                    // Destroy object
                    session.DestroyObject(objectHandle);

                    session.Logout();
                }
            }
        }


        public static string[] getRSAKeyFromDBUnwrapIt(string lengthInBitsStr, string publicModulus)
        {
            byte[] pubMod = HelperFunctions.StringToByteArray(publicModulus);
            ulong lengthInBits = Convert.ToUInt32(lengthInBitsStr);

            string[] result = new string[2];

            try
            {
                using (IPkcs11 pkcs11 = Settings.Factories.Pkcs11Factory.CreatePkcs11(Settings.Factories, Configurations.Pkcs11LibraryPath, Settings.AppType))
                {
                    // Find first slot with token present
                    ISlot slot = Helpers.GetUsableSlot(pkcs11, Configurations.default_slot);

                    // Open RW session
                    using (ISession session = slot.OpenSession(SessionType.ReadWrite))
                    {
                        // Login as normal user
                        //session.Login(CKU.CKU_USER, "1234");
                        session.Login(Configurations.user_type, Configurations.hsm_password);

                        // The CKA_ID attribute is intended as a means of distinguishing multiple key pairs held by the same subject
                        byte[] ckaId = session.GenerateRandom(20);

                        // Prepare attribute template of new public key
                        List<IObjectAttribute> publicKeyAttributes = new List<IObjectAttribute>();
                        publicKeyAttributes.Add(Settings.Factories.ObjectAttributeFactory.CreateObjectAttribute(CKA.CKA_TOKEN, false));
                        publicKeyAttributes.Add(Settings.Factories.ObjectAttributeFactory.CreateObjectAttribute(CKA.CKA_PRIVATE, false));
                        publicKeyAttributes.Add(Settings.Factories.ObjectAttributeFactory.CreateObjectAttribute(CKA.CKA_LABEL, Settings.ApplicationName));
                        publicKeyAttributes.Add(Settings.Factories.ObjectAttributeFactory.CreateObjectAttribute(CKA.CKA_ID, ckaId));
                        publicKeyAttributes.Add(Settings.Factories.ObjectAttributeFactory.CreateObjectAttribute(CKA.CKA_ENCRYPT, true));
                        publicKeyAttributes.Add(Settings.Factories.ObjectAttributeFactory.CreateObjectAttribute(CKA.CKA_VERIFY, true));
                        publicKeyAttributes.Add(Settings.Factories.ObjectAttributeFactory.CreateObjectAttribute(CKA.CKA_VERIFY_RECOVER, true));
                        publicKeyAttributes.Add(Settings.Factories.ObjectAttributeFactory.CreateObjectAttribute(CKA.CKA_WRAP, true));
                        publicKeyAttributes.Add(Settings.Factories.ObjectAttributeFactory.CreateObjectAttribute(CKA.CKA_SENSITIVE, false));
                        publicKeyAttributes.Add(Settings.Factories.ObjectAttributeFactory.CreateObjectAttribute(CKA.CKA_MODULUS_BITS, lengthInBits));
                        publicKeyAttributes.Add(Settings.Factories.ObjectAttributeFactory.CreateObjectAttribute(CKA.CKA_PUBLIC_EXPONENT, pubMod));
                        publicKeyAttributes.Add(Settings.Factories.ObjectAttributeFactory.CreateObjectAttribute(CKA.CKA_EXTRACTABLE, true));


                        // Prepare attribute template of new private key
                        List<IObjectAttribute> privateKeyAttributes = new List<IObjectAttribute>();
                        privateKeyAttributes.Add(Settings.Factories.ObjectAttributeFactory.CreateObjectAttribute(CKA.CKA_TOKEN, false));
                        privateKeyAttributes.Add(Settings.Factories.ObjectAttributeFactory.CreateObjectAttribute(CKA.CKA_PRIVATE, true));
                        privateKeyAttributes.Add(Settings.Factories.ObjectAttributeFactory.CreateObjectAttribute(CKA.CKA_LABEL, Settings.ApplicationName));
                        privateKeyAttributes.Add(Settings.Factories.ObjectAttributeFactory.CreateObjectAttribute(CKA.CKA_ID, ckaId));
                        privateKeyAttributes.Add(Settings.Factories.ObjectAttributeFactory.CreateObjectAttribute(CKA.CKA_SENSITIVE, false));
                        privateKeyAttributes.Add(Settings.Factories.ObjectAttributeFactory.CreateObjectAttribute(CKA.CKA_DECRYPT, true));
                        privateKeyAttributes.Add(Settings.Factories.ObjectAttributeFactory.CreateObjectAttribute(CKA.CKA_SIGN, true));
                        privateKeyAttributes.Add(Settings.Factories.ObjectAttributeFactory.CreateObjectAttribute(CKA.CKA_SIGN_RECOVER, true));
                        privateKeyAttributes.Add(Settings.Factories.ObjectAttributeFactory.CreateObjectAttribute(CKA.CKA_UNWRAP, true));
                        privateKeyAttributes.Add(Settings.Factories.ObjectAttributeFactory.CreateObjectAttribute(CKA.CKA_EXTRACTABLE, true));

                        // Specify key generation mechanism
                        IMechanism mechanism = Settings.Factories.MechanismFactory.CreateMechanism(CKM.CKM_RSA_PKCS_KEY_PAIR_GEN);

                        // Generate key pair
                        IObjectHandle publicKeyHandle = null;
                        IObjectHandle privateKeyHandle = null;
                        session.GenerateKeyPair(mechanism, publicKeyAttributes, privateKeyAttributes, out publicKeyHandle, out privateKeyHandle);

                        //List<CKA> ckaAttr = new List<CKA>();
                        //ckaAttr.Add(CKA.CKA_PUBLIC_EXPONENT);
                        //ckaAttr.Add(CKA.CKA_MODULUS_BITS);
                        //ckaAttr.Add(CKA.CKA_MODULUS);
                        //ckaAttr.Add(CKA.CKA_VALUE);
                        //List<IObjectAttribute> c = session.GetAttributeValue(publicKeyHandle, ckaAttr);

                        //byte[] test1 = c[0].GetValueAsByteArray();
                        //byte[] test2 = c[1].GetValueAsByteArray();
                        //byte[] test3 = c[2].GetValueAsByteArray();
                        //byte[] test4 = c[3].GetValueAsByteArray();


                        //List<CKA> ckaAttrB = new List<CKA>();
                        //ckaAttrB.Add(CKA.CKA_PRIVATE);
                        //ckaAttrB.Add(CKA.CKA_PRIVATE_EXPONENT);
                        //ckaAttrB.Add(CKA.CKA_PRIME);
                        //ckaAttrB.Add(CKA.CKA_PRIME_1);
                        //ckaAttrB.Add(CKA.CKA_PRIME_2);
                        //ckaAttrB.Add(CKA.CKA_VALUE);
                        //List<IObjectAttribute> d = session.GetAttributeValue(privateKeyHandle, ckaAttrB);

                        //byte[] testA = d[0].GetValueAsByteArray();
                        //byte[] testG = d[1].GetValueAsByteArray();
                        //byte[] testC = d[2].GetValueAsByteArray();
                        //byte[] testF = d[3].GetValueAsByteArray();

                        //byte[] keyData = ...;
                        //RsaPrivateKeyStructure rsaPrivKey = RsaPrivateKeyStructure.GetInstance(Asn1Sequence.FromByteArray(keyData));
                        //byte[] privateExponent = rsaPrivKey.PrivateExponent.ToByteArrayUnsigned();


                        /****************** WRAP Key ***********************************/
                        // Specify wrapping mechanism
                        IMechanism mechanism_wrap = Settings.Factories.MechanismFactory.CreateMechanism(CKM.CKM_DES3_ECB);

                        // Prepare attribute template of new key
                        List<IObjectAttribute> objectAttributes_wrapper_key = new List<IObjectAttribute>();
                        objectAttributes_wrapper_key.Add(Settings.Factories.ObjectAttributeFactory.CreateObjectAttribute(CKA.CKA_TOKEN, false)); //not stored in token
                        objectAttributes_wrapper_key.Add(Settings.Factories.ObjectAttributeFactory.CreateObjectAttribute(CKA.CKA_CLASS, CKO.CKO_SECRET_KEY));
                        objectAttributes_wrapper_key.Add(Settings.Factories.ObjectAttributeFactory.CreateObjectAttribute(CKA.CKA_KEY_TYPE, CKK.CKK_DES3));
                        //objectAttributes_wrapper_key.Add(Settings.Factories.ObjectAttributeFactory.CreateObjectAttribute(CKA.CKA_ENCRYPT, true));
                        objectAttributes_wrapper_key.Add(Settings.Factories.ObjectAttributeFactory.CreateObjectAttribute(CKA.CKA_DECRYPT, true));
                        //objectAttributes_wrapper_key.Add(Settings.Factories.ObjectAttributeFactory.CreateObjectAttribute(CKA.CKA_DERIVE, true));
                        //objectAttributes_wrapper_key.Add(Settings.Factories.ObjectAttributeFactory.CreateObjectAttribute(CKA.CKA_EXTRACTABLE, true));
                        objectAttributes_wrapper_key.Add(Settings.Factories.ObjectAttributeFactory.CreateObjectAttribute(CKA.CKA_WRAP, true));
                        //objectAttributes_wrapper_key.Add(Settings.Factories.ObjectAttributeFactory.CreateObjectAttribute(CKA.CKA_UNWRAP, true));

                        IObjectHandle hLMKKey = findAKeyObject(Configurations.LMK_KEYNAME, session);

                        // Wrap key
                        byte[] wrappedPublicKeyBytes = session.WrapKey(mechanism_wrap, hLMKKey, publicKeyHandle);
                        byte[] wrappedPrivateKeyBytes = session.WrapKey(mechanism_wrap, hLMKKey, privateKeyHandle);

                        // Do something interesting with wrapped key
                        if (wrappedPublicKeyBytes == null || wrappedPrivateKeyBytes == null)
                            throw new Exception("Fail wrapping key");

                        //try to unwrap
                        //IObjectHandle unwrappedPublicKeyHandle = session.UnwrapKey(mechanism_wrap, hLMKKey, wrappedPublicKeyBytes, publicKeyAttributes);
                        //IObjectHandle unwrappedPrivateKeyHandle = session.UnwrapKey(mechanism_wrap, hLMKKey, wrappedPrivateKeyBytes, privateKeyAttributes);
                        
                        //try to decrypt

                        // Decrypt data
                        byte[] decryptedData = session.Decrypt(mechanism_wrap, hLMKKey, wrappedPrivateKeyBytes);


                        //byte[] pub = new byte[wrappedPublicKeyBytes.Length - 14];
                        //Array.Copy(decryptedData, pub, wrappedPublicKeyBytes.Length - 14);

                        byte[] priv = new byte[decryptedData.Length - 14];
                        Array.Copy(decryptedData, priv, decryptedData.Length - 14);

                        //result[0] = HelperFunctions.ByteArrayToString(pub);
                        //result[1] = HelperFunctions.ByteArrayToString(priv);

                        var obj = Asn1Sequence.FromByteArray(priv);
                        Asn1Sequence seq = Asn1Sequence.GetInstance(obj);
                        Asn1OctetString obcSeq = (Asn1OctetString) seq[2];
                        byte[] octByte = obcSeq.GetOctets();

                        Asn1Object octObj = Asn1Sequence.FromByteArray(octByte);
                        Asn1Sequence seqPrivKey = Asn1Sequence.GetInstance(octObj);

                        RsaPrivateKeyStructure rsaPrivKey = RsaPrivateKeyStructure.GetInstance(seqPrivKey);
                        byte[] privateExponent = rsaPrivKey.PrivateExponent.ToByteArrayUnsigned();
                        

                        ////byte[] keyData = ...;
                        //RsaPrivateKeyStructure rsaPrivKey = RsaPrivateKeyStructure.GetInstance(seq);
                        //byte[] privateExponent = rsaPrivKey.PrivateExponent.ToByteArrayUnsigned();


                        String res = Common.HelperFunctions.ByteArrayToString(decryptedData);

                        // Do Unwrap key
                        IObjectHandle unwrapPublicKey = session.UnwrapKey(mechanism_wrap, hLMKKey, wrappedPublicKeyBytes, publicKeyAttributes);
                        IObjectHandle unwrapPrivateKey = session.UnwrapKey(mechanism_wrap, hLMKKey, wrappedPrivateKeyBytes, privateKeyAttributes);



                        // Destroy keys
                        session.DestroyObject(publicKeyHandle);
                        session.DestroyObject(privateKeyHandle);

                        session.Logout();

                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                throw ex;
            }
            return result;
        }



        public static string encryptKeyUnderLmk(string plainKey)
        {
            try
            {
                using (IPkcs11 pkcs11 = Settings.Factories.Pkcs11Factory.CreatePkcs11(Settings.Factories, Configurations.Pkcs11LibraryPath, Settings.AppType))
                {
                    // Find first slot with token present
                    ISlot slot = Helpers.GetUsableSlot(pkcs11, Configurations.default_slot);

                    // Open RW session
                    using (ISession session = slot.OpenSession(SessionType.ReadWrite))
                    {
                        // Login as normal user
                        //session.Login(CKU.CKU_USER, "1234");
                        session.Login(Configurations.user_type, Configurations.hsm_password);

                        //get LMK Key
                        IObjectHandle keyObj = findAKeyObject(Configurations.LMK_KEYNAME, session);

                        /****************** Compute KCV ***********************************/
                        IMechanism mechanism_wrap_encrypt_decrypt = Settings.Factories.MechanismFactory.CreateMechanism(CKM.CKM_DES3_ECB);

                        // Encrypt data
                        byte[] EncryptedKey = session.Encrypt(mechanism_wrap_encrypt_decrypt, keyObj, Common.HelperFunctions.StringToByteArray(plainKey));

                        return Common.HelperFunctions.ByteArrayToString(EncryptedKey);
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                throw ex;
            }
        }


        public static string decryptKeyUnderLmk(string encryptedKey)
        {
            try
            {
                using (IPkcs11 pkcs11 = Settings.Factories.Pkcs11Factory.CreatePkcs11(Settings.Factories, Configurations.Pkcs11LibraryPath, Settings.AppType))
                {
                    // Find first slot with token present
                    ISlot slot = Helpers.GetUsableSlot(pkcs11, Configurations.default_slot);

                    // Open RW session
                    using (ISession session = slot.OpenSession(SessionType.ReadWrite))
                    {
                        // Login as normal user
                        //session.Login(CKU.CKU_USER, "1234");
                        session.Login(Configurations.user_type, Configurations.hsm_password);

                        //get LMK Key
                        IObjectHandle keyObj = findAKeyObject(Configurations.LMK_KEYNAME, session);

                        /****************** Compute KCV ***********************************/
                        IMechanism mechanism_wrap_encrypt_decrypt = Settings.Factories.MechanismFactory.CreateMechanism(CKM.CKM_DES3_ECB);

                        // Encrypt data
                        byte[] EncryptedKey = session.Decrypt(mechanism_wrap_encrypt_decrypt, keyObj, Common.HelperFunctions.StringToByteArray(encryptedKey));

                        return Common.HelperFunctions.ByteArrayToString(EncryptedKey);
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                throw ex;
            }
        }

        // wrap a clear key value (string) under LMK
        public static IObjectHandle createLMKKeyFrom3Components(string plainKeyValue, string keyKCV)
        {
            using (IPkcs11 pkcs11 = Settings.Factories.Pkcs11Factory.CreatePkcs11(Settings.Factories, Configurations.Pkcs11LibraryPath, Settings.AppType))
            {
                // Find first slot with token present
                ISlot slot = Helpers.GetUsableSlot(pkcs11, Configurations.default_slot);

                // Open RW session
                using (Net.Pkcs11Interop.HighLevelAPI.ISession session = slot.OpenSession(SessionType.ReadWrite))
                {
                    // Login as normal user
                    session.Login(Configurations.user_type, Configurations.hsm_password);

                    byte[] plainKeyValueBytes = Common.HelperFunctions.StringToByteArray(plainKeyValue);

                    CKK keyType;
                    CKM keyTypeCKM;

                    if (plainKeyValue.Length == 8 * 2 * 3)
                    {
                        keyType = CKK.CKK_DES3;
                        keyTypeCKM = CKM.CKM_DES3_ECB;
                    }
                    else if (plainKeyValue.Length == 8 * 2 * 2)
                    {
                        keyType = CKK.CKK_DES2;
                        keyTypeCKM = CKM.CKM_DES3_ECB;
                    }
                    else if (plainKeyValue.Length == 8 * 2)
                    {
                        keyType = CKK.CKK_DES;
                        keyTypeCKM = CKM.CKM_DES_ECB;
                    }
                    else
                        throw new Exception("Wrong Key Length");

                    List<IObjectAttribute> objectAttributes = new List<IObjectAttribute>();
                    objectAttributes.Add(Settings.Factories.ObjectAttributeFactory.CreateObjectAttribute(CKA.CKA_TOKEN, true)); //not stored in token
                    objectAttributes.Add(Settings.Factories.ObjectAttributeFactory.CreateObjectAttribute(CKA.CKA_CLASS, CKO.CKO_SECRET_KEY));
                    objectAttributes.Add(Settings.Factories.ObjectAttributeFactory.CreateObjectAttribute(CKA.CKA_KEY_TYPE, keyType));
                    objectAttributes.Add(Settings.Factories.ObjectAttributeFactory.CreateObjectAttribute(CKA.CKA_LABEL, Configurations.LMK_KEYNAME));
                    objectAttributes.Add(Settings.Factories.ObjectAttributeFactory.CreateObjectAttribute(CKA.CKA_ENCRYPT, true));
                    objectAttributes.Add(Settings.Factories.ObjectAttributeFactory.CreateObjectAttribute(CKA.CKA_DECRYPT, true));
                    objectAttributes.Add(Settings.Factories.ObjectAttributeFactory.CreateObjectAttribute(CKA.CKA_WRAP, true));
                    objectAttributes.Add(Settings.Factories.ObjectAttributeFactory.CreateObjectAttribute(CKA.CKA_UNWRAP, true));
                    objectAttributes.Add(Settings.Factories.ObjectAttributeFactory.CreateObjectAttribute(CKA.CKA_EXTRACTABLE, true));
                    objectAttributes.Add(Settings.Factories.ObjectAttributeFactory.CreateObjectAttribute(CKA.CKA_SENSITIVE, false));
                    objectAttributes.Add(Settings.Factories.ObjectAttributeFactory.CreateObjectAttribute(CKA.CKA_VALUE, plainKeyValueBytes));

                    IObjectHandle importedKey = session.CreateObject(objectAttributes);

                    // Check if key was successfully created
                    if (importedKey == null)
                        throw new Exception("Fail creating key object, key must be ODD value");

                    IMechanism mechanism_wrap_encrypt_decrypt = Settings.Factories.MechanismFactory.CreateMechanism(keyTypeCKM);

                    /****************** Compute KCV ***********************************/
                    if (!string.IsNullOrEmpty(keyKCV))
                    {
                        byte[] iv = new byte[8];

                        // Encrypt data
                        byte[] kcvBytes = session.Encrypt(mechanism_wrap_encrypt_decrypt, importedKey, iv);
                        byte[] refKcvBytes = Common.HelperFunctions.StringToByteArray(keyKCV);

                        for (int i = 0; i < refKcvBytes.Length; i++)
                        {
                            if (kcvBytes[i] != refKcvBytes[i])
                            {
                                throw new Exception("KCV is incorrect");
                            }
                        }
                    }

                    session.Logout();

                    return importedKey;

                }
            }
        }

    }

}

