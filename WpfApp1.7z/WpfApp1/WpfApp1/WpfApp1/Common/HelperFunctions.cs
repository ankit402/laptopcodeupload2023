﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WpfApp1.Common
{
    public class HelperFunctions
    {
        public static string ByteArrayToString(byte[] ba)
        {
            //if (BitConverter.IsLittleEndian)
            //    Array.Reverse(ba);

            string hex = BitConverter.ToString(ba);
            return hex.Replace("-", "");
        }


        public static byte[] SubArray(byte[] data, int from, int to)
        {
            if (to < from)
                throw new Exception("To index must be higher than from index in SubArray"); ;

            int length = to - from;

            byte[] result = new byte[length];
            Array.Copy(data, from, result, 0, length);

            return result;
        }

        // convert from string to array
        public static byte[] StringToByteArray(string hex)
        {
            byte[] result;
            try
            {
                result = Enumerable.Range(0, hex.Length)
                             .Where(x => x % 2 == 0)
                             .Select(x => Convert.ToByte(hex.Substring(x, 2), 16))
                             .ToArray();

                return result;
            }
            catch (Exception e)
            {
                throw new Exception(e.Message); ;
            }
        }

        public static bool ArraysEqual<T>(T[] a1, T[] a2)
        {
            if (ReferenceEquals(a1, a2))
                return true;

            if (a1 == null || a2 == null)
                return false;

            if (a1.Length != a2.Length)
                return false;

            EqualityComparer<T> comparer = EqualityComparer<T>.Default;
            for (int i = 0; i < a1.Length; i++)
            {
                if (!comparer.Equals(a1[i], a2[i])) return false;
            }
            return true;
        }
    }
}
