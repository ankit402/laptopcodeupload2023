﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows.Forms;
    public class CustomTreeNode : TreeNode
    {

        private int intIndex = 0;
        private string strName = "";
        private string strText = "";
        private string strType = "";
        private string strTag = "";
        private string intLengthEncoding = "";
        private string intRole = "";
        private string intEncMode = "";
        private string intEncKey = "";
        private string intPaddMode = "";
        private string strOrigin = "";
        private string intValue = "";
        private string strPath = "";
        private string strauthenticate = "";
        private string strformat = "";
        // private string intRole;

        public int Index
        {
            get
            {
                return intIndex;
            }
            set
            {
                intIndex = value;
            }
        }

        public string Name
        {
            get
            {
                return strName;
            }
            set
            {
                strName = value;
            }
        }

        //public string Text
        //{
        //    get
        //    {
        //        return strText;
        //    }
        //    set
        //    {
        //        strText = value;
        //    }
        //}

        public string Type
        {
            get
            {
                return strType;
            }
            set
            {
                strType = value;
            }
        }

        public string Tag
        {
            get
            {
                return strTag;
            }
            set
            {
                strTag = value;
            }
        }

        public string LengthEncoding
        {
            get
            {
                return intLengthEncoding;
            }
            set
            {
                intLengthEncoding = value;
            }
        }
        public string Format
        {
            get
            {
                return strformat;
            }
            set
            {
                strformat = value;
            }
        }
        public string Role
        {
            get
            {
                return intRole;
            }
            set
            {
                intRole = value;
            }
        }
        public string EncMode
        {
            get
            {
                return intEncMode;
            }
            set
            {
                intEncMode = value;
            }
        }
        public string EncKey
        {
            get
            {
                return intEncKey;
            }
            set
            {
                intEncKey = value;
            }
        }
        public string PaddMode
        {
            get
            {
                return intPaddMode;
            }
            set
            {
                intPaddMode = value;
            }
        }

        public string Origin
        {
            get
            {
                return strOrigin;
            }
            set
            {
                strOrigin = value;
            }
        }

        public string Value
        {
            get
            {
                return intValue;
            }
            set
            {
                intValue = value;
            }
        }

        public string Path
        {
            get
            {
                return strPath;
            }
            set
            {
                strPath = value;
            }
        }

        public string IsAuthSFI
        {
            get
            {
                return strauthenticate;
            }
            set
            {
                strauthenticate = value;
            }
        }
    }

