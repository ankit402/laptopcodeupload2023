﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Configuration;
using System.Data;
using System.Drawing;
using System.Drawing.Printing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Xml;
using System.Xml.Linq;
using System.Xml.Serialization;
using GemCard;
using SDKShim;
using SmartCardPlayer;


namespace WpfApp1
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        string tempXml =string.Empty;
        //Tree
        // Xml tag for node, e.g. 'node' in case of <node></node>
        private const string XmlNodeTag = "NODE";
        private const int Count = 2;
        private string[] codeList = { "th", "os" };
        // Xml attributes for node e.g. <node text="Asia" tag="" 
        // imageindex="1"></node>
        private const string XmlNodeNameAtt = "NAME";
        private const string XmlNodeTagAtt = "TAG";
        private const string XmlNodeIndexAtt = "INDEX";
        private const string XmlNodeTypeAtt = "TYPE";
        private const string XmlNodeEncodingAtt = "ENCODING";
        private const string XmlNodeRoleAtt = "ROLE";
        private const string XmlNodeEncKeyAtt = "ENC_KEY";
        private const string XmlNodeEncModeAtt = "ENC_MODE";
        private const string XmlNodePaddAtt = "PADD";
        private const string XmlNodeOriginAtt = "ORIGIN";
        private const string XmlNodeValueAtt = "VALUE";
        private const string XmlNodePathAtt = "PATH";
        private const string XmlNodeAuthAtt = "AUTHENTICATE";
        private const string XmlNodeFormat = "Format";
        //Tree end
        private CardBase m_iCard = null;
        private APDUPlayer m_apduPlayer = null;
        private APDUParam m_apduParam = null;
        const string ApduListFile = "ApduList.xml";
        public string hexOutput, PersoPAN = string.Empty, PersoErr = String.Empty;
        private string encHSM = "CRYPTOCARD01";
        private Boolean Auth = false;
        private string SelectedReader = null;
        MagicardProLibrary.Embossing objRio = new MagicardProLibrary.Embossing();
        string ipkxmlpath = ConfigurationSettings.AppSettings["ipkxml"];
        private IntPtr hSession;
        static private IntPtr hDC = IntPtr.Zero;
        static private PrinterSettings ps = new PrinterSettings();
        //static private PrintDialog pd = new PrintDialog();
        static private Graphics g;
        IntPtr FrontDC, BackDC, FrontResinDC, BackResinDC;
        SDK.TextDef TextDefn = new SDK.TextDef();
        SDK.ShapeDef ShapeDefn = new SDK.ShapeDef();
        SDK.LineDef LineDefn = new SDK.LineDef();
        SDK.ImageDef ImageDefn = new SDK.ImageDef();
        SDK.Return SDKReturn;
       
        public MainWindow()
        {
                
        InitializeComponent();
            SelectICard();
            SetupReaderList();
        }
        private void SelectICard()
        {
            try
            {
                if (m_iCard != null)
                    m_iCard.Disconnect(DISCONNECT.Unpower);

                m_iCard = new CardNative();
                // statusStrip2.Text = "CardNative implementation used";

                // m_iCard.OnCardInserted += new CardInsertedEventHandler(m_iCard_OnCardInserted);
                // m_iCard.OnCardRemoved += new CardRemovedEventHandler(m_iCard_OnCardRemoved);


            }
            catch (Exception ex)
            {
                // btnConnect.Enabled = false;
                //btnDisconnect.Enabled = false;
                // btnPersonalize.Enabled = false;

                // toolStripStatusLabel2.Text = ex.Message;
            }

        }
        private void SetupReaderList()
        {
            try
            {
                string[] sListReaders = m_iCard.ListReaders();
                comboReader.Items.Clear();
                //SelectReader.Text = "No Reader Found";
                if (sListReaders != null)
                {
                    //  SelectReader.Text = "Select Reader";
                    for (int nI = 0; nI < sListReaders.Length; nI++)
                    {
                        comboReader.Items.Add(sListReaders[nI]);
                        // SelectReader.DropDownItems.Add(sListReaders[nI]);
                        // SelectReader.DropDownItems[nI].Click += new EventHandler(SelectReaderItemClickHandler);
                    }
                    comboReader.SelectedIndex = 0;
                    //SelectReader.DropDownItems[0].Font = new Font(SelectReader.DropDownItems[0].Font, FontStyle.Bold);


                    //// Start waiting for a card
                    SelectedReader = (string)comboReader.SelectedItem;
                    //m_iCard.StartCardEvents(reader);
                    // toolStripStatusLabel2.Text = "Waiting for a card";
                }
            }
            catch (Exception ex)
            {
                //toolStripStatusLabel2.Text = ex.Message;
                // btnConnect.Enabled = false;
            }
        }

        private void Btn_click(object sender, RoutedEventArgs e)
        {
            
            //Create();
            //read();
            ////InsertAfter();
            //AppendChild();
            //AddAfterSelf();
            //Add();
        }
        public void Create()
        {
            using (XmlWriter writer = XmlWriter.Create("C:\\PrinterConfiguration.xml"))
            {
                writer.WriteStartElement("PrinterConfiguration");
                writer.WriteEndElement();
                writer.Flush();
            }
        }
        public void read()
        {
            string path = "C:\\PrinterConfiguration.xml";
            tempXml = System.IO.File.ReadAllText(path);
            if (tempXml=="")
            {
                Create();
                read();
            }
        }
        public void InsertAfter()
        {
            // Option1: Using InsertAfter()
            // Adding Node to XML  
            XmlDocument doc3 = new XmlDocument();
            doc3.LoadXml(tempXml);  
            XmlNode root1 = doc3.DocumentElement;
            //Create a new attrtibute.  
            XmlElement elem = doc3.CreateElement("Printer");
            XmlAttribute attr = doc3.CreateAttribute("ID");
            attr.Value = "6";  
            elem.Attributes.Append(attr);  
            //Create a new attrtibute.  
            XmlAttribute attr2 = doc3.CreateAttribute("Name");
            attr2.Value = "Project6";  
            elem.Attributes.Append(attr2);  
            //Add the node to the document.  
            root1.InsertAfter(elem, root1.LastChild);
            string path = "C:\\PrinterConfiguration.xml";           
            doc3.Save(path);          
        }
        public void AppendChild()
        {
            // Option2: Using AppendChild()          
            XmlDocument doc4 = new XmlDocument();
            doc4.LoadXml(tempXml);
            XmlElement XEle = doc4.CreateElement("Printer");
            XEle.SetAttribute("Name", txtprintername.Text);
            string ids = Guid.NewGuid().ToString();
            XEle.SetAttribute("ID", ids);
            doc4.DocumentElement.AppendChild(XEle.Clone());
            string path = "C:\\PrinterConfiguration.xml";
            doc4.Save(path);
        }

        public void AddAfterSelf()
        {

            // Option1: Using AddAfterSelf()
            XDocument xdoc = XDocument.Parse(tempXml);
            XmlDocument xmlDoc = new XmlDocument();   
            var count = xdoc.Descendants("Printer").Count();
            var maxId = xmlDoc.SelectNodes("/PrinterConfiguration/Printer/ID")
                .Cast<XmlNode>()
                .Max(node => int.Parse(node.InnerText));
            var cust = new XElement("Printer", new XElement("id", count + 1));
            //var cust = xdoc.Descendants("Project")
            //                .First(rec => rec.Attribute("ID").Value == "5");
            cust.AddAfterSelf(new XElement("Printer", new XAttribute("ID", 1)));
            string path = "C:\\PrinterConfiguration.xml";
            xdoc.Save(path);
        }

        public void Add()
        {
            // Option2: Using Add() method 
            XDocument doc = XDocument.Parse(tempXml);
            XElement root = new XElement("Printer");
            root.Add(new XAttribute("ID", "6"));
            root.Add(new XAttribute("Name", "Project6"));
            doc.Element("Printer").Add(root);
            string path = "C:\\PrinterConfiguration.xml";
           doc.Save(path);
        }

        private void Rbnew_Checked(object sender, RoutedEventArgs e)
        {
          ////  var radioButton = sender as RadioButton;
           
          //  MessageBoxResult result = MessageBox.Show("Are you want to Add New Printer?", "Confirmation", MessageBoxButton.YesNo, MessageBoxImage.Question);
          //  if (result == MessageBoxResult.Yes)
          //  {
          //      radioButton.Checked = true;
          //      btn_click.Content = "Save Profile";
          //      return;
          //  }
          //  else
          //  {
               
          //      rbedit.IsChecked = true;
          //      btn_click.Content = "Edit Profile";
          //  }
        }

        private void Btn_reset_Click(object sender, RoutedEventArgs e)
        {
           bool resetresult= objRio.Reset();
            if (resetresult)
            {
                MessageBox.Show("Reset Successfully");
            }
        }

        private void RadioButton_Checked(object sender, RoutedEventArgs e)
        {
            //var radioButton = sender as RadioButton;
            
            //MessageBoxResult result = MessageBox.Show("Are you want to use Front Card Feed Functionality?", "Confirmation", MessageBoxButton.YesNo, MessageBoxImage.Question);
            //if (result == MessageBoxResult.Yes)
            //{
            //    radioButton.Checked = true;
            //    btn_click.Content = "Save Profile";
            //    return;
            //}
            //else
            //{
                
            //    rbedit.IsChecked = true;
            //    btn_click.Content = "Edit Profile";
            //}
        }
       
        private void Btn_print_Click(object sender, RoutedEventArgs e)
        {
            Print_Card();
        }
        static private string ByteArrayToString(byte[] data)
        {
            StringBuilder sDataOut;

            if (data != null)
            {
                sDataOut = new StringBuilder(data.Length * 2);
                for (int nI = 0; nI < data.Length; nI++)
                    sDataOut.AppendFormat("{0:X02}", data[nI]);
            }
            else
                sDataOut = new StringBuilder();

            return sDataOut.ToString();
        }
        void worker_DoWork(object sender, DoWorkEventArgs e)
        {
            for (int i = 0; i < 100; i++)
            {
                (sender as BackgroundWorker).ReportProgress(i);
                Thread.Sleep(100);
            }
        }
        public bool chipperso()
        {
            string m_exePath = string.Empty;
            SelectICard();
            BackgroundWorker worker = new BackgroundWorker();
            worker.WorkerReportsProgress = true;
          

            worker.RunWorkerAsync();
            string file_name = "e:\\ " + "Personalizelog.txt";
            connect_card(SelectedReader, SHARE.Direct, PROTOCOL.Undefined);
            if (chkgemalto.IsChecked == true)
            {
                m_apduPlayer.IsGemalto = true;
                m_apduPlayer.encryptionKey = "47454D5850524553534F53414D504C45";
                m_apduPlayer.Authentication("A0000000030000");
            }

            else
            {
                m_apduPlayer.IsGemalto = false;
                m_apduPlayer.encryptionKey = "4755525557414C54455244534F555A41";
                m_apduPlayer.Authentication("A0000001510000");
               
            }
            if (m_apduPlayer.Auth == false)
            {
                m_apduPlayer.m_apduLogString += String.Format("{0} | Gemalto Chip Authentication Failed [{1}]\n", System.DateTime.Now, m_apduPlayer.Auth.ToString());

                return false;
            }
            m_apduPlayer.NonDerived = false;
            m_apduPlayer.m_apduLogString += String.Format("{0} | Below are configuration.....\n", System.DateTime.Now);
            m_apduPlayer.m_apduLogString += String.Format("{0} | Encryption Key [{1}]\n", System.DateTime.Now, m_apduPlayer.encryptionKey);
            m_apduPlayer.m_apduLogString += String.Format("{0} | IsGemalto [{1}]\n", System.DateTime.Now, m_apduPlayer.IsGemalto.ToString());
            m_apduPlayer.m_apduLogString += String.Format("{0} | NonDerived [{1}]\n", System.DateTime.Now, m_apduPlayer.NonDerived.ToString());
            if (m_apduPlayer.Auth && chkgemalto.IsChecked == true)
            {
                m_apduPlayer.m_apduLogString += String.Format("{0} | Gemalto Chip Authentication Successfully [{1}]\n", System.DateTime.Now, m_apduPlayer.Auth.ToString());
                //Authentication Done Successfully.
                //Default ISD
                //A0000001510000    (Default)
                //A0000000040000    (MChip)
                //A0000000030000    (Visa)
                //Delete MChip Debit/Credit AID
                //4F07A0000000041010
                //m_apduPlayer.DeleteCommand("4F07A0000000041010");
                //Delete Visa Debit/Credit AID
                //4F07A0000000031010
                m_apduPlayer.DeleteCommand("4F07A0000000031010");
                m_apduPlayer.m_apduLogString += String.Format("{0} | DeleteCommand for  [{1}]\n", System.DateTime.Now, " VISA Applet completed Successfully");
                //Delete Visa Electron AID
                //4F07A0000000032010
                //m_apduPlayer.DeleteCommand("4F07A0000000032010");
                //Delete PSE
                //4F0E315041592E5359532E4444463031
                m_apduPlayer.DeleteCommand("4F0E315041592E5359532E4444463031");
                m_apduPlayer.m_apduLogString += String.Format("{0} | DeleteCommand for  [{1}]\n", System.DateTime.Now, " VISA PSE Applet completed Successfully");
                //Delete PPSE
                //4F0E325041592E5359532E4444463031
                //m_apduPlayer.DeleteCommand("4F0E325041592E5359532E4444463031");
                //Authentication After Deletion
                //m_apduPlayer.Authentication("A0000000030000");
                //Install Gemalto GFX5 MChip
                //0cA0000000180F0000018330320bA0000000180F000001830307A0000000041010010008C90600000000020200
                //m_apduPlayer.InstallCommand("0cA0000000180F0000018330320bA0000000180F000001830307A0000000041010010008C90600000000020200");
                //Install Gemalto GFX5 PSE (MChip)
                //10A00000001830070100000000000001FF0fA000000018300701000000000000010e315041592E5359532E4444463031010004C902014000
                //m_apduPlayer.InstallCommand("10A00000001830070100000000000001FF0fA000000018300701000000000000010e315041592E5359532E4444463031010004C902014000");
                //Install Gemalto GFX5 Visa 
                //08A00000000310102407A000000003101007A0000000031010011204C902010400
                m_apduPlayer.InstallCommand("08A00000000310102407A000000003101007A0000000031010011204C902010400");
                //Install Gemalto GFX5 PSE (Visa)
                m_apduPlayer.InstallCommand("10A00000001830070100000000000001FF0fA000000018300701000000000000010e315041592E5359532E4444463031010004C902015000");
                m_apduPlayer.InstallCommand("06A0000000031607A00000000316500E315041592E5359532E4444463031010004C902015000");
                //Install Gemalto GFX5 PSSE (Visa)
                //10A00000001830070100000000000001FF0fA000000018300701000000000000010e315041592E5359532E4444463031010004C902015000
                m_apduPlayer.InstallCommand("06A0000000031607A00000000316500E325041592E5359532E4444463031010003C9010000");
                string StoreData = "91041282023900940C080104001001010010020201910235A533500A566973612044656269748701015F2D04656E61729F1101019F120E5149422056697361204465626974BF0C059F4D020B10010133703157134140820086948694D24072211000069406940F5F2019343134303832303038363934383639342f544553544341524401028200FE7081FB9081F80EBC2D71D7A78710195F339D4F22D09F0F6E69E856E384161A92981D3414D40B9D2793AF56EF0CD204BB7B251677DAC2C72761BBAC3DC705956CACCAB724D85618D4551B96CA9FEDB82E688042F4198ABDE8E39F6D25C554B6D6731D24BEC6600C15E58993F6E73AF9171B9A4797978B21BA28C56F3A764FAB0B7662D4F0D642F60DFF4E3AB36826A1AF3F305B3AED260B11A0F992FBD30B984EA699ADB75C6571E9C12ECE120EC6E6E9E536CFC39F180F1C953EBF365C9E55EDF41A3E559EA10C9514628886CF2A94D9B609E353EBFE39D98501A10DE1506CFDB24A0A8A4E9C1D131F27571E46BB708AB2E5783DE04150CC3A0D008E508901033870369F4701039F49039F37049F3201038F019492237EDE408A456259942EF30827C76783B7796EA761180A90C569E4AC074225E28010C21301048200FE7081FB9F4681F71EAAE5A4723F339FEA87E88EEE7CA72A1C907379DF953F7018A55D91315BCF9F5DF67DD9308874CB9EA89B97201BDE51F9280AE23F2204039DEAE18808723FE80977C4204000E560AE964578E3CAADB79859D645E367BA946942CF1E30C6D52CC7EE0CBD6D27719D4275BBF767E8A861DBA2975658488DBF604E1620F7CBFFCCC019ED79E133497F3E0B3333DA6DEBA2D411285287001A66BA9AB3A5DAF41766EE425AACC95C32DAE67335694542DC8EF38AEF3BE5BE6EEA77C17BA71D6BB1902A9FF5D284B3B76F83668803867522B0840C202497A700C732C98AA59363DACA70DADFBAE9B679B6D642CADB2EDCC02DA760B674BD8F0E02014770458C159F02069F03069F1A0295055F2A029A039C019F37048D198A029F02069F03069F1A0295055F2A029A039C019F3704910A9F4401029F420206345F300202269F0802009602025470525A0841408200869486945F3401018E100000000000000000020542035E031F029F0D05BC608C88009F0E0500100000009F0F05BC689C98005F24032407315F280206349F0702FF005F25031908089F4A01823000119F4F0E9F27019F02065F2A029A039F36023001249F130200009F510206349F5206C208600000009F5601009F570206349F5801009F59010092000A9F100706010A03000000800030FE8A67DAFDD916344F98E976E3163E08FE8A67DAFDD916344F98E976E3163E08FE8A67DAFDD916344F98E976E3163E0882014076406416A5FB91C6CABA90AD1DCFE25C05CAF97E31FEBCC412AC92D97F8DF1A240C6EDC0BFCEBA853734CFE7A1454456E2B5FC9E5F04B58D3FADB820ADACB1FD8202409BFBBA8238B0DB559860815E83E246504E3F0526AE49794A8D7F02487D292D47FE2597984C4DFE140C9AE536DCAA15DE51973620864702CFFCCD1EBF83FADC1F8203409DC115A1EA466E93C784E9625AFAFCADC4AABA9F55BC9E9BC4DC7F1A9D316F9FDC7046EBA37C8A10046240D0B3EB9B065505845B8363E6482CEB137F21A0DBFF820440E9F997C3550949006490C20DC5D36978755E87BA056E35EFD43E836CBBBDC3EBFD3863647274FD1E12E857D24AFF20CD7A62D130C96A8437FB33AE1F45F84A2F820540ECA1A072DF69A5DDAB475E1388787B04A70017EF009AEDE9A74ABEA7EBCA276FCAA86A61753ACF18069361390DE168897F8846894515D96C43609D3EB27149FF8010089F31E4F02E51BD3F9010020303";
                m_apduPlayer.Personalization(StoreData, StoreData.Length, "A0000000031010");
                StoreData = "010129702761254F07A0000000031010500A566973612044656269749F120A56697361204465626974870101910210A50E8801015F2D04656E61729F110101";
                m_apduPlayer.Personalization(StoreData, StoreData.Length, "315041592E5359532E4444463031");
                //Write anywhere m_apduPlayer.m_apduLogString for Log    
                 file_name = "e:\\ " + "Personalizelog.txt";
                using (StreamWriter objWriter = new StreamWriter(file_name, true))
                {
                    objWriter.Write(m_apduPlayer.m_apduLogString);
                }
            }
            else if(m_apduPlayer.Auth && chkgemalto.IsChecked == false)
            {
                //Authentication Done Successfully.
                m_apduPlayer.m_apduLogString += String.Format("{0} | Other Chip Authentication Successfully [{1}]\n", System.DateTime.Now, m_apduPlayer.Auth.ToString());
                //Default ISD
                //A0000001510000    (Default)
                //A0000000040000    (MChip)
                //A0000000030000    (Visa)
                //Delete MChip Debit/Credit AID
                //4F07A0000000041010
                //m_apduPlayer.DeleteCommand("4F07A0000000041010");
                //Delete Visa Debit/Credit AID
                //4F07A0000000031010
                m_apduPlayer.DeleteCommand("4F07A0000000031010");
                m_apduPlayer.m_apduLogString += String.Format("{0} | DeleteCommand for  [{1}]\n", System.DateTime.Now, " VISA Applet completed Successfully");
                //Delete Visa Electron AID
                //4F07A0000000032010
                //m_apduPlayer.DeleteCommand("4F07A0000000032010");
                //Delete PSE
                //4F0E315041592E5359532E4444463031
                m_apduPlayer.DeleteCommand("4F0E315041592E5359532E4444463031");
                m_apduPlayer.m_apduLogString += String.Format("{0} | DeleteCommand for  [{1}]\n", System.DateTime.Now, " VISA PSE Applet completed Successfully");
                //Delete PPSE
                m_apduPlayer.DeleteCommand("4F0E325041592E5359532E4444463031");
                m_apduPlayer.m_apduLogString += String.Format("{0} | DeleteCommand for  [{1}]\n", System.DateTime.Now, " VISA PPSE Applet completed Successfully");
                //4F0E325041592E5359532E4444463031
                //m_apduPlayer.DeleteCommand("4F0E325041592E5359532E4444463031");
                //Authentication After Deletion
                //m_apduPlayer.Authentication("A0000000030000");
                //Install Gemalto GFX5 MChip
                //0cA0000000180F0000018330320bA0000000180F000001830307A0000000041010010008C90600000000020200
                //m_apduPlayer.InstallCommand("0cA0000000180F0000018330320bA0000000180F000001830307A0000000041010010008C90600000000020200");
                //Install Gemalto GFX5 PSE (MChip)
                //10A00000001830070100000000000001FF0fA000000018300701000000000000010e315041592E5359532E4444463031010004C902014000
                //m_apduPlayer.InstallCommand("10A00000001830070100000000000001FF0fA000000018300701000000000000010e315041592E5359532E4444463031010004C902014000");
                //Install Gemalto GFX5 Visa 
                //08A00000000310102407A000000003101007A0000000031010011204C902010400
                //GFX 5 visa  m_apduPlayer.InstallCommand("08A00000000310102407A000000003101007A0000000031010011204C902010400");
                m_apduPlayer.InstallCommand("06A0000000031007A000000003105607A0000000031010011003C9010100");
                if (m_apduPlayer.apduResp.SW1 != 0x90)
                {
                    m_apduPlayer.m_apduLogString += String.Format("{0} | InstallCommand failed for  [{1}]\n", System.DateTime.Now, m_apduPlayer.apduResp.SW1);
                    return false;
                }
                else
                {
                    
                    //Install Gemalto GFX5 PSE (Visa)
                    //10A00000001830070100000000000001FF0fA000000018300701000000000000010e315041592E5359532E4444463031010004C902015000
                    //GFX5 visa  m_apduPlayer.InstallCommand("10A00000001830070100000000000001FF0fA000000018300701000000000000010e315041592E5359532E4444463031010004C902015000");
                    m_apduPlayer.InstallCommand("06A0000000031607A00000000316500E315041592E5359532E4444463031010004C902015000");
                    if (m_apduPlayer.apduResp.SW1 != 0x90)
                    {
                        m_apduPlayer.m_apduLogString += String.Format("{0} | InstallCommand failed for  [{1}]\n", System.DateTime.Now, m_apduPlayer.apduResp.SW1);
                        return false;
                    }
                    else
                    {
                   
                      
                        //Install Gemalto GFX5 PSSE (Visa)                  
                        m_apduPlayer.InstallCommand("06A0000000031607A00000000316500E325041592E5359532E4444463031010003C9010000");
                        if (m_apduPlayer.apduResp.SW1 != 0x90)
                        {
                            m_apduPlayer.m_apduLogString += String.Format("{0} | InstallCommand failed for  [{1}]\n", System.DateTime.Now, m_apduPlayer.apduResp.SW1);
                            return false;
                        }
                        else
                        {
                          
                          
                            //  GFX5 Visa string StoreData = "91041282023900940C080104001001010010020201910235A533500A566973612044656269748701015F2D04656E61729F1101019F120E5149422056697361204465626974BF0C059F4D020B10010133703157134140820086948694D24072211000069406940F5F2019343134303832303038363934383639342f544553544341524401028200FE7081FB9081F80EBC2D71D7A78710195F339D4F22D09F0F6E69E856E384161A92981D3414D40B9D2793AF56EF0CD204BB7B251677DAC2C72761BBAC3DC705956CACCAB724D85618D4551B96CA9FEDB82E688042F4198ABDE8E39F6D25C554B6D6731D24BEC6600C15E58993F6E73AF9171B9A4797978B21BA28C56F3A764FAB0B7662D4F0D642F60DFF4E3AB36826A1AF3F305B3AED260B11A0F992FBD30B984EA699ADB75C6571E9C12ECE120EC6E6E9E536CFC39F180F1C953EBF365C9E55EDF41A3E559EA10C9514628886CF2A94D9B609E353EBFE39D98501A10DE1506CFDB24A0A8A4E9C1D131F27571E46BB708AB2E5783DE04150CC3A0D008E508901033870369F4701039F49039F37049F3201038F019492237EDE408A456259942EF30827C76783B7796EA761180A90C569E4AC074225E28010C21301048200FE7081FB9F4681F71EAAE5A4723F339FEA87E88EEE7CA72A1C907379DF953F7018A55D91315BCF9F5DF67DD9308874CB9EA89B97201BDE51F9280AE23F2204039DEAE18808723FE80977C4204000E560AE964578E3CAADB79859D645E367BA946942CF1E30C6D52CC7EE0CBD6D27719D4275BBF767E8A861DBA2975658488DBF604E1620F7CBFFCCC019ED79E133497F3E0B3333DA6DEBA2D411285287001A66BA9AB3A5DAF41766EE425AACC95C32DAE67335694542DC8EF38AEF3BE5BE6EEA77C17BA71D6BB1902A9FF5D284B3B76F83668803867522B0840C202497A700C732C98AA59363DACA70DADFBAE9B679B6D642CADB2EDCC02DA760B674BD8F0E02014770458C159F02069F03069F1A0295055F2A029A039C019F37048D198A029F02069F03069F1A0295055F2A029A039C019F3704910A9F4401029F420206345F300202269F0802009602025470525A0841408200869486945F3401018E100000000000000000020542035E031F029F0D05BC608C88009F0E0500100000009F0F05BC689C98005F24032407315F280206349F0702FF005F25031908089F4A01823000119F4F0E9F27019F02065F2A029A039F36023001249F130200009F510206349F5206C208600000009F5601009F570206349F5801009F59010092000A9F100706010A03000000800030FE8A67DAFDD916344F98E976E3163E08FE8A67DAFDD916344F98E976E3163E08FE8A67DAFDD916344F98E976E3163E0882014076406416A5FB91C6CABA90AD1DCFE25C05CAF97E31FEBCC412AC92D97F8DF1A240C6EDC0BFCEBA853734CFE7A1454456E2B5FC9E5F04B58D3FADB820ADACB1FD8202409BFBBA8238B0DB559860815E83E246504E3F0526AE49794A8D7F02487D292D47FE2597984C4DFE140C9AE536DCAA15DE51973620864702CFFCCD1EBF83FADC1F8203409DC115A1EA466E93C784E9625AFAFCADC4AABA9F55BC9E9BC4DC7F1A9D316F9FDC7046EBA37C8A10046240D0B3EB9B065505845B8363E6482CEB137F21A0DBFF820440E9F997C3550949006490C20DC5D36978755E87BA056E35EFD43E836CBBBDC3EBFD3863647274FD1E12E857D24AFF20CD7A62D130C96A8437FB33AE1F45F84A2F820540ECA1A072DF69A5DDAB475E1388787B04A70017EF009AEDE9A74ABEA7EBCA276FCAA86A61753ACF18069361390DE168897F8846894515D96C43609D3EB27149FF8010089F31E4F02E51BD3F9010020303";
                            string StoreData = "91023AA538500B56697361204372656469748701015F2D04656E61729F1101019F120F514942205669736120437265646974BF0C089F5A056006340634910355A553500B56697361204372656469748701019F38189F66049F02069F03069F1A0295055F2A029A039C019F37045F2D04656E61729F120F5149422056697361204372656469749F110101BF0C089F5A05600634063491041A82023800941408020200100102001004050018010101180202009115428202000094042001010057134140820086948694D24072211000069406940F5F3401019F100706010A030000009F26089F27019F36029F6C0200009F6E042070000091174E8202200094101002020010050600180303011003030057134140820086948694D24072211000069406940F9F100706010A030000009F26089F27019F36029F4B81809F6C0200009F6E0420700000010133703157134140820086948694D24072211000069406940F5F2019343134303832303038363934383639342f5445535443415244010233703157134140820086948694D24072211000069406940F5F2019343134303832303038363934383639342f544553544341524402010C700A9F4701039F49039F370402022E702C8F01949F32010392237EDE408A456259942EF30827C76783B7796EA761180A90C569E4AC074225E28010C21302031E701C9F4701035F3401015F280206349F0702C0009F69070100000000000002048200FE7081FB9F4681F73B85C69884E1BE5FEA57679E1FE5ECC086CF420C6EF2DE2FEFF9DACD81EEBD265978463A83B75912FFD6AB21936CF8E340CCC47990E62FCB965DDF005B2620BD8D159C0EE30D0A5A635E9BF7FD1B8331DFA61438D112C7153E45BB061BBB0774D6119260A817D5B5447FD48C873283CFCCF7AD34AC2BEB96F164591E209D90442DF3127DFD7AF69E34EB140E662C627266235922D38EDA4E91060C134610E11992AF9F0CD56BF7360815B8601D624B4E287106B52F3B69599DB513F92DCB53A743B10D8EE66AC9B0D59C3EEAF6C447AD2CA37A43F5A05D83AF8B2DC7CF526AEDFC19D3EDC94D90561A5C3A73E1F674BDCB310262D1597302058200FE7081FB9081F80EBC2D71D7A78710195F339D4F22D09F0F6E69E856E384161A92981D3414D40B9D2793AF56EF0CD204BB7B251677DAC2C72761BBAC3DC705956CACCAB724D85618D4551B96CA9FEDB82E688042F4198ABDE8E39F6D25C554B6D6731D24BEC6600C15E58993F6E73AF9171B9A4797978B21BA28C56F3A764FAB0B7662D4F0D642F60DFF4E3AB36826A1AF3F305B3AED260B11A0F992FBD30B984EA699ADB75C6571E9C12ECE120EC6E6E9E536CFC39F180F1C953EBF365C9E55EDF41A3E559EA10C9514628886CF2A94D9B609E353EBFE39D98501A10DE1506CFDB24A0A8A4E9C1D131F27571E46BB708AB2E5783DE04150CC3A0D008E508902068200FE7081FB9F4681F741550EA6214742176CD45F9B3226561400D91EADE41CD1E7BAA1794610218AD771EA58FBF0E305B7DBAA6EF37269C54B33634D8BDDE8FAD6B67E65CF364A0BF16C1DFD609D8263F2F7DC7868AEB780A791482669EFD594A29935F385C13F558605FFF21EC358574748FB31B1B02A9850D7246DDB11D991583DD5ED5DF568DC5F4A4DC4C581753881A4E5D2125E3E9FA96E6EDB08CFFBD10DE8BE6CA0BA52954AA3108EAB1CF6DC00CD12D87E679D110F5817CC757CA0295777787448F066E71C0F00FAA1F1B397D89CE12D96218F41EBD9E90FE03AB9F55A45E38700F3E6C453791B36D339A85F6ED1C87E8C542DEABDE0BEFD3D36AAA203015270505A0841408200869486945F24032407318E0E000000000000000042035E031F029F0D05B8608C88009F0E0500100000009F0F05B8689C98005F25031908085F3401019F0702FF005F280206349F4A018203023D703B9F080200968C159F02069F03069F1A0295055F2A029A039C019F37048D198A029F02069F03069F1A0295055F2A029A039C019F3704910A9F44010203031270105F24032407315A08414082008694869404010C700A9F0702C0005F2802063492000A9F100706010A0300000030015C57134140820086948694D24072211000069406940F5F2019343134303832303038363934383639342f54455354434152445F3401019F510206349F5206C208000000009F5601009F570206349F6301009F68040080D0009F6C0200003F552CDF210100DF310100DF5106000000000000DF4106000000000000DF6106000000000000DF71060000000000003F560CDF110100DF210100DF3101003F5714DF110100DF210100DF310100DF510100DF6101003F5809DF11060000000000003F5B05DF01028000820140A4A559D435C5EE752E0ACB0E046732C227BBC82387791E201C08D5EC41CB417A557CEF018BAFBBDF21162395CCB4C6B65EA38ED402F2C3B6094FB49E1AC5ACF28202409A39BCA1F977D64F8DF7B074D36A7F8185F2ADAF87C06EBEE79F3DB8D623EF1CFF5BAA4D923E959B44A3F01488E88A9F9708B52A8C1B89ED4E0D9998E5B99ED7820340A1050B9758E748B0964788131C8378969C65863DD0596CE901753723186E577424F3375215221A491AF847FC8795C1049EABD70362DDBDCA554682C7081C1693820440E7569AF2F633C17754F388AF3D1FBF4248EC04874BA0A61E5B6EDC954135E6AB7F097F745B5DE068E6F5E81ECD5CCFEF628D0FBFD2294EE3F514666558966E43820540F1879163055AED08E16B4C1CAAC534E1EA98495CB886235D822FD2B4A4A5832E376CD2FB1FB3276DA8746BFACB60A186EE01C285144C9CAF7FE9C42A8C2A21DD800030FE8A67DAFDD916344F98E976E3163E08FE8A67DAFDD916344F98E976E3163E08FE8A67DAFDD916344F98E976E3163E089010020303";
                            m_apduPlayer.Personalization(StoreData, StoreData.Length, "A0000000031010");
                            if (m_apduPlayer.apduResp.SW1 != 0x90)
                            {
                                m_apduPlayer.m_apduLogString += String.Format("{0} | Personalization failed for  [{1}]\n", System.DateTime.Now, m_apduPlayer.apduResp.SW1);

                                using (StreamWriter objWriter = new StreamWriter(file_name, true))
                                {
                                    objWriter.Write(m_apduPlayer.m_apduLogString);
                                }
                                return false;
                            }                        
                            else
                            {
                                
                                
                                StoreData = "010129702761254F07A0000000031010500A566973612044656269749F120A56697361204465626974870101910210A50E8801015F2D04656E61729F110101";
                                m_apduPlayer.Personalization(StoreData, StoreData.Length, "315041592E5359532E4444463031");
                                if (m_apduPlayer.apduResp.SW1 != 0x90)
                                {
                                    //Write anywhere m_apduPlayer.m_apduLogString for Log
                                    //  objRio.EjectCard();
                                     file_name = "e:\\ " + "Personalizelog.txt";
                                    using (StreamWriter objWriter = new StreamWriter(file_name, true))
                                    {
                                        objWriter.Write(m_apduPlayer.m_apduLogString);
                                    }
                                    return false;
                                }
                                else
                                {
                                    file_name = "e:\\ " + "Personalizelog.txt";
                                    using (StreamWriter objWriter = new StreamWriter(file_name, true))
                                    {
                                        objWriter.Write(m_apduPlayer.m_apduLogString);
                                    }
                                    return true;
                                }
                            }                           
                        }
                    }                   
                }                      
            }
            return false;
        }
       
        private void Btn_perso_Click(object sender, RoutedEventArgs e)
        {
            bool str= chipperso();
            if (str==true)
            {
                MessageBox.Show("Chip Card Personalized Now Ready to Move for printing");
            }
            else
            {
                MessageBox.Show("Failed");
            }
        }

        public bool Print_Card()
        {
            //objRio.PrintCards( "", 1);
            return true;
        }

        private void Btn_eject_Click(object sender, RoutedEventArgs e)
        {

          bool res=  objRio.EjectCard();

            if (res)
            {
                System.Windows.MessageBox.Show("Eject Card Successfully");
            }
            else
            {
                System.Windows.MessageBox.Show("Eject Failed Successfully");
            }
        }
        private void SetAttributeValue(CustomTreeNode node,
                               string propertyName, string value)
        {
            //log.LogFile(class_name, "Information", "Setting Attribute value for [" + node.Text + "]", logfilename);
            if (propertyName == XmlNodeNameAtt)
            {
                node.Name = value;
                node.Text = value;
            }
            else if (propertyName == XmlNodeTagAtt)
            {
                node.Tag = value;
            }
            else if (propertyName == XmlNodeIndexAtt)
            {
                node.Index = Convert.ToInt32(value);
            }
            else if (propertyName == XmlNodeTypeAtt)
            {
                node.Type = value;
            }
            else if (propertyName == XmlNodeEncodingAtt)
            {
                node.LengthEncoding = value;
            }
            else if (propertyName == XmlNodeRoleAtt)
            {
                node.Role = value;
            }
            else if (propertyName == XmlNodeEncKeyAtt)
            {
                node.EncKey = value;
            }
            else if (propertyName == XmlNodeEncModeAtt)
            {
                node.EncMode = value;
            }
            else if (propertyName == XmlNodePaddAtt)
            {
                node.PaddMode = value;
            }
            else if (propertyName == XmlNodeOriginAtt)
            {
                node.Origin = value;
            }
            else if (propertyName == XmlNodeValueAtt)
            {
                node.Value = value;
            }
            else if (propertyName == XmlNodePathAtt)
            {
                node.Path = value;
            }
            else if (propertyName == XmlNodeAuthAtt)
            {
                node.IsAuthSFI = value;
            }
            else if (propertyName == XmlNodeFormat)
            {
                node.Format = value;
            }
        }

        private void Btn_form1_Click(object sender, RoutedEventArgs e)
        {
            test ts = new test();
            ts.Show();
        }

        private void Btn_ipk_Copy_Click(object sender, RoutedEventArgs e)
        {
            //test2 ts2 = new test2();
            //ts2.Show();
        }

       
        public void DeserializeTreeView(TreeView treeView, Stream XMLStream)
        {
            XmlTextReader reader = null;
            try
            {
               // log.LogFile(class_name, "Information", "Creating Treeview form XML File. File Name [" + XMLStream.ToString() + "]", logfilename);
                // disabling re-drawing of treeview till all nodes are added
                //treeView.BeginUpdate();
                reader = new XmlTextReader(XMLStream);
                CustomTreeNode parentNode = null;
               

                while (reader.Read())
                {
                    if (reader.NodeType == XmlNodeType.Element)
                    {
                        if (reader.Name == XmlNodeTag)
                        {
                            CustomTreeNode newNode = new CustomTreeNode();
                            bool isEmptyElement = reader.IsEmptyElement;

                            // loading node attributes
                            int attributeCount = reader.AttributeCount;
                            if (attributeCount > 0)
                            {
                                for (int i = 0; i < attributeCount; i++)
                                {
                                    reader.MoveToAttribute(i);
                                    SetAttributeValue(newNode, reader.Name, reader.Value);
                                }
                            }
                            // add new node to Parent Node or TreeView
                            if (parentNode != null)
                                parentNode.Nodes.Add(newNode);
                            else
                               // treeView.Nodes.Add(newNode);

                            // making current node 'ParentNode' if its not empty
                            if (!isEmptyElement)
                            {
                                parentNode = newNode;
                            }
                        }
                    }
                    // moving up to in TreeView if end tag is encountered
                    else if (reader.NodeType == XmlNodeType.EndElement)
                    {
                        if (reader.Name == XmlNodeTag)
                        {
                            //parentNode = (CustomTreeNode)parentNode.Parent;
                        }
                    }
                    else if (reader.NodeType == XmlNodeType.XmlDeclaration)
                    {
                        //Ignore Xml Declaration                    
                    }
                    else if (reader.NodeType == XmlNodeType.None)
                    {
                        return;
                    }
                    else if (reader.NodeType == XmlNodeType.Text)
                    {
                        parentNode.Nodes.Add(reader.Value);
                    }

                }
              //  log.LogFile(class_name, "Information", "Treeview created from File. File Name [" + XMLStream.ToString() + "]", logfilename);
            }
            finally
            {
                // enabling redrawing of treeview after all nodes are added
                //treeView.EndUpdate();
               
                reader.Close();
            }
        }
        private void Button_Click(object sender, RoutedEventArgs e)
        {
           string str = @"C:\inetpub\wwwroot\webqib\XML\TEST MP2323V2 533103 MCHIP DEBIT.XML";
        }
        private void HandleError(string action, SDK.Return result)
        {
            string error;

            switch (result)
            {
                case SDK.Return.Timeout: error = "ID_TIMEOUT"; break;
                case SDK.Return.Error: error = "ID_ERROR"; break;
                case SDK.Return.PrinterError: error = "ID_PRINTER_ERROR"; break;
                case SDK.Return.DriverNotCompliant: error = "ID_DRIVER_NOTCOMPLIANT"; break;
                case SDK.Return.OpenPrinterError: error = "ID_OPENPRINTER_ERROR"; break;
                case SDK.Return.RemoteCommError: error = "ID_REMOTECOMM_ERROR"; break;
                case SDK.Return.LocalCommError: error = "ID_LOCALCOMM_ERROR"; break;
                case SDK.Return.SpoolerNotEmpty: error = "ID_SPOOLER_NOT_EMPTY"; break;
                case SDK.Return.RemoteCommInUse: error = "ID_REMOTECOMM_IN_USE"; break;
                case SDK.Return.LocalCommInUse: error = "ID_LOCALCOMM_IN_USE"; break;
                case SDK.Return.ParamError: error = "ID_PARAM_ERROR"; break;
                case SDK.Return.InvalidSession: error = "ID_INVALID_SESSION"; break;
                default: error = "Unknown API Error - " + result; break;
            }
            MessageBox.Show(action + ": " + error);
        }
        //public void printcard()
        //{
        //    int hSession_value = 0;
        //    // ps = pd.PrinterSettings;
        //    g = ps.CreateMeasurementGraphics();
        //    hDC = g.GetHdc();
        //    SDK.Config Config = (new KeyValuePair<SDK.Config, string>(SDK.Config.Normal, "Normal").Key);
        //    SDK.Return SDKReturn = SDK.ID_OpenSession(hDC, out hSession, Config);
        //    hSession_value = (int)hSession;
        //    if (SDKReturn != SDK.Return.Success)
        //    {
        //        SDK.ID_CloseSession(hSession);

        //        //return false;
        //    }
        //    SDK.MagDef Encode = new SDK.MagDef();
        //    if (hSession_value != 0) // session remains printer perform 
        //    {
        //        do
        //        {
        //            //Is there a front to be printed?
        //            if (true)//CardFront.Checked
        //            {
        //                //Initialise Front Canvas
        //                SDK.PrintSetting PrintSettings = new SDK.PrintSetting();
        //                SDK.PrintSetting OldPrintSettings = new SDK.PrintSetting();
        //                SDKReturn = SDK.ID_PrintSettings(hSession, SDK.Action.Read, OldPrintSettings);
        //                if (SDKReturn != SDK.Return.Success)
        //                {
        //                    HandleError("OldPrintSettings", SDKReturn);
        //                    break;
        //                }
        //                PrintSettings = OldPrintSettings;
        //                //Determine which sides of the card need to be printed

        //                PrintSettings.Duplex = SDK.Duplex.Both;

        //                //Change the print settings for the card
        //                SDKReturn = SDK.ID_PrintSettings(hSession, SDK.Action.Write, PrintSettings);
        //                if (SDKReturn != SDK.Return.Success)
        //                {
        //                    HandleError("WritePrintSettings", SDKReturn);
        //                    break;
        //                }
        //                SDKReturn = SDK.ID_CanvasInit(hSession, out FrontDC, SDK.Canvas.Front);
        //                if (SDKReturn != SDK.Return.Success)
        //                {
        //                    HandleError("CanvasInitFront", SDKReturn);
        //                    break;
        //                }
        //                if (true)//TextFrontEnabled.Checked
        //                {
        //                    //Card Number 
        //                    TextDefn.FontName = "Arial";
        //                    TextDefn.FontSize = Convert.ToInt16(cardnosize.Text);
        //                    //TextDefn.FontColour = ((KeyValuePair<System.Drawing.Color, string>)TextFrontColourBox.SelectedItem).Key;
        //                    TextDefn.FontStyle = 0;
        //                    //Get the location and angle for the text
        //                    TextDefn.X = Convert.ToInt16(txtcardnoX.Text);
        //                    TextDefn.Y = Convert.ToInt16(txtcardnoY.Text);
        //                    TextDefn.Angle = 0;
        //                    //Get the text to be drawn
        //                    TextDefn.Text = txtcrdno.Text;
        //                    //Call the SDK function to draw the text on the canvas
        //                    SDKReturn = SDK.ID_DrawText(hSession, false ? SDK.Canvas.FrontResin : SDK.Canvas.Front, TextDefn);
        //                    if (SDKReturn != SDK.Return.Success)
        //                    {
        //                        HandleError("DrawTextFront", SDKReturn);
        //                        break;
        //                    }
        //                    //Name on Card
        //                    TextDefn.FontName = "Arial";
        //                    TextDefn.FontSize = Convert.ToInt16(txtCardnamesize.Text);
        //                    // TextDefn.FontColour = ((KeyValuePair<Color, string>)TextFrontColourBox.SelectedItem).Key;
        //                    TextDefn.FontStyle = 0;
        //                    TextDefn.X = Convert.ToInt16(txtcardnameX.Text);
        //                    TextDefn.Y = Convert.ToInt16(txtCardnameY.Text);
        //                    TextDefn.Angle = 0;
        //                    TextDefn.Text = txtcardname.Text;
        //                    ////Call the SDK function to draw the text on the canvas
        //                    SDKReturn = SDK.ID_DrawText(hSession, false ? SDK.Canvas.FrontResin : SDK.Canvas.Front, TextDefn);
        //                    if (SDKReturn != SDK.Return.Success)
        //                    {
        //                        HandleError("DrawTextFront", SDKReturn);
        //                        break;
        //                    }
        //                    //Valid
        //                    TextDefn.FontName = "Arial";
        //                    TextDefn.FontSize = Convert.ToInt16(txtValidsize.Text);
        //                    // TextDefn.FontColour = ((KeyValuePair<Color, string>)TextFrontColourBox.SelectedItem).Key;
        //                    TextDefn.FontStyle = 0;
        //                    TextDefn.X = Convert.ToInt16(txtValidX.Text);
        //                    TextDefn.Y = Convert.ToInt16(txtValidY.Text);
        //                    TextDefn.Angle = 0;
        //                    TextDefn.Text = txtvalid.Text;
        //                    ////Call the SDK function to draw the text on the canvas
        //                    SDKReturn = SDK.ID_DrawText(hSession, false ? SDK.Canvas.FrontResin : SDK.Canvas.Front, TextDefn);
        //                    if (SDKReturn != SDK.Return.Success)
        //                    {
        //                        HandleError("DrawTextFront", SDKReturn);
        //                        break;
        //                    }
        //                    //expiry
        //                    TextDefn.FontName = "Arial";
        //                    TextDefn.FontSize = Convert.ToInt16(txtExpirySize.Text);
        //                    //TextDefn.FontColour = ((KeyValuePair<System.Drawing.Color, string>)TextFrontColourBox.SelectedItem).Key;
        //                    TextDefn.FontStyle = 0;
        //                    TextDefn.X = Convert.ToInt16(txtExpiryX.Text);
        //                    TextDefn.Y = Convert.ToInt16(txtExpiryY.Text);
        //                    TextDefn.Angle = 0;
        //                    TextDefn.Text = txtexpry.Text;
        //                    ////Call the SDK function to draw the text on the canvas
        //                    SDKReturn = SDK.ID_DrawText(hSession, false ? SDK.Canvas.FrontResin : SDK.Canvas.Front, TextDefn);
        //                    if (SDKReturn != SDK.Return.Success)
        //                    {
        //                        HandleError("DrawTextFront", SDKReturn);
        //                        break;
        //                    }
        //                }
        //            }
        //            //-------------------------------------------------------------------
        //            //Is there a back to be printed?
        //            if (true)//CardBack.Checked
        //            {
        //                SDK.CardSetting BackSettings = new SDK.CardSetting();
        //                SDK.CardSetting OldBackSettings = new SDK.CardSetting();
        //                //Read the current settings for the Back of the card
        //                SDKReturn = SDK.ID_CardSettings(hSession, SDK.Action.Read, SDK.Side.Back, OldBackSettings);
        //                if (SDKReturn != SDK.Return.Success)
        //                {
        //                    HandleError("OldCardSettings", SDKReturn);
        //                    break;
        //                }
        //                BackSettings = OldBackSettings;

        //                if (SDKReturn != SDK.Return.Success)
        //                {
        //                    HandleError("OldCardSettings", SDKReturn);
        //                    break;
        //                }
        //                BackSettings = OldBackSettings;
        //                SDKReturn = SDK.ID_CardSettings(hSession, SDK.Action.Write, SDK.Side.Back, BackSettings);
        //                if (SDKReturn != SDK.Return.Success)
        //                {
        //                    HandleError("CardSettingsBack", SDKReturn);
        //                    break;
        //                }
        //                //Initialise Rear Canvas
        //                SDKReturn = SDK.ID_CanvasInit(hSession, out BackDC, SDK.Canvas.Back);
        //                if (SDKReturn != SDK.Return.Success)
        //                {
        //                    HandleError("CanvasInitBack", SDKReturn);
        //                    break;
        //                }
        //                TextDefn.FontName = "Arial";
        //                TextDefn.FontSize = Convert.ToInt16(txtCVVY_Size.Text);
        //                // TextDefn.FontColour = ((KeyValuePair<System.Drawing.Color, string>)TextFrontColourBox.SelectedItem).Key;
        //                TextDefn.FontStyle = 0;
        //                TextDefn.X = Convert.ToInt16(txtCVVX.Text);
        //                TextDefn.Y = Convert.ToInt16(txtCVVY.Text);
        //                TextDefn.Angle = 0;
        //                TextDefn.Text = cvv.Text;
        //                //Call the SDK function to draw the text on the canvas
        //                SDKReturn = SDK.ID_DrawText(hSession,
        //                                            false ? SDK.Canvas.BackResin : SDK.Canvas.Back,
        //                                            TextDefn);
        //                if (SDKReturn != SDK.Return.Success)
        //                {
        //                    HandleError("DrawTextback", SDKReturn);
        //                    break;
        //                }
        //            }
        //            //-------------------------------------------------------------------
        //            //Print the Card
        //            SDKReturn = SDK.ID_PrintCard(hSession);
        //            if (SDKReturn != SDK.Return.Success)
        //            {
        //                HandleError("PrintCard", SDKReturn);
        //                break;
        //            }
        //            //Wait for the printing to complete
        //            WaitForPrinterToFinish();
        //            SDKReturn = SDK.ID_CloseSession(hSession);
        //        }

        //        while (false);  //End of single pass do..while loop

        //    }
        //    else
        //    {
        //        System.Windows.MessageBox.Show("Cannot Print - Printer is not available");
        //        return;
        //    }
        //}

        private void WaitForPrinterToFinish()
        {
            // Cursor.Current = Cursors.WaitCursor;
            SDK.Return SDKReturn;
            do
            {
                //Repeat the wait until response is not timeout
                SDKReturn = SDK.ID_WaitForPrinter(hSession);
            } while (SDKReturn == SDK.Return.Timeout);
            if (SDKReturn != SDK.Return.Success)
            {
                System.Windows.MessageBox.Show("Printer Response" + SDKReturn);

            }
        }
        public void connect_card(string ReaderName, SHARE ShareMode, PROTOCOL Protocol)
        {
            try
            {
                m_iCard.Connect(ReaderName, ShareMode, Protocol);
                m_apduPlayer = new APDUPlayer(m_iCard);
                m_apduPlayer.m_apduLogString += String.Format("{0} | Card Connected.....\n", System.DateTime.Now);

                try
                {
                    // Get the ATR of the card
                    byte[] atrValue = m_iCard.GetAttribute(SCARD_ATTR_VALUE.ATR_STRING);
                    //TextRange textRange = new TextRange(rTxtOutput.Document.ContentStart, rTxtOutput.Document.ContentEnd);

                    //textRange.Text = "Card Connected, ATR : " + ByteArrayToString(atrValue) + "\n" + textRange.Text;
                    m_apduPlayer.m_apduLogString += String.Format("{0} | ATR[{1}]\n", System.DateTime.Now, ByteArrayToString(atrValue));
                }
                catch (Exception ex)
                {
                    // rTxtOutput.Text = "Cannot get ATR\n" + rTxtOutput.Text;
                    m_apduPlayer.m_apduLogString += String.Format("{0} | Exception : [{1}]\n", System.DateTime.Now, ex.Message);
                    m_apduPlayer.m_apduLogString += String.Format("{0} | Details : [{1}]\n", System.DateTime.Now, ex.ToString());

                }

                //btnConnect.Enabled = false;
                //btnDisconnect.Enabled = true;
                //btnPersonalize.Enabled = true;
                //toolStripStatusLabel2.Text = "Connection Established";
                //if (cbDBPerso.Checked)
                //{
                //    SqlParameter prmCardNo = new SqlParameter("@CardNo", tbCardNo.Text);
                //    //DB db = new DB();
                //    DB db = new DB(DBServer, DBName, DBUser, DBPwd);
                //    DataSet dsCrdData = db.ExecuteDataset("SM_ReadSCPTData", prmCardNo);
                //    if (dsCrdData.Tables[0].Rows.Count > 0)
                //    {
                //        ResetAllVar(dsCrdData.Tables[0].Rows[0]["AppletID"].ToString(),
                //            dsCrdData.Tables[0].Rows[0]["LoadAppletCmd"].ToString(),
                //            dsCrdData.Tables[0].Rows[0]["LoadPSECmd"].ToString(),
                //            dsCrdData.Tables[0].Rows[0]["InstallPSECmd"].ToString(),
                //            dsCrdData.Tables[0].Rows[0]["SelectPSECmd"].ToString(),
                //            dsCrdData.Tables[0].Rows[0]["HardKMCValue"].ToString(),
                //            Convert.ToBoolean(dsCrdData.Tables[0].Rows[0]["Crypto_Derived"]),
                //            Convert.ToBoolean(dsCrdData.Tables[0].Rows[0]["LoadApplet"]),
                //            Convert.ToBoolean(dsCrdData.Tables[0].Rows[0]["LoadPSE"]),
                //            Convert.ToBoolean(dsCrdData.Tables[0].Rows[0]["InstallPSE"]),
                //            Convert.ToBoolean(dsCrdData.Tables[0].Rows[0]["SelectPSE"]),
                //            Convert.ToBoolean(dsCrdData.Tables[0].Rows[0]["AppletIDExist"]),
                //            !Convert.ToBoolean(dsCrdData.Tables[0].Rows[0]["HardCodeKMC"]));
                //        string PersoData = dsCrdData.Tables[0].Rows[0]["SCPTCardData"].ToString();
                //        string[] Temp = PersoData.Split('\n');
                //        PSEPersoTags = new List<string>();
                //        NonPSEPersoTags = new List<string>();
                //        foreach (string str in Temp)
                //        {
                //            if (str.StartsWith("$#"))
                //                PSEPersoTags.Add(str.Replace("$#", ""));
                //            else if (str.StartsWith("$"))
                //                NonPSEPersoTags.Add(str.Replace("$", ""));
                //        }
                //        //NonPSEPersoTags
                //        if (SCPT_Perso(false))
                //            MessageBox.Show("Successfully Personalized");
                //        else
                //            MessageBox.Show("Failed to Personalized");
                //    }
                //    else
                //        MessageBox.Show("No record found to Personalized");
                //}
            }
            catch (Exception ex)
            {
                //btnConnect.Enabled = true;
                //btnDisconnect.Enabled = false;
                //btnPersonalize.Enabled = false;

                //toolStripStatusLabel2.Text = ex.Message;
            }

        }
        
       
    }
}
