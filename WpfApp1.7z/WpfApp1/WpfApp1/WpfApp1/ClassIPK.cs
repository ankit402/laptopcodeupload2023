﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Serialization;

namespace WpfApp1
{
    [XmlRoot(ElementName = "Issuer_RSA")]
    public class Issuer_RSA
    {
        [XmlAttribute(AttributeName = "Length")]
        public string Length { get; set; }
        [XmlAttribute(AttributeName = "PublicMod")]
        public string PublicMod { get; set; }
        [XmlAttribute(AttributeName = "PubExponent")]
        public string PubExponent { get; set; }
        [XmlAttribute(AttributeName = "PrivateExp")]
        public string PrivateExp { get; set; }
        [XmlAttribute(AttributeName = "Prime1")]
        public string Prime1 { get; set; }
        [XmlAttribute(AttributeName = "Prime2")]
        public string Prime2 { get; set; }
        [XmlAttribute(AttributeName = "Exp1")]
        public string Exp1 { get; set; }
        [XmlAttribute(AttributeName = "Exp2")]
        public string Exp2 { get; set; }
        [XmlAttribute(AttributeName = "Conf")]
        public string Conf { get; set; }
    }

    [XmlRoot(ElementName = "IPK_Details")]
    public class IPK_Details
    {
        [XmlAttribute(AttributeName = "CA_Index")]
        public string CA_Index { get; set; }
        [XmlAttribute(AttributeName = "IPK_Length")]
        public string IPK_Length { get; set; }
        [XmlAttribute(AttributeName = "IPK_Expiry")]
        public string IPK_Expiry { get; set; }
        [XmlAttribute(AttributeName = "BIN")]
        public string BIN { get; set; }
        [XmlAttribute(AttributeName = "RID")]
        public string RID { get; set; }
        [XmlAttribute(AttributeName = "SHA1")]
        public string SHA1 { get; set; }
    }

    [XmlRoot(ElementName = "Request_IPK")]
    public class Request_IPK
    {
        [XmlAttribute(AttributeName = "IPK_REQUEST_FILE_DATA")]
        public string IPK_REQUEST_FILE_DATA { get; set; }
    }

    [XmlRoot(ElementName = "Request_IPK_Hash")]
    public class Request_IPK_Hash
    {
        [XmlAttribute(AttributeName = "HASH_FILE_DATA")]
        public string HASH_FILE_DATA { get; set; }
    }

    [XmlRoot(ElementName = "Signed_IPK_RAW")]
    public class Signed_IPK_RAW
    {
        [XmlAttribute(AttributeName = "SIGNED_IPK_RAW_DATA")]
        public string SIGNED_IPK_RAW_DATA { get; set; }
    }

    [XmlRoot(ElementName = "Signed_IPK")]
    public class Signed_IPK
    {
        [XmlAttribute(AttributeName = "Signed_Certificate")]
        public string Signed_Certificate { get; set; }
        [XmlAttribute(AttributeName = "Remainder")]
        public string Remainder { get; set; }
    }

    [XmlRoot(ElementName = "Other_Details")]
    public class Other_Details
    {
        [XmlAttribute(AttributeName = "FileName")]
        public string FileName { get; set; }
        [XmlAttribute(AttributeName = "BankName")]
        public string BankName { get; set; }
        [XmlAttribute(AttributeName = "IPK_Request_Request_FileName")]
        public string IPK_Request_Request_FileName { get; set; }
        [XmlAttribute(AttributeName = "Signed_IPK_File_Name")]
        public string Signed_IPK_File_Name { get; set; }
        [XmlAttribute(AttributeName = "Scheame_Name")]
        public string Scheame_Name { get; set; }
        [XmlAttribute(AttributeName = "DateTimeCreation")]
        public string DateTimeCreation { get; set; }
        [XmlAttribute(AttributeName = "DateTimeSigned")]
        public string DateTimeSigned { get; set; }
    }

    [XmlRoot(ElementName = "IPK")]
    public class IPK
    {
        [XmlElement(ElementName = "Issuer_RSA")]
        public Issuer_RSA Issuer_RSA { get; set; }
        [XmlElement(ElementName = "IPK_Details")]
        public IPK_Details IPK_Details { get; set; }
        [XmlElement(ElementName = "Request_IPK")]
        public Request_IPK Request_IPK { get; set; }
        [XmlElement(ElementName = "Request_IPK_Hash")]
        public Request_IPK_Hash Request_IPK_Hash { get; set; }
        [XmlElement(ElementName = "Signed_IPK_RAW")]
        public Signed_IPK_RAW Signed_IPK_RAW { get; set; }
        [XmlElement(ElementName = "Signed_IPK")]
        public Signed_IPK Signed_IPK { get; set; }
        [XmlElement(ElementName = "Other_Details")]
        public Other_Details Other_Details { get; set; }
    }

}
