﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Security.Cryptography;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace WpfApp1.Crypto
{
    public class KeyComponents
    {
        public string keyVal1 { get; set; }
        public string kcvKey1 { get; set; }
        public string keyVal2 { get; set; }
        public string kcvKey2 { get; set; }
        public string keyVal3 { get; set; }
        public string kcvKey3 { get; set; }
        public string keyFinalKey { get; set; }
        public string kcvFinalKey { get; set; }

        public bool isSplit { get; set; }
    }

    public class DESCryptoLib2018
    {
        public static string doXor(string a, string b)
        {
            if (a.Length != b.Length)
                throw new SystemException("Length to be xored not equal");

            byte[] aBytes = Common.HelperFunctions.StringToByteArray(a);
            byte[] bBytes = Common.HelperFunctions.StringToByteArray(b);
            byte[] cBytes = new byte[aBytes.Length];

            for (int i = 0; i < aBytes.Length; i++)
            {
                cBytes[i] = (byte)(aBytes[i] ^ bBytes[i]);
            }

            return Common.HelperFunctions.ByteArrayToString(cBytes);
        }

        public static byte[] doXor(byte[] a, byte[] b)
        {
            if (a.Length != b.Length)
                throw new SystemException("Length to be xored not equal");

            byte[] cBytes = new byte[a.Length];

            for (int i = 0; i < a.Length; i++)
            {
                cBytes[i] = (byte)(a[i] ^ b[i]);
            }

            return cBytes;
        }

        public static void doCombineKey(ref KeyComponents kc)
        {
            if (!Crypto.DESCryptoLib2018.computeKCV(kc.keyVal1).Equals(kc.kcvKey1))
                throw new SystemException("Componen 1: KCV given is not equal with computed KCV!");

            if (!Crypto.DESCryptoLib2018.computeKCV(kc.keyVal2).Equals(kc.kcvKey2))
                throw new SystemException("Componen 2: KCV given is not equal with computed KCV!");

            if (!Crypto.DESCryptoLib2018.computeKCV(kc.keyVal3).Equals(kc.kcvKey3))
                throw new SystemException("Componen 3: KCV given is not equal with computed KCV!");

            string tmp = doXor(kc.keyVal1, kc.keyVal2);
            kc.keyFinalKey = doXor(tmp, kc.keyVal3);

            kc.kcvFinalKey = Crypto.DESCryptoLib2018.computeKCV(kc.keyFinalKey);
        }

        public static byte[] RemoveZeroTrailer(byte[] deciphered)
        {
            int noOfZero = 0;

            for (int i = deciphered.Length - 1; i >= 0; i--)
            {
                if (deciphered[i] == 0x00)
                    noOfZero++;
                else
                    break;
            }

            byte[] newByte = new byte[deciphered.Length - noOfZero];
            Array.Copy(deciphered, newByte, newByte.Length);

            return newByte;
        }

        public static byte[] RemoveZeroHead(byte[] deciphered)
        {
            int noOfZero = 0;

            for (int i = 0; i < deciphered.Length; i++)
            {
                if (deciphered[i] != 0x00)
                    break;
                else
                    noOfZero++;
            }

            byte[] newByte = new byte[deciphered.Length - noOfZero];
            Array.Copy(deciphered, noOfZero, newByte, 0, newByte.Length);

            return newByte;
        }


        public static KeyComponents doSplitKey(string key, string kcv)
        {
            KeyComponents kc = new KeyComponents();

            byte[] finalKey = Common.HelperFunctions.StringToByteArray(key);
            byte[] comp1 = new byte[finalKey.Length];
            byte[] comp3 = new byte[finalKey.Length];

            comp1 = Common.SafenetWrappers.safenetGenRandomBytes(finalKey.Length);
            byte[] tmp = doXor(finalKey, comp1);

            //for simulation/sw
            if (Common.Configurations.isSwHsm)
                Thread.Sleep(1000);

            byte[] comp2 = new byte[finalKey.Length];
            comp2 = Common.SafenetWrappers.safenetGenRandomBytes(finalKey.Length);

            comp3 = doXor(tmp, comp2);

            String x = Crypto.DESCryptoLib2018.computeKCV(key);
            if (kcv != null)
            {
                if (!x.Equals(kcv))
                    throw new SystemException("KCV given is not equal with computed KCV!");
            }

            kc.keyFinalKey = key;
            kc.kcvFinalKey = x;

            kc.keyVal1 = Common.HelperFunctions.ByteArrayToString(comp1);
            kc.kcvKey1 = Crypto.DESCryptoLib2018.computeKCV(kc.keyVal1);

            kc.keyVal2 = Common.HelperFunctions.ByteArrayToString(comp2);
            kc.kcvKey2 = Crypto.DESCryptoLib2018.computeKCV(kc.keyVal2);

            kc.keyVal3 = Common.HelperFunctions.ByteArrayToString(comp3);
            kc.kcvKey3 = Crypto.DESCryptoLib2018.computeKCV(kc.keyVal3);

            return kc;
        }


        public static string computeKCV(string key, string kcvReference = null)
        {
            string kcv = doEncrypTDestStrECB("0000000000000000", key);

            if (kcvReference != null)
            {
                if (kcv.Substring(0, 6).Equals(kcvReference.Substring(0, 6)) == false)
                    throw new SystemException("Computed KCV and Reference KCV not equal");
            }

            return kcv.Substring(0, 6);
        }


        ///USING MICROSOFT LIBRARY CRYPTO
        public static string doEncrypTDestStrCBC(string plain, string key, string iv = null)
        {
            bool needPad = false;

            if (plain.Length < 8)
                needPad = true;
            else if (plain.Length % 8 == 1)
                needPad = true;

            byte[] encrypted = EncryptTDesCBC(plain, key, iv, needPad);

            return BitConverter.ToString(encrypted).Replace("-", string.Empty);
        }

        public static string doEncrypTDestStrECB(string plain, string key)
        {
            bool needPad = false;

            if (plain.Length < 8)
                needPad = true;
            else if (plain.Length % 8 == 1)
                needPad = true;

            byte[] encrypted = EncryptTDesECB(plain, key, needPad);

            return BitConverter.ToString(encrypted).Replace("-", string.Empty);
        }

        public static string doDecrypTDestStrCBC(string encipher, string key, string iv = null, bool isPad = false)
        {
            byte[] decrypted = DecryptTDesCBC(encipher, key, iv, isPad);

            return BitConverter.ToString(decrypted).Replace("-", string.Empty);
        }

        public static string doDecrypTDestStrECB(string encipher, string key, bool isPad = false)
        {
            byte[] decrypted = DecryptTDesECB(encipher, key, isPad);

            return BitConverter.ToString(decrypted).Replace("-", string.Empty);
        }

        private static byte[] EncryptTDesCBC(string plain, string key, string iv, bool isPad)
        {
            string rawkey = key;
            if (key.Length <= 16)
            {
                rawkey = key + key; //make it 3 key length but single des
            }
            byte[] keyArray = Common.HelperFunctions.StringToByteArray(rawkey);
            byte[] plainByte = Common.HelperFunctions.StringToByteArray(plain);

            TripleDES tripleDESalg = TripleDES.Create();
            TripleDESCryptoServiceProvider sm = tripleDESalg as TripleDESCryptoServiceProvider;
            sm.Mode = CipherMode.CBC;
            sm.Padding = isPad ? PaddingMode.PKCS7 : PaddingMode.None;

            byte[] IV = null;
            if (iv == null || iv == string.Empty)
                IV = new byte[8];
            else
                IV = Common.HelperFunctions.StringToByteArray(iv);

            ICryptoTransform transEncrypt = DESCryptoExtensions2018.CreateWeakEncryptor(sm, keyArray, IV);

            byte[] data = Common.HelperFunctions.StringToByteArray(plain);
            byte[] result = transEncrypt.TransformFinalBlock(data, 0, data.Length);

            return result;
        }


        private static byte[] EncryptTDesECB(string plain, string key, bool isPad)
        {
            string rawkey = key;
            if (key.Length <= 16)
            {
                rawkey = key + key; //make it 3 key length but single des
            }
            byte[] keyArray = Common.HelperFunctions.StringToByteArray(rawkey);
            byte[] plainByte = Common.HelperFunctions.StringToByteArray(plain);

            TripleDES tripleDESalg = TripleDES.Create();
            TripleDESCryptoServiceProvider sm = tripleDESalg as TripleDESCryptoServiceProvider;
            sm.Mode = CipherMode.ECB;
            sm.Padding = isPad ? PaddingMode.PKCS7 : PaddingMode.None;

            byte[] IV = new byte[8];

            ICryptoTransform transEncrypt = DESCryptoExtensions2018.CreateWeakEncryptor(sm, keyArray, IV);

            byte[] data = Common.HelperFunctions.StringToByteArray(plain);
            byte[] result = transEncrypt.TransformFinalBlock(data, 0, data.Length);

            return result;
        }


        private static byte[] DecryptTDesCBC(string enchipered, String key, string iv, bool isPad)
        {
            string rawkey = key;
            if (key.Length <= 16)
            {
                rawkey = key + key; //make it 3 key length but single des
            }
            byte[] keyArray = Common.HelperFunctions.StringToByteArray(rawkey);
            byte[] enchiperedBytes = Common.HelperFunctions.StringToByteArray(enchipered);

            TripleDES tripleDESalg = TripleDES.Create();
            TripleDESCryptoServiceProvider sm = tripleDESalg as TripleDESCryptoServiceProvider;
            sm.Mode = CipherMode.CBC;
            sm.Padding = isPad ? PaddingMode.PKCS7 : PaddingMode.None;

            byte[] IV = null;
            if (iv == null || iv == string.Empty)
                IV = new byte[8];
            else
                IV = Common.HelperFunctions.StringToByteArray(iv);

            ICryptoTransform transEncrypt = DESCryptoExtensions2018.CreateWeakDecryptor(sm, keyArray, IV);

            byte[] result = transEncrypt.TransformFinalBlock(enchiperedBytes, 0, enchiperedBytes.Length);

            return result;

        }

        private static byte[] DecryptTDesECB(string enchipered, String key, bool isPad)
        {
            string rawkey = key;
            if (key.Length <= 16)
            {
                rawkey = key + key; //make it 3 key length but single des
            }
            byte[] keyArray = Common.HelperFunctions.StringToByteArray(rawkey);
            byte[] enchiperedBytes = Common.HelperFunctions.StringToByteArray(enchipered);

            TripleDES tripleDESalg = TripleDES.Create();
            TripleDESCryptoServiceProvider sm = tripleDESalg as TripleDESCryptoServiceProvider;
            sm.Mode = CipherMode.ECB;
            sm.Padding = isPad ? PaddingMode.PKCS7 : PaddingMode.None;

            byte[] IV = new byte[8];

            ICryptoTransform transEncrypt = DESCryptoExtensions2018.CreateWeakDecryptor(sm, keyArray, IV);

            byte[] result = transEncrypt.TransformFinalBlock(enchiperedBytes, 0, enchiperedBytes.Length);

            return result;
        }
    }
}
