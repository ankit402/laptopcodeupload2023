﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Text;
using System.Security.Cryptography;
using System.IO;


namespace WpfApp1.Data
{
    public class Utility
    {
        System.Text.ASCIIEncoding encoding = new System.Text.ASCIIEncoding();

        public string getString(byte[] input)
        {
            string test1 = encoding.GetString(input);
            byte[] ByteLicKey = StringToByte(test1);
            string hexString1 = BitConverter.ToString(ByteLicKey);
            hexString1 = hexString1.Replace("-", "");
            hexString1 = hexString1.Replace("0", "");
            //MessageBox.Show(hexString1);
            return hexString1;
        }
        public byte[] StringToByte(string str)
        {
            byte[] ba = Encoding.Default.GetBytes(str);
            return ba;
        }
        public string Convert_ASCIIToHex(string str)
        {
            byte[] ba = Encoding.Default.GetBytes(str);
            string hexString = BitConverter.ToString(ba);
            hexString = hexString.Replace("-", "");
            return hexString;
        }

        public string FromHexString(string hexString)
        {
            var bytes = new byte[hexString.Length / 2];
            for (var i = 0; i < bytes.Length; i++)
            {
                bytes[i] = Convert.ToByte(hexString.Substring(i * 2, 2), 16);
            }
            string retval = Encoding.ASCII.GetString(bytes);
            return retval;
        }
        public string GetHexString(byte[] byteArray)
        {
            StringBuilder hexString = new StringBuilder(byteArray.Length * 2);
            for (int i = 0; i < byteArray.Length; i++)
                hexString.Append(string.Format("{0:X}", byteArray[i]));
            int x = hexString.Capacity;
            return hexString.ToString();
        }

        public byte[] String_To_Bytes(string strInput)
        {
            int i = 0;
            int x = 0;
            byte[] bytes = new byte[(strInput.Length) / 2];
            while (strInput.Length > i + 1)
            {
                long lngDecimal = Convert.ToInt32(strInput.Substring(i, 2), 16);
                bytes[x] = Convert.ToByte(lngDecimal);
                i = i + 2;
                ++x;
            }
            return bytes;
        }

        public byte[] StringToByteArray(String hex)
        {
            int NumberChars = hex.Length / 2;
            byte[] bytes = new byte[NumberChars];
            using (var sr = new StringReader(hex))
            {
                for (int i = 0; i < NumberChars; i++)
                    bytes[i] = Convert.ToByte(new string(new char[2] { (char)sr.Read(), (char)sr.Read() }), 16);
            }
            return bytes;
        }

        public byte[] buildKey(byte[] cc1, byte[] cc2)
        {
            byte[] result = new byte[cc1.Length];
            int i = 0;
            foreach (byte b1 in cc1)
            {
                byte b2 = cc2[i];

                result[i] = ((byte)((b1 ^ b2)));
                i++;
            }

            return result;
        }

        public string ByteArrayToString(byte[] ba)
        {
            string hex = BitConverter.ToString(ba);
            return hex.Replace("-", "");
        }



        public string tDesEncrypt(string Key, String Data, String CMode)//101010-32time cmode-cbc
        {
            try
            {
                TripleDESCryptoServiceProvider tDES = new TripleDESCryptoServiceProvider();

                tDES.Key = StringToByteArray(Key);
                if (CMode == "ECB") { tDES.Mode = CipherMode.ECB; }
                else if (CMode == "CBC") { tDES.Mode = CipherMode.CBC; }
                else if (CMode == "CFB") { tDES.Mode = CipherMode.CFB; }
                else if (CMode == "CTS") { tDES.Mode = CipherMode.CTS; }
                else if (CMode == "OFB") { tDES.Mode = CipherMode.OFB; }


                tDES.Padding = PaddingMode.None;
                ICryptoTransform TRANS = tDES.CreateEncryptor();
                byte[] Bdata = StringToByteArray(Data);
                MemoryStream ms = new MemoryStream(StringToByteArray(Data));

                CryptoStream cs = new CryptoStream(ms, TRANS, CryptoStreamMode.Write);
                cs.Write(Bdata, 0, Bdata.Length);
                //cs.FlushFinalBlock();
                //string sms = BitConverter.ToString(ms.ToArray());
                //sms = sms.Replace("-", "");
                return ByteArrayToString(ms.ToArray());
            }
            catch (Exception ex)
            { return ex.ToString(); }
        }
        public string getFirst16DecofString(string s)
        {
            String dec = ""; int tmp = 1; int dec1 = 0;
            foreach (char c in s)
            {

                if (tmp <= 16 && (int)c <= 57 && (int)c >= 48)
                {
                    dec += c;
                    tmp++;
                }

            }
            if (tmp < 16)
            {
                foreach (char c in s)
                {
                    if (tmp > 16)
                        break;
                    if (tmp <= 16 && (int)c >= 65 && (int)c <= 70)
                    {
                        switch ((int)c)
                        {
                            case 65:
                                dec1 = 0;
                                break;
                            case 66:
                                dec1 = 1;
                                break;
                            case 67:
                                dec1 = 2;
                                break;
                            case 68:
                                dec1 = 3;
                                break;
                            case 69:
                                dec1 = 4;
                                break;
                            case 70:
                                dec1 = 5;
                                break;

                        }
                        dec += dec1;
                        tmp++;
                    }
                }

            }

            return dec;
        }
        public string GetOddParityDESKEY(string key)
        {
            //string s = "777D587A614DC728962D93E393ECA45A";
            int i = 0; int j = 0;

            string[] b = new string[key.Length / 2];//Divide the key to pairs of hex digits
            for (i = 0; i < key.Length; i++)
            {
                b[j] = key[i].ToString() + key[i + 1].ToString();
                i = i + 1;
                j++;

            }
            string bin = "";
            for (int k = 0; k < b.Length; k++)//iterates over individual hex strings
            {
                int count = 0;
                bin = hex2binary(b[k]);
                for (i = 0; i < bin.Length; i++)
                {
                    if (bin[i].ToString().Equals("1"))//counts no of ones in binary string
                        count++;
                }
                if (count % 2 == 0)//if it's even make it odd by reversing last digit
                {
                    StringBuilder binNew = new StringBuilder(bin);

                    if (bin[bin.Length - 1].ToString().Equals("1"))
                        binNew[bin.Length - 1] = '0';
                    else
                        binNew[bin.Length - 1] = '1';
                    b[k] = bin2hex(binNew.ToString());
                }

            }
            return string.Concat(b);

        }
        public string hex2binary(string hexString)
        {
            string binaryval = "";
            binaryval = Convert.ToString(Convert.ToInt32(hexString, 16), 2);
            if (binaryval.Length != hexString.Length * 4)
            {
                //int bitsdifference = hexString.Length * 4 - binaryval.Length;

                binaryval = binaryval.PadLeft(hexString.Length * 4, '0');
            }
            return binaryval;
        }
        public string bin2hex(string binString)
        {
            string strHex = Convert.ToInt32(binString, 2).ToString("X");

            if (strHex.Length != binString.Length / 4)
            {
                //int bitsdifference = hexString.Length * 4 - binaryval.Length;

                strHex = strHex.PadLeft(binString.Length / 4, '0');
            }
            return strHex;
        }
    }
}