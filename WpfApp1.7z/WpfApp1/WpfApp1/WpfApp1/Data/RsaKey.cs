﻿using WpfApp1.Common;
using Net.Pkcs11Interop.Common;
using Net.Pkcs11Interop.HighLevelAPI;
using Net.Pkcs11Interop.Tests.HighLevelAPI;
using System;
using System.Collections.Generic;

namespace WpfApp1.Data
{
    public class RsaKey
    {
        public byte[] publicModulus { get; set; }
        public byte[] publicExponent { get; set; }
        public byte[] privateExponent { get; set; }
        public byte[] prime1 { get; set; }
        public byte[] prime2 { get; set; }
        public byte[] exponent1 { get; set; }
        public byte[] exponent2 { get; set; }
        public byte[] coefficient { get; set; }
        public byte[] asn1PubKey { get; set; }
        public byte[] asn1PrivKey { get; set; }

        public String getStringAndEncryptUnderLmk(byte[] val)
        {
            return Common.SafenetWrappers.encryptKeyUnderLmk(Common.HelperFunctions.ByteArrayToString(val));
        }

        public string getLengthInBits()
        {
            return (privateExponent.Length * 8).ToString();
        }

        public IObjectHandle getRsaKeyHndl()
        {
            IObjectHandle objectHandle = null;

            using (IPkcs11 pkcs11 = Net.Pkcs11Interop.Tests.Settings.Factories.Pkcs11Factory.CreatePkcs11(Net.Pkcs11Interop.Tests.Settings.Factories, Configurations.Pkcs11LibraryPath, Net.Pkcs11Interop.Tests.Settings.AppType))
            {
                // Find first slot with token present
                ISlot slot =  Helpers.GetUsableSlot(pkcs11, Configurations.default_slot);

                // Open RW session
                using (Net.Pkcs11Interop.HighLevelAPI.ISession session = slot.OpenSession(SessionType.ReadWrite))
                {
                    // Prepare attribute template of new private key
                    List<IObjectAttribute> privateKeyAttributes = new List<IObjectAttribute>();
                    privateKeyAttributes.Add(Net.Pkcs11Interop.Tests.Settings.Factories.ObjectAttributeFactory.CreateObjectAttribute(CKA.CKA_CLASS, CKO.CKO_PRIVATE_KEY));
                    privateKeyAttributes.Add(Net.Pkcs11Interop.Tests.Settings.Factories.ObjectAttributeFactory.CreateObjectAttribute(CKA.CKA_TOKEN, false));
                    privateKeyAttributes.Add(Net.Pkcs11Interop.Tests.Settings.Factories.ObjectAttributeFactory.CreateObjectAttribute(CKA.CKA_APPLICATION, Net.Pkcs11Interop.Tests.Settings.ApplicationName));
                    privateKeyAttributes.Add(Net.Pkcs11Interop.Tests.Settings.Factories.ObjectAttributeFactory.CreateObjectAttribute(CKA.CKA_LABEL, "TmpRsaKey"));
                    privateKeyAttributes.Add(Net.Pkcs11Interop.Tests.Settings.Factories.ObjectAttributeFactory.CreateObjectAttribute(CKA.CKA_KEY_TYPE, CKK.CKK_RSA));

                    privateKeyAttributes.Add(Net.Pkcs11Interop.Tests.Settings.Factories.ObjectAttributeFactory.CreateObjectAttribute(CKA.CKA_MODULUS, this.publicModulus));
                    privateKeyAttributes.Add(Net.Pkcs11Interop.Tests.Settings.Factories.ObjectAttributeFactory.CreateObjectAttribute(CKA.CKA_PRIVATE_EXPONENT, this.privateExponent));
                    privateKeyAttributes.Add(Net.Pkcs11Interop.Tests.Settings.Factories.ObjectAttributeFactory.CreateObjectAttribute(CKA.CKA_PUBLIC_EXPONENT, this.publicExponent));
                    privateKeyAttributes.Add(Net.Pkcs11Interop.Tests.Settings.Factories.ObjectAttributeFactory.CreateObjectAttribute(CKA.CKA_PRIME_1, this.prime1));
                    privateKeyAttributes.Add(Net.Pkcs11Interop.Tests.Settings.Factories.ObjectAttributeFactory.CreateObjectAttribute(CKA.CKA_PRIME_2, this.prime2));
                    privateKeyAttributes.Add(Net.Pkcs11Interop.Tests.Settings.Factories.ObjectAttributeFactory.CreateObjectAttribute(CKA.CKA_EXPONENT_1, this.exponent1));
                    privateKeyAttributes.Add(Net.Pkcs11Interop.Tests.Settings.Factories.ObjectAttributeFactory.CreateObjectAttribute(CKA.CKA_EXPONENT_2, this.exponent2));
                    privateKeyAttributes.Add(Net.Pkcs11Interop.Tests.Settings.Factories.ObjectAttributeFactory.CreateObjectAttribute(CKA.CKA_COEFFICIENT, this.coefficient));

                    objectHandle = session.CreateObject(privateKeyAttributes);
                }
            }

            return objectHandle;
        }
    }
}
