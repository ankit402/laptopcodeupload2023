﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WpfApp1.Data
{
    public class IPK_Details
    {
        public string header { get; set; }
        public string ipk_mod_len { get; set; }
        public string ipk_mod { get; set; }
        public string ipk_expo_len { get; set; }
        public string ipk_expo { get; set; }
        public string tracking_number { get; set; }


    }
}
