﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WpfApp1.Data
{
    public class KekKey
    {
        public string keyName { get; set; }
        public string KeyValueClear { get; set; }
        public string KeyValueEncryptedUnderLMK { get; set; }
        public string KeyKCV { get; set; }
        public const string KeyType = "KEK";


        public string getKeyLength()
        {
            return (KeyValueClear.Length / 2).ToString();
        }

    }
}
