﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using System.Xml;

namespace WpfApp1
{
    /// <summary>
    /// Interaction logic for ipk.xaml
    /// </summary>
    public partial class ipk : Window
    {
        string ipkxmlpath = ConfigurationSettings.AppSettings["ipkxml"];
        public ipk()
        {
            InitializeComponent();
            getipk();
        }

        public void getipk()
        {
            string xmlFile = ipkxmlpath;
            XmlTextReader xmdatareader = new XmlTextReader(xmlFile);
            DataSet _objdataset = new DataSet();
            _objdataset.ReadXml(xmdatareader);

            list_issuer.ItemsSource = _objdataset.Tables["Issuer_RSA"].DefaultView;
            list_issuer.DisplayMemberPath= "PrivateExp";
            //list_issuer.DisplayMemberPath += "length";

        }
    }
}
