﻿using System;
using System.Collections.Generic;
using System.Data;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using System.Xml;
using System.Xml.Linq;

namespace WpfApp1
{
    /// <summary>
    /// Interaction logic for test.xaml
    /// </summary>
    public partial class test : Window
    {
        public test()
        {
            InitializeComponent();
            bindgrid();
            bindgridkey();
        }

        public void bindgrid()
        {

            DataSet dataSet = new DataSet();
            dataSet.ReadXml(@"E:\CA_Configuration.xml");
            DataView dr = new DataView(dataSet.Tables[0]);
            string e = "MasterCard";
           // dr.RowFilter= "Issuer LIKE '" + e + "' ";
            dataGrid1.ItemsSource = dr;
        }

        public void bindgridkey()
        {

           // DataSet dataSet = new DataSet();
           // dataSet.ReadXml(@"D:\WpfApp1\XML\XML\KeyBank.xml");
           // DataView dr = new DataView(dataSet.Tables[0]);
           //// string e = "MasterCard";
           // // dr.RowFilter= "Issuer LIKE '" + e + "' ";
           // dataGrid1.ItemsSource = dr;
        }
        private void Button_Click(object sender, RoutedEventArgs e)
        {
            testws();
            StringBuilder result = new StringBuilder();
            foreach (XElement level1Element in XElement.Load(@"D:\WpfApp1\XML\XML\KeyBank.xml").Elements("KeySet"))
            {
               // result.AppendLine(level1Element.Attribute("Set").Value);
                foreach (XElement level2Element in level1Element.Elements("Set"))
                {
                    result.AppendLine("  " + level2Element.Attribute("Name").Value);
                }
            }
            MessageBox.Show(result.ToString());
        }

        public void testws()
        {
            //XmlDocument xmlDoc = new XmlDocument();
            //xmlDoc.Load(@"D:\WpfApp1\XML\XML\KeyBank.xml");
            //XmlNodeList nodeList = xmlDoc.DocumentElement.SelectNodes("KeySet");
            //string proID = "", proName = "", price = "";
            //foreach (XmlAttribute node in nodeList)
            //{
            //    //proID = node.SelectSingleNode("Name").InnerText;
            //    proName = node.SelectSingleNode("ID").InnerText;
            //    price = node.SelectSingleNode("Description").InnerText;
            //    MessageBox.Show(proID + " " + proName + " " + price);
            //}

            //var doc = XDocument.Load(@"D:\WpfApp1\XML\XML\KeyBank.xml");
            //foreach (var element in doc.Descendants("/KeySet/Set"))
            //{
            //    element.Attribute("Name").Value = "Ankit";
            //}

            //doc.Save(@"D:\WpfApp1\XML\XML\KeyBank.xml");

            XmlDocument xmldoc = new XmlDocument();
            XmlNodeList xmlnode;
            int i = 0;
            List<string> listx = new List<string>();

            FileStream fs = new FileStream(@"D:\WpfApp1\XML\XML\KeyBank.xml", FileMode.Open, FileAccess.Read);
            xmldoc.Load(fs);
            xmlnode = xmldoc.GetElementsByTagName("Set");
            for (i = 0; i <= xmlnode.Count - 1; i++)
            {
                listx.Add(xmlnode[i].Attributes["Name"].Value);
            }

            for (int k = 0; k < listx.Count; k++)
            {
                MessageBox.Show(listx[k]);
            }
        }
    }
}
