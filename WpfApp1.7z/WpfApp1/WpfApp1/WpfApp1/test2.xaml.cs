﻿using Net.Pkcs11Interop.Common;
using Net.Pkcs11Interop.HighLevelAPI;
using Net.Pkcs11Interop.Tests;
using Net.Pkcs11Interop.Tests.HighLevelAPI;
using Org.BouncyCastle.Asn1;
using Org.BouncyCastle.Asn1.Pkcs;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using WpfApp1.Common;
using WpfApp1.Data;
using System.Numerics;
using System.IO;

namespace WpfApp1
{
    /// <summary>
    /// Interaction logic for test2.xaml
    /// </summary>
    public partial class test2 : Window
    {
        public test2()
        {
            InitializeComponent();
        }
        private static string doGenerateSecretKey3DesAndReturnClearKey(CKM keyType)
        {
            using (IPkcs11 pkcs11 = Settings.Factories.Pkcs11Factory.CreatePkcs11(Settings.Factories, Configurations.Pkcs11LibraryPath, Settings.AppType))
            {
                // Find first slot with token present
                ISlot slot = Helpers.GetUsableSlot(pkcs11, Configurations.default_slot);

                // Open RW session
                using (Net.Pkcs11Interop.HighLevelAPI.ISession session = slot.OpenSession(SessionType.ReadWrite))
                {
                    // Login as normal user
                    session.Login(Configurations.user_type, Configurations.hsm_password);

                    // Prepare attribute template of new key
                    List<IObjectAttribute> objectAttributes = new List<IObjectAttribute>();
                    objectAttributes.Add(Settings.Factories.ObjectAttributeFactory.CreateObjectAttribute(CKA.CKA_TOKEN, false)); //not stored in token
                    objectAttributes.Add(Settings.Factories.ObjectAttributeFactory.CreateObjectAttribute(CKA.CKA_CLASS, CKO.CKO_SECRET_KEY));
                    objectAttributes.Add(Settings.Factories.ObjectAttributeFactory.CreateObjectAttribute(CKA.CKA_KEY_TYPE, keyType == CKM.CKM_DES_KEY_GEN ? CKK.CKK_DES : CKK.CKK_DES3));
                    objectAttributes.Add(Settings.Factories.ObjectAttributeFactory.CreateObjectAttribute(CKA.CKA_ENCRYPT, true));
                    objectAttributes.Add(Settings.Factories.ObjectAttributeFactory.CreateObjectAttribute(CKA.CKA_DECRYPT, true));
                    objectAttributes.Add(Settings.Factories.ObjectAttributeFactory.CreateObjectAttribute(CKA.CKA_WRAP, true));
                    objectAttributes.Add(Settings.Factories.ObjectAttributeFactory.CreateObjectAttribute(CKA.CKA_UNWRAP, true));
                    objectAttributes.Add(Settings.Factories.ObjectAttributeFactory.CreateObjectAttribute(CKA.CKA_EXTRACTABLE, true));

                    // Specify key generation mechanism
                    IMechanism mechanism = Settings.Factories.MechanismFactory.CreateMechanism(keyType);

                    // Generate key
                    IObjectHandle secret_key = session.GenerateKey(mechanism, objectAttributes);

                    // Do something interesting with generated key

                    /****************** WRAP and Decrypt Key ***********************************/

                    // Prepare attribute template of new key
                    List<IObjectAttribute> objectAttributes_wrapper_key = new List<IObjectAttribute>();
                    objectAttributes_wrapper_key.Add(Settings.Factories.ObjectAttributeFactory.CreateObjectAttribute(CKA.CKA_TOKEN, false)); //not stored in token
                    objectAttributes_wrapper_key.Add(Settings.Factories.ObjectAttributeFactory.CreateObjectAttribute(CKA.CKA_CLASS, CKO.CKO_SECRET_KEY));
                    objectAttributes_wrapper_key.Add(Settings.Factories.ObjectAttributeFactory.CreateObjectAttribute(CKA.CKA_KEY_TYPE, keyType == CKM.CKM_DES_KEY_GEN ? CKK.CKK_DES : CKK.CKK_DES3));
                    //objectAttributes_wrapper_key.Add(Settings.Factories.ObjectAttributeFactory.CreateObjectAttribute(CKA.CKA_ENCRYPT, true));
                    objectAttributes_wrapper_key.Add(Settings.Factories.ObjectAttributeFactory.CreateObjectAttribute(CKA.CKA_DECRYPT, true));
                    //objectAttributes_wrapper_key.Add(Settings.Factories.ObjectAttributeFactory.CreateObjectAttribute(CKA.CKA_DERIVE, true));
                    //objectAttributes_wrapper_key.Add(Settings.Factories.ObjectAttributeFactory.CreateObjectAttribute(CKA.CKA_EXTRACTABLE, true));
                    objectAttributes_wrapper_key.Add(Settings.Factories.ObjectAttributeFactory.CreateObjectAttribute(CKA.CKA_WRAP, true));
                    //objectAttributes_wrapper_key.Add(Settings.Factories.ObjectAttributeFactory.CreateObjectAttribute(CKA.CKA_UNWRAP, true));

                    // Generate symmetric wrapper key
                    IObjectHandle wrapper_key = session.GenerateKey(mechanism, objectAttributes_wrapper_key);

                    IMechanism mechanism_wrap_decrypt = Settings.Factories.MechanismFactory.CreateMechanism(keyType == CKM.CKM_DES_KEY_GEN ? CKM.CKM_DES_ECB : CKM.CKM_DES3_ECB);

                    // Wrap key
                    byte[] wrappedKeyBytes = session.WrapKey(mechanism_wrap_decrypt, wrapper_key, secret_key);

                    // Do something interesting with wrapped key
                    if (wrappedKeyBytes == null)
                        throw new Exception("Fail wrapping key");

                    // Decrypt data
                    byte[] decryptedData = session.Decrypt(mechanism_wrap_decrypt, wrapper_key, wrappedKeyBytes);

                    // Destroy object
                    session.DestroyObject(wrapper_key);
                    session.DestroyObject(secret_key);
                    session.Logout();

                    return HelperFunctions.ByteArrayToString(decryptedData);
                }
            }
        }


        private static string[] doGenerateSecretKey3DesAndReturnClearKeyAndKCV(CKM keyType)
        {
            using (IPkcs11 pkcs11 = Settings.Factories.Pkcs11Factory.CreatePkcs11(Settings.Factories, Configurations.Pkcs11LibraryPath, Settings.AppType))
            {
                // Find first slot with token present
                ISlot slot = Helpers.GetUsableSlot(pkcs11, Configurations.default_slot);

                // Open RW session
                using (Net.Pkcs11Interop.HighLevelAPI.ISession session = slot.OpenSession(SessionType.ReadWrite))
                {
                    // Login as normal user
                    session.Login(Configurations.user_type, Configurations.hsm_password);

                    // Prepare attribute template of new key
                    List<IObjectAttribute> objectAttributes = new List<IObjectAttribute>();
                    objectAttributes.Add(Settings.Factories.ObjectAttributeFactory.CreateObjectAttribute(CKA.CKA_TOKEN, false)); //not stored in token
                    objectAttributes.Add(Settings.Factories.ObjectAttributeFactory.CreateObjectAttribute(CKA.CKA_CLASS, CKO.CKO_SECRET_KEY));
                    objectAttributes.Add(Settings.Factories.ObjectAttributeFactory.CreateObjectAttribute(CKA.CKA_KEY_TYPE, keyType == CKM.CKM_DES_KEY_GEN ? CKK.CKK_DES : CKK.CKK_DES3));
                    objectAttributes.Add(Settings.Factories.ObjectAttributeFactory.CreateObjectAttribute(CKA.CKA_ENCRYPT, true));
                    objectAttributes.Add(Settings.Factories.ObjectAttributeFactory.CreateObjectAttribute(CKA.CKA_DECRYPT, true));
                    objectAttributes.Add(Settings.Factories.ObjectAttributeFactory.CreateObjectAttribute(CKA.CKA_WRAP, true));
                    objectAttributes.Add(Settings.Factories.ObjectAttributeFactory.CreateObjectAttribute(CKA.CKA_UNWRAP, true));
                    objectAttributes.Add(Settings.Factories.ObjectAttributeFactory.CreateObjectAttribute(CKA.CKA_EXTRACTABLE, true));

                    // Specify key generation mechanism
                    IMechanism mechanism = Settings.Factories.MechanismFactory.CreateMechanism(keyType);

                    // Generate key
                    IObjectHandle secret_key = session.GenerateKey(mechanism, objectAttributes);

                    /****************** Compute KCV ***********************************/
                    byte[] iv = new byte[8];

                    IMechanism mechanism_wrap_encrypt_decrypt = Settings.Factories.MechanismFactory.CreateMechanism(keyType == CKM.CKM_DES_KEY_GEN ? CKM.CKM_DES_ECB : CKM.CKM_DES3_ECB);

                    // Encrypt data
                    byte[] kcvBytes = session.Encrypt(mechanism_wrap_encrypt_decrypt, secret_key, iv);


                    // Do something interesting with generated key

                    /****************** WRAP Key ***********************************/

                    // Prepare attribute template of new key
                    List<IObjectAttribute> objectAttributes_wrapper_key = new List<IObjectAttribute>();
                    objectAttributes_wrapper_key.Add(Settings.Factories.ObjectAttributeFactory.CreateObjectAttribute(CKA.CKA_TOKEN, false)); //not stored in token
                    objectAttributes_wrapper_key.Add(Settings.Factories.ObjectAttributeFactory.CreateObjectAttribute(CKA.CKA_CLASS, CKO.CKO_SECRET_KEY));
                    objectAttributes_wrapper_key.Add(Settings.Factories.ObjectAttributeFactory.CreateObjectAttribute(CKA.CKA_KEY_TYPE, keyType == CKM.CKM_DES_KEY_GEN ? CKK.CKK_DES : CKK.CKK_DES3));
                    //objectAttributes_wrapper_key.Add(Settings.Factories.ObjectAttributeFactory.CreateObjectAttribute(CKA.CKA_ENCRYPT, true));
                    objectAttributes_wrapper_key.Add(Settings.Factories.ObjectAttributeFactory.CreateObjectAttribute(CKA.CKA_DECRYPT, true));
                    //objectAttributes_wrapper_key.Add(Settings.Factories.ObjectAttributeFactory.CreateObjectAttribute(CKA.CKA_DERIVE, true));
                    //objectAttributes_wrapper_key.Add(Settings.Factories.ObjectAttributeFactory.CreateObjectAttribute(CKA.CKA_EXTRACTABLE, true));
                    objectAttributes_wrapper_key.Add(Settings.Factories.ObjectAttributeFactory.CreateObjectAttribute(CKA.CKA_WRAP, true));
                    //objectAttributes_wrapper_key.Add(Settings.Factories.ObjectAttributeFactory.CreateObjectAttribute(CKA.CKA_UNWRAP, true));

                    // Generate symmetric wrapper key
                    IObjectHandle wrapper_key = session.GenerateKey(mechanism, objectAttributes_wrapper_key);

                    // Wrap key
                    byte[] wrappedKeyBytes = session.WrapKey(mechanism_wrap_encrypt_decrypt, wrapper_key, secret_key);

                    // Do something interesting with wrapped key
                    if (wrappedKeyBytes == null)
                        throw new Exception("Fail wrapping key");

                    /****************** DECRYPT WRAPPED Key ***********************************/

                    // Decrypt data
                    byte[] decryptedData = session.Decrypt(mechanism_wrap_encrypt_decrypt, wrapper_key, wrappedKeyBytes);

                    string[] result = new string[2];
                    result[0] = HelperFunctions.ByteArrayToString(decryptedData);
                    result[1] = HelperFunctions.ByteArrayToString(kcvBytes).Substring(0, 6);

                    // Destroy object
                    session.DestroyObject(wrapper_key);
                    session.DestroyObject(secret_key);
                    session.Logout();

                    return result;
                }
            }
        }
        public static string doGenerateSecretKey3Des3KeyAndReturnClearKey()
        {
            return doGenerateSecretKey3DesAndReturnClearKey(CKM.CKM_DES3_KEY_GEN);
        }
        public static RsaKey doGenerateKeyPairReturnClearRSAKey(string lengthInBitsStr, string publicModulus)
        {
            byte[] pubMod = HelperFunctions.StringToByteArray(publicModulus);
            ulong lengthInBits = Convert.ToUInt32(lengthInBitsStr);

            RsaKey result = null;

            try
            {
                using (IPkcs11 pkcs11 = Settings.Factories.Pkcs11Factory.CreatePkcs11(Settings.Factories, Configurations.Pkcs11LibraryPath, Settings.AppType))
                {
                    // Find first slot with token present
                    ISlot slot = Helpers.GetUsableSlot(pkcs11, Configurations.default_slot);

                    // Open RW session
                    using (ISession session = slot.OpenSession(SessionType.ReadWrite))
                    {
                        // Login as normal user
                        session.Login(Configurations.user_type, Configurations.hsm_password);

                        // The CKA_ID attribute is intended as a means of distinguishing multiple key pairs held by the same subject
                        byte[] ckaId = session.GenerateRandom(20);

                        // Prepare attribute template of new public key
                        List<IObjectAttribute> publicKeyAttributes = new List<IObjectAttribute>();
                        publicKeyAttributes.Add(Settings.Factories.ObjectAttributeFactory.CreateObjectAttribute(CKA.CKA_TOKEN, false));
                        publicKeyAttributes.Add(Settings.Factories.ObjectAttributeFactory.CreateObjectAttribute(CKA.CKA_PRIVATE, false));
                        publicKeyAttributes.Add(Settings.Factories.ObjectAttributeFactory.CreateObjectAttribute(CKA.CKA_LABEL, Settings.ApplicationName));
                        publicKeyAttributes.Add(Settings.Factories.ObjectAttributeFactory.CreateObjectAttribute(CKA.CKA_ID, ckaId));
                        publicKeyAttributes.Add(Settings.Factories.ObjectAttributeFactory.CreateObjectAttribute(CKA.CKA_ENCRYPT, true));
                        publicKeyAttributes.Add(Settings.Factories.ObjectAttributeFactory.CreateObjectAttribute(CKA.CKA_VERIFY, true));
                        publicKeyAttributes.Add(Settings.Factories.ObjectAttributeFactory.CreateObjectAttribute(CKA.CKA_VERIFY_RECOVER, true));
                        publicKeyAttributes.Add(Settings.Factories.ObjectAttributeFactory.CreateObjectAttribute(CKA.CKA_WRAP, true));
                        publicKeyAttributes.Add(Settings.Factories.ObjectAttributeFactory.CreateObjectAttribute(CKA.CKA_MODULUS_BITS, lengthInBits));
                        publicKeyAttributes.Add(Settings.Factories.ObjectAttributeFactory.CreateObjectAttribute(CKA.CKA_PUBLIC_EXPONENT, pubMod));

                        // Prepare attribute template of new private key
                        List<IObjectAttribute> privateKeyAttributes = new List<IObjectAttribute>();
                        privateKeyAttributes.Add(Settings.Factories.ObjectAttributeFactory.CreateObjectAttribute(CKA.CKA_TOKEN, false));
                        privateKeyAttributes.Add(Settings.Factories.ObjectAttributeFactory.CreateObjectAttribute(CKA.CKA_PRIVATE, true));
                        privateKeyAttributes.Add(Settings.Factories.ObjectAttributeFactory.CreateObjectAttribute(CKA.CKA_LABEL, Settings.ApplicationName));
                        privateKeyAttributes.Add(Settings.Factories.ObjectAttributeFactory.CreateObjectAttribute(CKA.CKA_ID, ckaId));
                        privateKeyAttributes.Add(Settings.Factories.ObjectAttributeFactory.CreateObjectAttribute(CKA.CKA_SENSITIVE, true));
                        privateKeyAttributes.Add(Settings.Factories.ObjectAttributeFactory.CreateObjectAttribute(CKA.CKA_DECRYPT, true));
                        privateKeyAttributes.Add(Settings.Factories.ObjectAttributeFactory.CreateObjectAttribute(CKA.CKA_SIGN, true));
                        privateKeyAttributes.Add(Settings.Factories.ObjectAttributeFactory.CreateObjectAttribute(CKA.CKA_SIGN_RECOVER, true));
                        privateKeyAttributes.Add(Settings.Factories.ObjectAttributeFactory.CreateObjectAttribute(CKA.CKA_UNWRAP, true));

                        // Specify key generation mechanism
                        IMechanism mechanism = Settings.Factories.MechanismFactory.CreateMechanism(CKM.CKM_RSA_PKCS_KEY_PAIR_GEN);

                        // Generate key pair
                        IObjectHandle publicKeyHandle = null;
                        IObjectHandle privateKeyHandle = null;
                        session.GenerateKeyPair(mechanism, publicKeyAttributes, privateKeyAttributes, out publicKeyHandle, out privateKeyHandle);

                        /****************** WRAP Key ***********************************/
                        // Specify wrapping mechanism
                        IMechanism mechanism_wrap = Settings.Factories.MechanismFactory.CreateMechanism(CKM.CKM_DES3_ECB);

                        // Prepare attribute template of new key
                        List<IObjectAttribute> objectAttributes_wrapper_key = new List<IObjectAttribute>();
                        objectAttributes_wrapper_key.Add(Settings.Factories.ObjectAttributeFactory.CreateObjectAttribute(CKA.CKA_TOKEN, false)); //not stored in token
                        objectAttributes_wrapper_key.Add(Settings.Factories.ObjectAttributeFactory.CreateObjectAttribute(CKA.CKA_CLASS, CKO.CKO_SECRET_KEY));
                        objectAttributes_wrapper_key.Add(Settings.Factories.ObjectAttributeFactory.CreateObjectAttribute(CKA.CKA_KEY_TYPE, CKK.CKK_DES3));
                        //objectAttributes_wrapper_key.Add(Settings.Factories.ObjectAttributeFactory.CreateObjectAttribute(CKA.CKA_ENCRYPT, true));
                        objectAttributes_wrapper_key.Add(Settings.Factories.ObjectAttributeFactory.CreateObjectAttribute(CKA.CKA_DECRYPT, true));
                        //objectAttributes_wrapper_key.Add(Settings.Factories.ObjectAttributeFactory.CreateObjectAttribute(CKA.CKA_DERIVE, true));
                        //objectAttributes_wrapper_key.Add(Settings.Factories.ObjectAttributeFactory.CreateObjectAttribute(CKA.CKA_EXTRACTABLE, true));
                        objectAttributes_wrapper_key.Add(Settings.Factories.ObjectAttributeFactory.CreateObjectAttribute(CKA.CKA_WRAP, true));
                        //objectAttributes_wrapper_key.Add(Settings.Factories.ObjectAttributeFactory.CreateObjectAttribute(CKA.CKA_UNWRAP, true));

                      //  IObjectHandle hLMKKey = findAKeyObject(Configurations.LMK_KEYNAME, session);

                        // Wrap key
                        byte[] wrappedPublicKeyBytes = session.WrapKey(mechanism_wrap, hLMKKey, publicKeyHandle);
                        byte[] wrappedPrivateKeyBytes = session.WrapKey(mechanism_wrap, hLMKKey, privateKeyHandle);

                        // Do something interesting with wrapped key
                        if (wrappedPublicKeyBytes == null || wrappedPrivateKeyBytes == null)
                            throw new Exception("Fail wrapping key");

                        // Decrypt data
                        byte[] decryptedPrivateKeyBytes = session.Decrypt(mechanism_wrap, hLMKKey, wrappedPrivateKeyBytes);
                        byte[] decryptedPublicKeyBytes = session.Decrypt(mechanism_wrap, hLMKKey, wrappedPublicKeyBytes);

                        byte[] decryptedPrivateKeyBytesClean = WpfApp1.Crypto.DESCryptoLib2018.RemoveZeroTrailer(decryptedPrivateKeyBytes);
                        byte[] decryptedPublicKeyBytesClean = WpfApp1.Crypto.DESCryptoLib2018.RemoveZeroTrailer(decryptedPublicKeyBytes);

                        var obj = Asn1Sequence.FromByteArray(decryptedPrivateKeyBytesClean);
                        Asn1Sequence seq = Asn1Sequence.GetInstance(obj);
                        Asn1OctetString obcSeq = (Asn1OctetString)seq[2];
                        byte[] octByte = obcSeq.GetOctets();

                        Asn1Object octObj = Asn1Sequence.FromByteArray(octByte);
                        Asn1Sequence seqPrivKey = Asn1Sequence.GetInstance(octObj);

                        RsaPrivateKeyStructure rsaPrivKey = RsaPrivateKeyStructure.GetInstance(seqPrivKey);
                        RsaKey rsa = new RsaKey();
                        rsa.publicModulus = WpfApp1.Crypto.DESCryptoLib2018.RemoveZeroHead(rsaPrivKey.Modulus.ToByteArray());
                        rsa.publicExponent = WpfApp1.Crypto.DESCryptoLib2018.RemoveZeroHead(rsaPrivKey.PublicExponent.ToByteArray());
                        rsa.privateExponent = rsaPrivKey.PrivateExponent.ToByteArray();
                        rsa.prime1 = WpfApp1.Crypto.DESCryptoLib2018.RemoveZeroHead(rsaPrivKey.Prime1.ToByteArray());
                        rsa.prime2 = WpfApp1.Crypto.DESCryptoLib2018.RemoveZeroHead(rsaPrivKey.Prime2.ToByteArray());
                        rsa.exponent1 = WpfApp1.Crypto.DESCryptoLib2018.RemoveZeroHead(rsaPrivKey.Exponent1.ToByteArray());
                        rsa.exponent2 = WpfApp1.Crypto.DESCryptoLib2018.RemoveZeroHead(rsaPrivKey.Exponent2.ToByteArray());
                        rsa.coefficient = WpfApp1.Crypto.DESCryptoLib2018.RemoveZeroHead(rsaPrivKey.Coefficient.ToByteArray());
                        rsa.asn1PubKey = WpfApp1.Crypto.DESCryptoLib2018.RemoveZeroHead(decryptedPublicKeyBytesClean);
                        rsa.asn1PrivKey = WpfApp1.Crypto.DESCryptoLib2018.RemoveZeroHead(decryptedPrivateKeyBytesClean);

                        // Destroy keys
                        session.DestroyObject(publicKeyHandle);
                        session.DestroyObject(privateKeyHandle);

                        session.Logout();

                        return rsa;
                    }
                }
            }
            catch (Exception ex)
            {
               // MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                throw ex;
            }

        }
        public DataTable Read_IPK_Details(string ipkId)
        {
            try
            {
                //con.Open();
                DataTable dt = new DataTable();
                //cmd = new SqlCommand();
                //cmd.Connection = con;
                //cmd.CommandType = CommandType.StoredProcedure;
                //cmd.CommandText = "SP_KMS_READ_IPK_DETAILS";
                //cmd.Parameters.AddWithValue("@IPKID", ipkId);
                //dr = cmd.ExecuteReader();
                //dt.Load(dr);
                //con.Close();
                //if (dt.Rows.Count > 0)
                //    //Log_write.LogWrite( "Data Read Success");
                //else
                //    //Log_write.LogWrite( "Data Read Failure");

                return dt;

            }
            catch (Exception ex)
            {

                //Log_write.LogWrite( "Exception Occured while Reading IPK Details [" + ex.Message + "]");
                //con.Close();
                throw;
            }

        }

        public byte[] doRSASign(byte[] RSAPubMod, byte[] RSAPubExp, byte[] RSAPriExp, byte[] ClearData)
        {

           // Method_Name = "doRSASign";
            byte[] SignedData = null;

            try
            {
                ISlot slot = Net.Pkcs11Interop.Tests.HighLevelAPI.Helpers.GetUsableSlot(pkcs11, Configurations.default_slot);
                ISession session = slot.OpenSession(SessionType.ReadWrite);
            //    Log_write.LogWrite(GetIP(), Class_Name, Method_Name, "Information", " Session id [ " + session.SessionId + " ] ");
              //  response = session.Login(CKU.CKU_USER, "utokenuser12345678", "");
                if (response == "CKR_USER_ALREADY_LOGGED_IN")
                {
                   // Log_write.LogWrite(GetIP(), Class_Name, Method_Name, "Information", "Status [ " + response + " ]");
                }
               // Log_write.LogWrite(GetIP(), Class_Name, Method_Name, "Information", "Status [ " + response + " ]");
                // Prepare attribute template of new private key
                List<IObjectAttribute> privateKeyAttributes = new List<IObjectAttribute>();
                privateKeyAttributes.Add(Settings.Factories.ObjectAttributeFactory.CreateObjectAttribute(CKA.CKA_CLASS, CKO.CKO_PRIVATE_KEY));
                privateKeyAttributes.Add(Settings.Factories.ObjectAttributeFactory.CreateObjectAttribute(CKA.CKA_KEY_TYPE, CKK.CKK_RSA));
                privateKeyAttributes.Add(Settings.Factories.ObjectAttributeFactory.CreateObjectAttribute(CKA.CKA_TOKEN, false));
                privateKeyAttributes.Add(Settings.Factories.ObjectAttributeFactory.CreateObjectAttribute(CKA.CKA_PRIVATE, true));
                privateKeyAttributes.Add(Settings.Factories.ObjectAttributeFactory.CreateObjectAttribute(CKA.CKA_LABEL, Settings.ApplicationName));
                //privateKeyAttributes.Add(Settings.Factories.ObjectAttributeFactory.CreateObjectAttribute(CKA.CKA_ID, ckaId));
                privateKeyAttributes.Add(Settings.Factories.ObjectAttributeFactory.CreateObjectAttribute(CKA.CKA_SENSITIVE, true));
                privateKeyAttributes.Add(Settings.Factories.ObjectAttributeFactory.CreateObjectAttribute(CKA.CKA_DECRYPT, true));
                privateKeyAttributes.Add(Settings.Factories.ObjectAttributeFactory.CreateObjectAttribute(CKA.CKA_SIGN, true));
                privateKeyAttributes.Add(Settings.Factories.ObjectAttributeFactory.CreateObjectAttribute(CKA.CKA_SIGN_RECOVER, true));
                privateKeyAttributes.Add(Settings.Factories.ObjectAttributeFactory.CreateObjectAttribute(CKA.CKA_UNWRAP, true));
                privateKeyAttributes.Add(Settings.Factories.ObjectAttributeFactory.CreateObjectAttribute(CKA.CKA_MODULUS_BITS, Convert.ToUInt64(ClearData.Length * 8)));
                privateKeyAttributes.Add(Settings.Factories.ObjectAttributeFactory.CreateObjectAttribute(CKA.CKA_MODULUS, RSAPubMod));
                privateKeyAttributes.Add(Settings.Factories.ObjectAttributeFactory.CreateObjectAttribute(CKA.CKA_PUBLIC_EXPONENT, RSAPubExp));
                privateKeyAttributes.Add(Settings.Factories.ObjectAttributeFactory.CreateObjectAttribute(CKA.CKA_PRIVATE_EXPONENT, RSAPriExp));

               // Log_write.LogWrite(GetIP(), Class_Name, Method_Name, "Information", "CKA_LABEL [ " + Settings.ApplicationName + " ]");
              //  Log_write.LogWrite(GetIP(), Class_Name, Method_Name, "Information", "RSAPubMod [ " + HelperFunctions.ByteArrayToString(RSAPubMod) + " ]");
              //  Log_write.LogWrite(GetIP(), Class_Name, Method_Name, "Information", "RSAPubExp [ " + HelperFunctions.ByteArrayToString(RSAPubExp) + " ]");
              //  Log_write.LogWrite(GetIP(), Class_Name, Method_Name, "Information", "RSAPriExp [ " + HelperFunctions.ByteArrayToString(RSAPriExp) + " ]");
              //  Log_write.LogWrite(GetIP(), Class_Name, Method_Name, "Information", "ModulusBits [ " + Convert.ToUInt64(ClearData.Length * 8).ToString() + " ]");
              //  Log_write.LogWrite(GetIP(), Class_Name, Method_Name, "Information", "ClearData [ " + HelperFunctions.ByteArrayToString(ClearData) + " ]");
              //  Log_write.LogWrite(GetIP(), Class_Name, Method_Name, "Information", "privateKeyAttributes set");
                // Create RSA Key Object Handle
                IObjectHandle privateKeyHandle = null;
                privateKeyHandle = session.CreateObject(privateKeyAttributes);
              //  Log_write.LogWrite(GetIP(), Class_Name, Method_Name, "Information", "CreateObject Done");
                /****************** RSA Sign ***********************************/

                // Specify key generation mechanism
                IMechanism mechanism = Settings.Factories.MechanismFactory.CreateMechanism(CKM.CKM_RSA_X_509);

                //Signing Clear Data with RSA Private Key Handle
                SignedData = session.SignRecover(mechanism, privateKeyHandle, ClearData);

                // Destroy keys
                session.DestroyObject(privateKeyHandle);

                return SignedData;

            }
            catch (Exception ex)
            {
              //  Log_write.LogWrite(GetIP(), Class_Name, Method_Name, "Exception", ex.ToString());
              //  Log_write.LogWrite(GetIP(), Class_Name, Method_Name, "Exception", "HResult [" + ex.HResult.ToString("X") + "]");
                // return ex.ToString();
                throw;
            }
        }

        public int CreateIPKRequestMCHIPhIP(string IpkId, string len)
        {
            //Method_Name = "CreateIPKRequestMCHIPhIP";
            string Len = "1408";
            string publiExp = "03";
            Utility util = new Utility();
            try
            {
                bool SaveInDB = true;
                int ret_val = -1;
               // Log_write.LogWrite(GetIP(), Class_Name, Method_Name, "Information", "Generating  RSA pair for IPK[ " + IpkId + " ] and Length [ " + len + " ]");
                RsaKey rsa = doGenerateKeyPairReturnClearRSAKey(len, publiExp);
               // Log_write.LogWrite(GetIP(), Class_Name, Method_Name, "Information", " RSA pair Generated successfully for IPK[ " + IpkId + " ] and Length [ " + len + " ]");

                if (SaveInDB)//save in db
                {
                    
                //    Log_write.LogWrite(GetIP(), Class_Name, Method_Name, "Information", "Storing RSA key pair in DB for IPK[ " + IpkId + " ] and Length [ " + len + " ]");
                //  ret_val = dal.Insert_RSA_KeyPair(util.ByteArrayToString(rsa.publicModulus), util.ByteArrayToString(rsa.publicExponent), util.ByteArrayToString(rsa.privateExponent),
                    //util.ByteArrayToString(rsa.prime1), util.ByteArrayToString(rsa.prime2), util.ByteArrayToString(rsa.exponent1), util.ByteArrayToString(rsa.exponent2),
                  // util.ByteArrayToString(rsa.coefficient), util.ByteArrayToString(rsa.asn1PrivKey), util.ByteArrayToString(rsa.asn1PubKey), IpkId, len);
                    //  Library.WriteErrorLog("SaveinDB Done");
                    //Log_write.LogWrite(GetIP(), Class_Name, Method_Name, "Information", "Result of Storing RSA key pair for IPK[ " + IpkId + " ] and Length [ " + len + " ] Result[ " + ret_val.ToString() + " ]");
                }
                if (ret_val == -1)
                {
                   // Log_write.LogWrite(GetIP(), Class_Name, Method_Name, "Error", "Unable to Insert RSA key pair for IPK[ " + IpkId + " ] and Length [ " + len + " ] Result[ " + ret_val.ToString() + " ]");
                   // Log_write.LogWrite(GetIP(), Class_Name, Method_Name, "Error", "Exiting Method");
                    return ret_val;
                }
                //Create IPK Request
                else
                {
                    //Create IPK Request
                    int div_val = Convert.ToInt32(len) / 8;
                    string modLen = String.Format("{0:X}", div_val);
                    string ipk_exponent_len = "01";
                    string ipk_exponent = "";
                    string serviceIdentifier = "";
                    string bin = "";
                    string expiryDate = String.Empty;
                    string hashAlgo = "01";//SHA Algorithm
                    string ipkAlgm = "01";
                    string FixHeaderP2 = "6A";
                    string CertificateFormat = "11";
                    string RS_PUB_MOD = "01";
                    string RS_PUB_EXP = "";
                    string RS_PRI_EXP = "";
                    string RS_EXP1 = String.Empty;
                    string IPKFileIndexIssuerSide = RandomString(6);// string.Empty;
                    string CertificateSerialNoIssuedByIssuer = IPKFileIndexIssuerSide;
                    DataTable dt = new DataTable();
                    int res = -1;
                    Read_IPK_Details(IpkId);
                    if (dt.Rows.Count > 0)
                    {
                        bin = dt.Rows[0]["BIN"].ToString().Trim() + "FF";
                        expiryDate = dt.Rows[0]["EXPIRY"].ToString().Trim();
                        serviceIdentifier = dt.Rows[0]["SERVICE_IDENTIFIER"].ToString().Trim();
                        ipk_exponent = dt.Rows[0]["IPK_EXPO"].ToString().Trim();
                        ipk_exponent_len = dt.Rows[0]["IPK_EXPO_LEN"].ToString().Trim();
                    }
                    RS_PUB_MOD = util.ByteArrayToString(rsa.publicModulus);
                    RS_PUB_EXP = util.ByteArrayToString(rsa.publicExponent);
                    RS_PRI_EXP = util.ByteArrayToString(rsa.privateExponent);
                   // Log_write.LogWrite(GetIP(), Class_Name, Method_Name, "Information", "RS_PUB_MOD:" + RS_PUB_MOD);

                    /****************IPK Request Hash Creation (hip) Starts***********************/
                    string unsigned_ipkRequest = bin + IPKFileIndexIssuerSide + (RS_PUB_MOD) + ipk_exponent;
                    //Log_write.LogWrite(GetIP(), Class_Name, Method_Name, "Information", "unsigned_ipkRequest:" + unsigned_ipkRequest);
                    byte[] data1 = new byte[32];
                    data1 = util.String_To_Bytes(unsigned_ipkRequest);
                    SHA1 sha = new SHA1CryptoServiceProvider();
                    byte[] ShaHash = sha.ComputeHash(data1);
                    string hash = util.ByteArrayToString(ShaHash);
                    //Log_write.LogWrite(GetIP(), Class_Name, Method_Name, "Information", "hash :" + hash);
                    string PreparedDataHip = bin + IPKFileIndexIssuerSide + ipkAlgm + hash;
                   // Log_write.LogWrite(GetIP(), Class_Name, Method_Name, "Information", "PreparedDataHip : " + PreparedDataHip);

                    /****************IPK Request Hash Creation (hip) End***********************/


                    /****************IPK Request Hash Creation (Sip) Start***********************/
                    string self_signed_Ipk_Req = bin + IPKFileIndexIssuerSide + ipkAlgm + modLen + ipk_exponent_len + (RS_PUB_MOD) + publiExp;

                   // Log_write.LogWrite(GetIP(), Class_Name, Method_Name, "Information", "RS_PUB_EXP:" + RS_PUB_EXP);
                  //  Log_write.LogWrite(GetIP(), Class_Name, Method_Name, "Information", "RS_PRI_EXP:" + RS_PRI_EXP);

                    int lengthString = 36;// (headerSignedIpk + serviceIdentifier + FixPadding + CertificateFormat + bin + expiryDate + trackingNo + hashAlgo + ipkAlgm + modLen + ipk_exponent_len + ipk_exponent).Length / 2 + hash_Len;
                  // Log_write.LogWrite(GetIP(), Class_Name, Method_Name, "Information", "lengthString Static  :" + lengthString);
                    int LeftmostLen = Convert.ToInt32(div_val - lengthString) * 2;
                    string leftMostRSAPubMod = RS_PUB_MOD.Substring(0, LeftmostLen);

                    string Part1 = self_signed_Ipk_Req;
                 //   Log_write.LogWrite(GetIP(), Class_Name, Method_Name, "Information", "Part1 :" + self_signed_Ipk_Req);

                    string Part2 = FixHeaderP2 + CertificateFormat + bin + expiryDate + CertificateSerialNoIssuedByIssuer + hashAlgo + ipkAlgm + modLen + ipk_exponent_len + leftMostRSAPubMod;
                 //  Log_write.LogWrite(GetIP(), Class_Name, Method_Name, "Information", "Part2 :" + Part2);

                    string Part3 = CertificateFormat + bin + expiryDate + CertificateSerialNoIssuedByIssuer + hashAlgo + ipkAlgm + modLen + ipk_exponent_len + (RS_PUB_MOD) + publiExp;
                 //   Log_write.LogWrite(GetIP(), Class_Name, Method_Name, "Information", "Part3 :" + Part3);
                    byte[] dataP3 = new byte[32];
                    dataP3 = util.String_To_Bytes(Part3);
                    byte[] ShaHashP3 = sha.ComputeHash(dataP3);
                    string hashP3 = util.ByteArrayToString(ShaHashP3);
                   // Log_write.LogWrite(GetIP(), Class_Name, Method_Name, "Information", "hashP3 :" + hashP3);

                    string Part4 = "BC";
                   // Log_write.LogWrite(GetIP(), Class_Name, Method_Name, "Information", "Part4 :" + Part4);
                    //Start from here

                    string clearDatas = Part2 + hashP3 + Part4;
                    byte[] ClearData = HelperFunctions.StringToByteArray(clearDatas);
                    byte[] SignedData = doRSASign(HelperFunctions.StringToByteArray(RS_PUB_MOD), HelperFunctions.StringToByteArray(RS_PUB_EXP), HelperFunctions.StringToByteArray
                        (RS_PRI_EXP), ClearData);
                    string signedData = HelperFunctions.ByteArrayToString(SignedData);
                  //  Log_write.LogWrite(GetIP(), Class_Name, Method_Name, "Information", "Combine and Encrypted of Part 2,3,4 :" + signedData);
                    string FinalData = Part1 + signedData;
                   // Log_write.LogWrite(GetIP(), Class_Name, Method_Name, "Information", "FINAL PART:" + FinalData);
                    // int res = dal.Update_IPK_DetailsMCHIP(IpkId, "PreparedDataHip", "FinalData");
                   // Log_write.LogWrite(GetIP(), Class_Name, Method_Name, "Information", "FILE UPDATED ");

                    string validate_signedData = HelperFunctions.ByteArrayToString(PublicDecryption(signedData, HelperFunctions.ByteArrayToString(rsa.publicExponent), HelperFunctions.ByteArrayToString(rsa.publicModulus)));
                    string data_for_hashing = validate_signedData.Substring(2, 28) + HelperFunctions.ByteArrayToString(rsa.publicModulus) + HelperFunctions.ByteArrayToString(rsa.publicExponent);

                    string ValidateHashUnsign = util.ByteArrayToString(sha.ComputeHash(util.String_To_Bytes(data_for_hashing)));
                    //Log_write.LogWrite(GetIP(), Class_Name, Method_Name, "Information", (hashP3 + "==" + ValidateHashUnsign));
                    if (hashP3 == ValidateHashUnsign)
                    {

                       // Log_write.LogWrite(GetIP(), Class_Name, Method_Name, "Information", "Hash Validate Successfully");

                        //Log_write.LogWrite(GetIP(), Class_Name, Method_Name, "Information", (unsigned_ipkRequest + signedData));

                        // return unsigned_ipkRequest + signedData;
                      //  res = dal.Update_IPK_DetailsMCHIP(IpkId, hashP3, FinalData, PreparedDataHip, IPKFileIndexIssuerSide);
                        // .Update_IPK_Details(IpkId, unsigned_ipkRequest + signedData);
                    }




                   // Log_write.LogWrite(GetIP(), Class_Name, Method_Name, "Information", "Part 1,2,3,4 :" + res);
                    /****************IPK Request Hash Creation (Sip) End***********************/
                    return res;
                }
            }
            catch (Exception ex)
            {


               // Log_write.LogWrite(GetIP(), Class_Name, Method_Name, "Exception", (ex.StackTrace));
                return -1;

            }

        }
        public byte[] PublicDecryption(string encryptedData, string PublicExp = null, string PublicMod = null)
        {
           // Method_Name = "PublicDecryption";
            BigInteger Exponent = new BigInteger(), Modulus = new BigInteger();
            if (PublicExp != null && PublicMod != null)
            {
                Exponent = HexToBigInt(PublicExp);
                Modulus = HexToBigInt(PublicMod);
            }
            //if (!IsPublicKeyLoaded)  // is the public key has been loaded?
            //    throw new CryptographicException
            //        ("Public Key must be loaded before using the Public Deccryption method!");

            // Converting the encrypted data byte array data into a BigInteger instance
            BigInteger encData = HexToBigInt(encryptedData);

            // (encData ^ Exponent) % Modulus - This Decrypt the data using the public Exponent
            System.Numerics.BigInteger bnData = System.Numerics.BigInteger.ModPow(encData, Exponent, Modulus);

            return bnData.ToByteArray().Reverse().ToArray();
        }
        public BigInteger HexToBigInt(string HexString)
        {
            System.Numerics.BigInteger BigInt = System.Numerics.BigInteger.Parse(HexString,
                System.Globalization.NumberStyles.AllowHexSpecifier);
            if (BigInt < 0)
                BigInt = System.Numerics.BigInteger.Pow(2, HexString.Length * 4) - System.Numerics.BigInteger.Abs(BigInt);
            return BigInt;

        }
        public int CreateIPKRequest(string IpkId, string len)
        {
            string Len = "1408";
            string publiExp = "03";
            //Method_Name = "CreateIPKRequest";
            Utility util = new Utility();
            int ret_val = -1;
            try
            {
                bool SaveInDB = true;
              //  Log_write.LogWrite(GetIP(), Class_Name, Method_Name, "Information", "Generating  RSA pair for IPK[ " + IpkId + " ] and Length [ " + len + " ]");
                RsaKey rsa = doGenerateKeyPairReturnClearRSAKey(len, publiExp);
                // Log_write.LogWrite(GetIP(), Class_Name, Method_Name, "Information", " RSA pair Generated successfully for IPK[ " + IpkId + " ] and Length [ " + len + " ]");
                if (SaveInDB)//save in db
                {

                    //    Log_write.LogWrite(GetIP(), Class_Name, Method_Name, "Information", "Storing RSA key pair in DB for IPK[ " + IpkId + " ] and Length [ " + len + " ]");
                    //    ret_val = dal.Insert_RSA_KeyPair(util.ByteArrayToString(rsa.publicModulus), util.ByteArrayToString(rsa.publicExponent), util.ByteArrayToString(rsa.privateExponent),
                    //    util.ByteArrayToString(rsa.prime1), util.ByteArrayToString(rsa.prime2), util.ByteArrayToString(rsa.exponent1), util.ByteArrayToString(rsa.exponent2),
                    //    util.ByteArrayToString(rsa.coefficient), util.ByteArrayToString(rsa.asn1PubKey), util.ByteArrayToString(rsa.asn1PrivKey), IpkId, len);
                    //    Log_write.LogWrite(GetIP(), Class_Name, Method_Name, "Error", "Result of Storing RSA key pair for IPK[ " + IpkId + " ] and Length [ " + len + " ] Result[ " + ret_val.ToString() + " ]");
                    //}
                    if (ret_val == -1)
                    {
                        //  Log_write.LogWrite(GetIP(), Class_Name, Method_Name, "Error", "Unable to Insert RSA key pair for IPK[ " + IpkId + " ] and Length [ " + len + " ] Result[ " + ret_val.ToString() + " ]");
                        //  Log_write.LogWrite(GetIP(), Class_Name, Method_Name, "Error", "Exiting Method");
                        return ret_val;
                    }
                    //Create IPK Request
                    else
                    {
                        int div_val = Convert.ToInt32(len) / 8;
                        string modLen = String.Format("{0:X}", div_val);
                        string ipk_exponent_len = "01";
                        string ipk_exponent = "";
                        string serviceIdentifier = "";
                        string trackingNo = "";
                        string bin = "";
                        string expiryDate = String.Empty;
                        string encKeyName = "";
                        string hashAlgo = "01";//SHA Algorithm
                        string ipkAlgm = "01";
                        string headerUnsignedIpk = "22";
                        string headerSignedIpk = "23";
                        string CertificateFormat = "02";
                        int hash_Len = 20;
                        string FixPadding = "0000";
                        string RS_PUB_MOD = "01";
                        string RS_PUB_EXP = "";
                        string RS_PRI_EXP = "";
                        string RS_PRIME1 = "";
                        string RS_PRIME2 = "";
                        string RS_EXP1 = String.Empty;
                        string RS_EXP2 = "";
                        string RS_COEFF = "01";
                        int res = -1;
                        DataTable dt = new DataTable();
                        // dt = dal.Read_IPK_Details(IpkId);
                        if (dt.Rows.Count > 0)
                        {
                            bin = dt.Rows[0]["BIN"].ToString().Trim();
                            trackingNo = dt.Rows[0]["TRACKING_NUMBER"].ToString().Trim();
                            expiryDate = dt.Rows[0]["EXPIRY"].ToString().Trim();
                            serviceIdentifier = dt.Rows[0]["SERVICE_IDENTIFIER"].ToString().Trim();
                            ipk_exponent = dt.Rows[0]["IPK_EXPO"].ToString().Trim();
                            ipk_exponent_len = dt.Rows[0]["IPK_EXPO_LEN"].ToString().Trim();
                        }
                        RS_PUB_MOD = util.ByteArrayToString(rsa.publicModulus);
                        RS_PUB_EXP = util.ByteArrayToString(rsa.publicExponent);
                        RS_PRI_EXP = util.ByteArrayToString(rsa.privateExponent);

                        //RS_PUB_MOD = "B121EDBBCA623A957FBD432246C24D00A3BC077CCAC7AB78EAD7EE8EE3293C8306F190C4BAAB94A62393D1B27C7F380277274FE3842DD39435BD0F553D25BAA2F8C3BF1EBF42E04B9997BE18E4E41C262A233EE57D49F1556D9A0A44FC2D2E4F2BF5A0DD71E73038EA8CE1C27EFD20E5E17B4BA81229FBE8AC719BAFEA6AC3F005C86D9C9F1A37D6FD7CB1E88E9A6FA6432DA6858ABA00040478025A7DD6A4AC839DE933569122D08222057012BBD083";
                        // RS_PUB_EXP = "03";
                        // RS_PRI_EXP = "76169E7D3196D1B8FFD38216D9D6DE006D2804FDDC851CFB473A9F09ECC6285759F66083271D0DC417B7E121A854D001A4C4DFED02C937B823D35F8E28C3D1C1FB2D2A147F81EADD110FD410989812C41C177F43A8DBF637D7C8AF67C0893B9AAF43A745FEC96985EFC424ACE57637C7199D8CB4BD82397030933A700C1F757DF192C642333667B3D388538DAAA2EF4718DC4EF5A57702F5E803956AB22764ABDF75674F26533AF4B4136D9A142796FB";
                        // Log_write.LogWrite(GetIP(), Class_Name, Method_Name, "Information", "RS_PUB_MOD [ " + RS_PUB_MOD + " ]");

                        string unsigned_ipkRequest = headerUnsignedIpk + modLen +
                                                    // util.ByteArrayToString(rsa.publicModulus)
                                                    (RS_PUB_MOD) + ipk_exponent_len + ipk_exponent + trackingNo;
                        //  Log_write.LogWrite(GetIP(), Class_Name, Method_Name, "Information", "unsigned_ipkRequest [ " + unsigned_ipkRequest + " ]");

                        int lengthString = (headerSignedIpk + serviceIdentifier + FixPadding + CertificateFormat + bin + "FF" +
                                                        expiryDate + trackingNo + hashAlgo + ipkAlgm + modLen + ipk_exponent_len + ipk_exponent).Length / 2 + hash_Len;




                        // Log_write.LogWrite(GetIP(), Class_Name, Method_Name, "Information", "lengthString   :" + lengthString);
                        int LeftmostLen = Convert.ToInt32(div_val - lengthString) * 2;
                        string leftMostRSAPubMod = RS_PUB_MOD.Substring(0, LeftmostLen);
                        string data = headerSignedIpk + serviceIdentifier + FixPadding + CertificateFormat + bin + "FF" +
                                      expiryDate + trackingNo + hashAlgo + ipkAlgm + modLen + ipk_exponent_len + leftMostRSAPubMod + ipk_exponent;

                        byte[] data1 = new byte[32];
                        data1 = util.String_To_Bytes(data);
                        SHA1 sha = new SHA1CryptoServiceProvider();
                        // This is one implementation of the abstract class SHA1.
                        byte[] ShaHash = sha.ComputeHash(data1);
                        string hash = util.ByteArrayToString(ShaHash);
                        //Log_write.LogWrite(GetIP(), Class_Name, Method_Name, "Information", "Hash [ " + hash + " ]");
                        string self_signed_Ipk_Req = data + hash;
                        // Log_write.LogWrite(GetIP(), Class_Name, Method_Name, "Information", "self_signed_Ipk_Req [ " + self_signed_Ipk_Req + " ]");

                        // Log_write.LogWrite(GetIP(), Class_Name, Method_Name, "Information", "RS_PUB_EXP [ " + RS_PUB_EXP + " ]");
                        // Log_write.LogWrite(GetIP(), Class_Name, Method_Name, "Information", "RS_PRI_EXP [ " + RS_PRI_EXP + " ]");
                        string clearDatas = self_signed_Ipk_Req;
                        byte[] ClearData = HelperFunctions.StringToByteArray(clearDatas);
                        byte[] SignedData = doRSASign(HelperFunctions.StringToByteArray(RS_PUB_MOD), HelperFunctions.StringToByteArray(RS_PUB_EXP), HelperFunctions.StringToByteArray
                            (RS_PRI_EXP), ClearData);
                        string signedData = HelperFunctions.ByteArrayToString(SignedData);
                        //Log_write.LogWrite(GetIP(), Class_Name, Method_Name, "Information", " signedData [ " + signedData + " ]");

                        string validate_signedData = HelperFunctions.ByteArrayToString(PublicDecryption(signedData, HelperFunctions.ByteArrayToString(rsa.publicExponent), HelperFunctions.ByteArrayToString(rsa.publicModulus)));
                        //string hastovalidate = string.Empty;
                        //byte[] hash_data = new byte[32];
                        //hash_data = util.String_To_Bytes(validate_signedData.Substring(0, (validate_signedData.Length - 40)));
                        //byte[] ShaHash_final = sha.ComputeHash(hash_data);
                        //                string hash_final = util.ByteArrayToString(ShaHash_final);
                        //Log_write.LogWrite(GetIP(), Class_Name, Method_Name, "Information", (hash + "==" + validate_signedData.Substring(validate_signedData.Length - 40)));
                        if (hash == validate_signedData.Substring(validate_signedData.Length - 40))
                        {

                            //Log_write.LogWrite(GetIP(), Class_Name, Method_Name, "Information", "Hash Validate Successfully");

                            //  Log_write.LogWrite(GetIP(), Class_Name, Method_Name, "Information", (unsigned_ipkRequest + signedData));

                            // return unsigned_ipkRequest + signedData;
                            // res = dal.Update_IPK_DetailsMCHIP(IpkId, hash, unsigned_ipkRequest + signedData, hash, trackingNo);
                            // .Update_IPK_Details(IpkId, unsigned_ipkRequest + signedData);
                        }
                        return res;
                    }

                }
            }
            catch (Exception ex)
            {


                //Log_write.LogWrite(GetIP(), Class_Name, Method_Name, "Information", (ex.StackTrace));
                return -1;

            }

        }
        public static string RandomString(int length)
        {
            const string chars = "ABCDEF0123456789";
            return new string(Enumerable.Repeat(chars, length)
              .Select(s => s[mrandom.Next(s.Length)]).ToArray());
        }
        private void Btn_create_ipk_Click(object sender, RoutedEventArgs e)
        {
            string ca = "";
            string issuer_name = "";
            string textBoxScheme = "";
            string product = "";
            string textBoxBIN = "";
            string textBoxTracking = "";
            string textBoxExpiry = "";
            string textBoxServiceIdentifier = "";
            string type = "";
            string index = "";
            string textBoxLength = "";
            string textBoxExponent = "";


            //
            int ret_value = -1;
            string unsigned_ipkrequest = string.Empty;
            string selfsigned_ipkrequest = string.Empty;
            string ModLen = "BO";
            string ipk_exponent = string.Empty;
            string ipk_exponent_len = string.Empty;
            string hash_algo = string.Empty;
            string service_identifier = string.Empty;
            string ca_expiry = string.Empty;

            if (textBoxBIN.Length < 6)
            {
                MessageBox.Show("Please Enter 6 Digit BIN");
                return;
            }
            string value = textBoxBIN;
            if (value.StartsWith("4") && textBoxTracking.Length < 6)
            {
                MessageBox.Show("Please Enter 6 Digit Tracking Number");
                return;

            }
            if (textBoxExpiry.Length < 4)
            {
                MessageBox.Show("Please Enter 4 Digit Expiry");
                return;
            }
            if (textBoxTracking.Length < 6)
            {

            }
            if (Convert.ToInt32(textBoxExpiry) > Convert.ToInt32(ca_expiry))
            {
                MessageBox.Show("Please Enter Expiry Date below the CA Expiry [" + ca_expiry + "]");
                return;
            }

            else
            {
                if (textBoxServiceIdentifier.Length == 4)
                {
                    service_identifier = textBoxServiceIdentifier + "0000";
                }

                if (textBoxExponent == "03")
                {
                    ipk_exponent = "03";
                    ipk_exponent_len = "01";
                }
                else if (textBoxExponent == "010001")
                {
                    ipk_exponent = "010001";
                    ipk_exponent_len = "03";
                }

                //Save db code 

                //  result = objDAL.Insert_IPK(textBoxBIN.Text, textBoxTracking.Text, textBoxExpiry.Text, comboBoxCA.SelectedValue.ToString(),
                //   comboBoxProduct.SelectedValue.ToString(), textBoxServiceIdentifier.Text, getmacAddress(), textBoxIndex.Text, ipk_exponent, ipk_exponent_len, comboBoxIssuer.SelectedValue.ToString(), Convert.ToInt32(textBoxLength.Text));
                int result = 1;
                byte[] byte_ipkid = Encoding.ASCII.GetBytes(result.ToString());
                if (textBoxScheme.ToUpper().Contains("VISA"))
                {
                    CreateIPKRequest(result.ToString(), textBoxLength);
                }
                else
                {
                    CreateIPKRequestMCHIPhIP(result.ToString(), textBoxLength);
                }

            }
        }
        private byte[] Hex_to_ByteArray(string s)
        {
            s = s.Replace(" ", "");
            byte[] buffer = new byte[s.Length / 2];
            for (int i = 0; i < s.Length; i += 2)
            {
                buffer[i / 2] = (byte)Convert.ToByte(s.Substring(i, 2), 16);
            }
            return buffer;
        }
        public int Save_HIP_File()
        {
            string file_path = string.Empty;
            DataTable dt = new DataTable();
         //   SaveFileDialog save_log = new SaveFileDialog();
            int ret_value = -1;
           // save_log.DefaultExt = ".hip";
            //save_log.Filter = "Binary File (*.HIP)|*.HIP";    //File extention managed as per requirement.
           // dt = objDAL.ReadIPKDetails(result);
          //  save_log.FileName = "1-" + dt.Rows[0]["HIP_FILE_DATA"].ToString().Substring(8, 6) + ".HIP";
            //  save_log.FileName = "1-0000C1.HIP";
           //if (save_log.ShowDialog() == System.Windows.Forms.DialogResult.OK && save_log.FileName.Length > 0)
            {
                try
                {


                    string hip_data = dt.Rows[0]["HIP_FILE_DATA"].ToString();
                    if (hip_data == "")
                    {
                        MessageBox.Show("No data found to save in HIP File");
                        ret_value = 0;
                    }
                    else
                    {
                        FileStream stream = new FileStream(save_log.FileName, FileMode.Create, FileAccess.ReadWrite);
                        stream.Write(Hex_to_ByteArray(hip_data), 0, Hex_to_ByteArray(hip_data).Length);
                        stream.Close();
                        ret_value = 1;
                    }
                }

                catch (Exception ex)
                {
                    ret_value = -1;
                    MessageBox.Show("Exception Occured while saving HIP File.\nException" + ex.Message);
                }
            }
            return ret_value;
        }
        public int Save_INP_File()
        {
            string file_path = string.Empty;
            DataTable dt = new DataTable();
          //  SaveFileDialog save_log = new SaveFileDialog();
            int ret_value = -1;
           // save_log.DefaultExt = ".INP";
           // save_log.Filter = "Binary File (*.INP)|*.INP";    //File extention managed as per requirement.
                                                              //  save_log.FileName = "CC" + textBoxTracking.Text + ".INP";
           // save_log.FileName = "CC" + textBoxTracking.Text + ".INP";
            string data_signed = string.Empty;
            if (save_log.ShowDialog() == System.Windows.Forms.DialogResult.OK && save_log.FileName.Length > 0)
            {
                try
                {
                   // dt = objDAL.ReadIPKDetails(result);//result

                    data_signed = dt.Rows[0]["SIGNED_DATA"].ToString();


                    FileStream stream = new FileStream(save_log.FileName, FileMode.Create, FileAccess.ReadWrite);
                    stream.Write(Hex_to_ByteArray(data_signed), 0, Hex_to_ByteArray(data_signed).Length);
                    stream.Close();
                    ret_value = 1;
                }

                catch (Exception ex)
                {
                    ret_value = -1;
                    MessageBox.Show("Exception Occured while saving HIP File.\nException" + ex.Message);
                }
            }
            return ret_value;
        }
        private void Btn_export_Click(object sender, RoutedEventArgs e)
        {
            string file_path = string.Empty;
            DataTable dt = new DataTable();
            // SaveFileDialog save_log = new SaveFileDialog();
            //SaveFileDialog save_log_sip = new SaveFileDialog();
            int save_value = -1;
            // save_value = Save_HIP_File();
            // save_value = Save_SIP_File();

            if (textBoxBIN.StartsWith("4"))
            {
                save_value = Save_INP_File();
                if (save_value == 1)
                {
                    MessageBox.Show("IPK Request Created successfully.");
                    this.Close();
                }
            }
            if (textBoxBIN.StartsWith("5"))
            {
                save_value = Save_HIP_File();
                if (save_value == 1)
                    save_value = Save_SIP_File();
                else
                    MessageBox.Show("Error occured while saving files");
            }
        }
    }
}



