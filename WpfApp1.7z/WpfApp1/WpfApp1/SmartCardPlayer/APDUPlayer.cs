using System;
using System.Xml;
using System.Globalization;
using System.Collections.Generic;
using GemCard;
using System.Security.Cryptography;
using System.IO;
using System.Text;

namespace SmartCardPlayer
{
    /// <summary>
    /// List of sequence name. It is just a Dictionary of string indexed by string
    /// </summary>
    public class SequenceParameter : Dictionary<string, string> {
    }


    /// <summary>
    /// This class provides a set of functions to process APDU commands described in
    /// an XML format
    /// 
    /// The format is the following
    /// 
    /// <CommandList>
    ///		<Apdu Name="VerifyCHV" Class="A0" Ins="20" P1="0" P2="1" P3="8" Data="31323334FFFFFFFF" />
    ///		<Apdu Name="Get Response" Class="A0" Ins="C0" P1="0" P2="0" P3="SW2" Data="" />
    ///		<Apdu Name="Select 6F3A" Class="A0" Ins="A4" P1="0" P2="0" P3="2" Data="6F3A" />
    ///		<Apdu Name="Read Record" Class="A0" Ins="B2" P1="1" P2="4" P3="D15" Data="" />
    ///	</CommandList>
    /// </summary>

    public class APDUPlayer
	{
		private const	string	
			xmlNodeApdu = "Apdu",
            xmlNodeSequence = "Sequence",
            xmlNodeCommand = "Command",
            xmlAttrApdu = "Apdu",
            xmlAttrSequence = "Sequence",
			xmlAttrName = "Name",
			xmlAttrClass = "Class",
			xmlAttrIns = "Ins",
			xmlAttrP1 = "P1",
			xmlAttrP2 = "P2",
			xmAttrLe = "Le",
			xmlAttrLc = "Lc",
			xmlAttrData = "Data";
        private	const	string
			paramSW1 = "SW1",
			paramSW2 = "SW2";
        private	bool	m_bLeSW2 = false;
        private bool    m_bLeData = false;
        private short   m_nDataId = -1;
		private	byte	m_bSW1Cond = 0;
		private	bool	m_bCheckSW1 = false;
        private bool    m_bReplay = false;
        public string CMACOK;
        private List<string> TLVDatas;
        private XmlNodeList m_xmlApduList = null;
        private XmlNodeList m_xmlSequenceList = null;
		private	ICard		m_iCard = null;
		private	APDUResponse	m_apduResp = null;
        public int ThreadID = 0, ThreadCount = 0;
        public APDUResponse apduResp = null;
        private string InitUpdateFixData = "2021222324252627", InitupdateResp = null, CardSeq = null, CardKeyData = null, CardChallenge = null, CardCrypto = null,
                        CardAuthCryptogram = null, HostCrypto = null, HostAuthCryptogram = null, 
                        SKUenc = null, SKUmac = null, SKUdek = null, Kenc = null, Kmac = null, Kdek = null;
        public string m_apduLogString = null;
        public string encryptionKey = null;
        public bool NonDerived = false, IsGemalto = false, Auth = false;
        private bool GoNext = true;
        public int Counter = -1;

        private APDULogList m_logList = new APDULogList();
        TextInfo myTI = new CultureInfo("en-US", false).TextInfo;

        /// <summary>
        /// Constructor
        /// </summary>
        /// <param name="apduFileName">XML file name with the description of the commands</param>
        /// <param name="iCard">Card interface to process the APDUs</param>
        
        public APDUPlayer(string apduFileName, ICard iCard)
		{
			XmlDocument	apduDoc = new XmlDocument();

			try
			{
				// Load the document
				apduDoc.Load(apduFileName);

				// Get the list of APDUs
				m_xmlApduList = apduDoc.GetElementsByTagName(xmlNodeApdu);	

                // Get the list of sequences
                m_xmlSequenceList = apduDoc.GetElementsByTagName(xmlNodeSequence);

				m_iCard = iCard;
			}
			catch
			{
                throw new ApduCommandException(ApduCommandException.NotValidDocument);
			}
		}
        //public APDUPlayer()
        //{ }
        public APDULogList Log
        {
            get
            {
                return m_logList;
            }
        }


        /// <summary>
        /// Constructs an APDU player
        /// </summary>
        /// <param name="iCard">ICard interface to the Smartcard</param>
        public APDUPlayer(ICard iCard)
        {
            m_iCard = iCard;
            m_apduLogString = String.Format("{0} | New Log Started....\n", System.DateTime.Now);
            Auth = false;
        }


        /// <summary>
        /// Constructs an APDU player
        /// </summary>
        /// <param name="apduFileName">APDU file name</param>
        /// <param name="seqFileName">Sequence file name</param>
        /// <param name="iCard">ICard interface to the Smartcard</param>
        public APDUPlayer(string apduFileName, string seqFileName, ICard iCard)
        {
            LoadAPDUFile(apduFileName);
            LoadSequenceFile(seqFileName);

            m_iCard = iCard;
        }
        //Triple DES Encryption
        //public string ByteArrayToString(byte[] data)
        //{
        //    StringBuilder sDataOut;

        //    if (data != null)
        //    {
        //        sDataOut = new StringBuilder(data.Length * 2);
        //        for (int nI = 0; nI < data.Length; nI++)
        //            sDataOut.AppendFormat("{0:X02}", data[nI]);
        //    }
        //    else
        //        sDataOut = new StringBuilder();

        //    return sDataOut.ToString();
        //}
        public string ByteArrayToString(byte[] byteArray)
        {
            StringBuilder hex;
            if (byteArray != null)
            {
                hex = new StringBuilder(byteArray.Length * 2);
                foreach (var b in byteArray)
                    hex.AppendFormat("{0:x2}", b);
                
            }
            else
                hex = new StringBuilder();
            return hex.ToString().ToUpper();
        }
        public string tDesEncrypt(string Key, String Data, String CMode, bool Decrypt = false)
        {
            try
            {
                TripleDESCryptoServiceProvider tDES = new TripleDESCryptoServiceProvider();

                tDES.Key = StringToByteArray(Key);
                if (CMode == "ECB") { tDES.Mode = CipherMode.ECB; }
                else if (CMode == "CBC") { tDES.Mode = CipherMode.CBC; }
                else if (CMode == "CFB") { tDES.Mode = CipherMode.CFB; }
                else if (CMode == "CTS") { tDES.Mode = CipherMode.CTS; }
                else if (CMode == "OFB") { tDES.Mode = CipherMode.OFB; }


                tDES.Padding = PaddingMode.None;
                tDES.IV = StringToByteArray("0000000000000000");
                ICryptoTransform TRANS = Decrypt ? tDES.CreateDecryptor():tDES.CreateEncryptor();
                byte[] Bdata = StringToByteArray(Data);
                MemoryStream ms = new MemoryStream(StringToByteArray(Data));

                CryptoStream cs = new CryptoStream(ms, TRANS, CryptoStreamMode.Write);
                cs.Write(Bdata, 0, Bdata.Length);
                cs.FlushFinalBlock();
                //string sms = BitConverter.ToString(ms.ToArray());
                //sms = sms.Replace("-", "");
                return ByteArrayToString(ms.ToArray());
            }
            catch (Exception ex)
            { return ex.ToString(); }
        }
        public string CMAC(string SKUmac, string data, String CMODE, String IV)
        {
            //*************************Generation of MAC Session Key*****************************

            //Key Devide in two part
            //*******************************************************
            byte[] keybytes = StringToByteArray(SKUmac);
            byte[] key1 = new byte[8];
            Array.Copy(keybytes, 0, key1, 0, 8);
            byte[] key2 = new byte[8];
            Array.Copy(keybytes, 8, key2, 0, 8);

            DES des1 = DES.Create();
            des1.Key = key1;

            if (CMODE == "ECB") { des1.Mode = CipherMode.ECB; }
            else if (CMODE == "CBC") { des1.Mode = CipherMode.CBC; }
            else if (CMODE == "CFB") { des1.Mode = CipherMode.CFB; }
            else if (CMODE == "CTS") { des1.Mode = CipherMode.CTS; }
            else if (CMODE == "OFB") { des1.Mode = CipherMode.OFB; }

            des1.Padding = PaddingMode.None;
            des1.IV = StringToByteArray(IV); ;
            //**********************************************************

            //Data Devide in two part
            //*******************************************************
            byte[] DataByte = StringToByteArray(data);
            //Left Most 8 Digit
            byte[] Data1 = new byte[8];
            Array.Copy(DataByte, 0, Data1, 0, 8);
            //Right Most 8 Digit
            byte[] Data2 = new byte[8];
            Array.Copy(DataByte, 8, Data2, 0, 8);

            //Apply DES Encryption operation on DataPart 1 with using left most 8 byte of Session_Mac(des1) as a key 

            byte[] intermediate = des1.CreateEncryptor().TransformFinalBlock(Data1, 0, 8);

            string x = exclusiveOR(intermediate, Data2);

            //Apply 3DES encryption on x, using Session_Mac(SKUmac) Key + iv = 00 00 00 00 00 00 00 00 here you get 8 byte as a output = CMAC

            CMACOK = tDesEncrypt(SKUmac, x, "CBC");

            return CMACOK;
        }

        public string ConvertHexToString(string HexValue)
        {
            string StrValue = "";
            while (HexValue.Length > 0)
            {
                StrValue += System.Convert.ToChar(System.Convert.ToUInt32(HexValue.Substring(0, 2), 16)).ToString();
                HexValue = HexValue.Substring(2, HexValue.Length - 2);
            }
            return StrValue;
        }
        public byte[] StringToByteArray(String hex)
        {
            int NumberChars = hex.Length / 2;
            byte[] bytes = new byte[NumberChars];
            using (var sr = new StringReader(hex))
            {
                for (int i = 0; i < NumberChars; i++)
                    bytes[i] = Convert.ToByte(new string(new char[2] { (char)sr.Read(), (char)sr.Read() }),16);
            }
            return bytes;
        }



        public string ConvertStringToHex(string asciiString)
        {
            string hex = "";
            foreach (char c in asciiString)
            {
                int tmp = c;
                hex += String.Format("{0:x2}", (uint)System.Convert.ToUInt32(tmp.ToString()));
            }
            return hex;
        }

        //public string ByteArrayToString(byte[] byteArray)
        //{
        //    var hex = new StringBuilder(byteArray.Length * 2);
        //    foreach (var b in byteArray)
        //        hex.AppendFormat("{0:x2}", b);
        //    return hex.ToString().ToUpper();
        //}

        public string exclusiveOR(byte[] Xorkey, byte[] Xordata)
        {
            if (Xorkey.Length == Xordata.Length)
            {
                byte[] result = new byte[Xorkey.Length];
                for (int i = 0; i < Xorkey.Length; i++)
                {
                    result[i] = (byte)(Xorkey[i] ^ Xordata[i]);
                }
                string hex = BitConverter.ToString(result).Replace("-", "");
                return hex;
            }
            else
            {
                throw new ArgumentException();
            }
        }

        public static string xorIt(string key, string input)
        {
            StringBuilder sb = new StringBuilder();
            for (int i = 0; i < input.Length; i++)
                sb.Append((char)(input[i] ^ key[(i % key.Length)]));
            String result = sb.ToString();

            return result;
        }
        /// <summary>
        /// Loads a Sequence file
        /// </summary>
        /// <param name="fileName">Sequence file name</param>
        public void LoadAPDUFile(string fileName)
        {
            XmlDocument apduDoc = new XmlDocument();

            try
            {
                // Load the document
                apduDoc.Load(fileName);

                // Get the list of sequences
                m_xmlApduList = apduDoc.GetElementsByTagName(xmlNodeApdu);
            }
            catch
            {
                throw new ApduCommandException(ApduCommandException.NotValidDocument);
            }
        }


        /// <summary>
        /// Loads an APDU file
        /// </summary>
        /// <param name="fileName">APDU file name</param>
        public void LoadSequenceFile(string fileName)
        {
            XmlDocument apduDoc = new XmlDocument();

            try
            {
                // Load the document
                apduDoc.Load(fileName);

                // Get the list of sequences
                m_xmlSequenceList = apduDoc.GetElementsByTagName(xmlNodeSequence);
            }
            catch
            {
                throw new ApduCommandException(ApduCommandException.NotValidDocument);
            }
        }


		/// <summary>
		/// APDUNames property, gets a list of the APDU Names
		/// </summary>
		public	string[]	APDUNames
		{
			get
			{
				string[]	apduNames = null;
				int	nCount = m_xmlApduList.Count;

				if (nCount != 0)
				{
					apduNames = new string[nCount];
					for (int nI = 0; nI < nCount; nI++)
					{
						XmlNode apdu = m_xmlApduList.Item(nI);

						apduNames[nI] = apdu.Attributes[xmlAttrName].Value;
					}
				}

				return apduNames;
			}
		}


        /// <summary>
        /// Process a simple APDU command, Parameters can be provided in the APDUParam object
        /// </summary>
        /// <param name="command">APDU command name</param>
        /// <param name="apduParam">Parameters for the command</param>
        /// <returns>An APDUResponse object with the response of the card </returns>
        public APDUResponse ProcessCommand(string apduName, APDUParam apduParam)
		{
			APDUCommand		apduCmd = APDUDB("00", "A4", "04", "00", "A0000000031010", "07");;
                                    
			// Get the base APDU
			//apduCmd = APDUByName(apduName);
			if (apduCmd == null)
                throw new ApduCommandException(ApduCommandException.NoSuchCommand);

			//apduCmd.Update(apduParam);
			
			return ExecuteApduCommand(apduCmd);
		}

        public APDUResponse ProcessCommand(string Classs, string Inss, string P1s, string P2s, string Datas, string Lens)
        {
            APDUCommand apduCmd = APDUDB(Classs,Inss,P1s,P2s,Datas,Lens);

            // Get the base APDU
            //apduCmd = APDUByName(apduName);
            if (apduCmd == null)
                throw new ApduCommandException(ApduCommandException.NoSuchCommand);

            //apduCmd.Update(apduParam);

            m_apduLogString += String.Format("{0} | Sent [{1}, {2}, {3}, [{4}], {5}, {6}]\n", System.DateTime.Now, Classs, Inss, P1s, P2s, Lens, Datas);
            APDUResponse APDU_resp = ExecuteApduCommand(apduCmd);
            m_apduLogString += String.Format("{0} | Response [{1}{2}]\n", System.DateTime.Now, APDU_resp.SW1.ToString("X02"), APDU_resp.SW2.ToString("X02"));
            if (APDU_resp.Data != null)
            {
                StringBuilder sDataOut = new StringBuilder(APDU_resp.Data.Length * 2);
                for (int nI = 0; nI < APDU_resp.Data.Length; nI++)
                    sDataOut.AppendFormat("{0:X02}", APDU_resp.Data[nI]);
                m_apduLogString += String.Format("{0} | Response Data [{1}]\n", System.DateTime.Now, sDataOut);
            }
            return APDU_resp;
        }

        public APDUResponse ProcessCommand(APDUParam apduParam)
        {
            APDUCommand apduCmd = null;

            //// Get the base APDU
            //apduCmd = APDUByName(apduName);
            //if (apduCmd == null)
            //    throw new ApduCommandException(ApduCommandException.NoSuchCommand);

            apduCmd.Update(apduParam);
            return ExecuteApduCommand(apduCmd);
        }


		/// <summary>
		/// Process a simple APDU command, all parameters are included in the 
		/// XML description
		/// </summary>
		/// <param name="command">APDU command name</param>
		/// <returns>An APDUResponse object with the response of the card </returns>
		public	APDUResponse	ProcessCommand(string apduName)
		{
			APDUCommand		apduCmd = null;
		
			apduCmd = APDUByName(apduName);
			if (apduCmd == null)
                throw new ApduCommandException(ApduCommandException.NoSuchCommand);

			return ExecuteApduCommand(apduCmd);
		}

        public string HSM_ResPCode(int hsmRespCodez)
        {
            string code = "";
            string hexcode = hsmRespCodez.ToString("X03");

            if (hexcode == "000")
            {
                code = myTI.ToTitleCase("HSM Command Successfully Completed");
                return code;
            }
            switch (hexcode)
            {
                case "001":
                    code = myTI.ToTitleCase("HSM Disconnected");
                    break;
                case "002":
                    code = myTI.ToTitleCase("HSM HOST_MEMORY LOST");
                    break;
                case "003":
                    code = myTI.ToTitleCase("HSM SLOT_ID_INVALID");
                    break;
                case "004":
                    code = myTI.ToTitleCase("HSM FLAGS_INVALID");
                    break;
                case "005":
                    code = myTI.ToTitleCase("HSM GENERAL_ERROR");
                    break;
                case "006":
                    code = myTI.ToTitleCase("HSM FUNCTION_FAILED");
                    break;
                case "007":
                    code = myTI.ToTitleCase("HSM ARGUMENTS_BAD");
                    break;
                case "008":
                    code = myTI.ToTitleCase("HSM NO_EVENT");
                    break;
                case "009":
                    code = myTI.ToTitleCase("HSM NEED_TO_CREATE_THREADS");
                    break;
                case "00A":
                    code = myTI.ToTitleCase("HSM CANT_LOCK");
                    break;
                case "010":
                    code = myTI.ToTitleCase("HSM ATTRIBUTE_READ_ONLY");
                    break;
                case "011":
                    code = myTI.ToTitleCase("HSM ATTRIBUTE_SENSITIVE");
                    break;
                case "012":
                    code = myTI.ToTitleCase("HSM ATTRIBUTE_TYPE_INVALID");
                    break;
                case "013":
                    code = myTI.ToTitleCase("HSM ATTRIBUTE_VALUE_INVALID");
                    break;
                case "020":
                    code = myTI.ToTitleCase("HSM DATA_INVALID");
                    break;
                case "021":
                    code = myTI.ToTitleCase("HSM DATA_LEN_RANGE");
                    break;
                case "030":
                    code = myTI.ToTitleCase("HSM DEVICE_ERROR");
                    break;
                case "031":
                    code = myTI.ToTitleCase("HSM DEVICE_MEMORY");
                    break;
                case "032":
                    code = myTI.ToTitleCase("HSM DEVICE_REMOVED");
                    break;
                case "040":
                    code = myTI.ToTitleCase("HSM ENCRYPTED_DATA_INVALID");
                    break;
                case "041":
                    code = myTI.ToTitleCase("HSM ENCRYPTED_DATA_LEN_RANGE");
                    break;
                case "050":
                    code = myTI.ToTitleCase("HSM FUNCTION_CANCELED");
                    break;
                case "051":
                    code = myTI.ToTitleCase("HSM FUNCTION_NOT_PARALLEL");
                    break;
                case "052":
                    code = myTI.ToTitleCase("HSM ENCRYPTED_DATA_INVALID");
                    break;
                case "054":
                    code = myTI.ToTitleCase("HSM ENCRYPTED_DATA_LEN_RANGE");
                    break;
                case "060":
                    code = myTI.ToTitleCase("HSM KEY_HANDLE_INVALID");
                    break;
                case "061":
                    code = myTI.ToTitleCase("HSM KEY_SENSITIVE");
                    break;
                case "062":
                    code = myTI.ToTitleCase("HSM KEY_SIZE_RANGE");
                    break;
                case "063":
                    code = myTI.ToTitleCase("HSM KEY_TYPE_INCONSISTENT");
                    break;
                case "064":
                    code = myTI.ToTitleCase("HSM KEY_NOT_NEEDED");
                    break;
                case "065":
                    code = myTI.ToTitleCase("HSM KEY_CHANGED");
                    break;

                case "066":
                    code = myTI.ToTitleCase("HSM KEY_NEEDED");
                    break;
                case "067":
                    code = myTI.ToTitleCase("HSM KEY_INDIGESTABLE");
                    break;
                case "068":
                    code = myTI.ToTitleCase("HSM KEY_FUNCTION_NOT_PERMITTED");
                    break;
                case "069":
                    code = myTI.ToTitleCase("HSM KEY_NOT_WRAPPABLE");
                    break;

                case "06A"://6A
                    code = myTI.ToTitleCase("HSM KEY_UNEXTRACTABLE");
                    break;
                case "06B"://6B
                    code = myTI.ToTitleCase("HSM KEY_PARAMS_INVALID");
                    break;
                case "06C"://6C
                    code = myTI.ToTitleCase("HSM KEYLEN_INVALID");
                    break;
                case "070":
                    code = myTI.ToTitleCase("HSM MECHANISM_INVALID");
                    break;
                    //*********************** YAHAN TAK KER LIYA********************
                case "071":
                    code = myTI.ToTitleCase("HSM MECHANISM_PARAM_INVALID");
                    break;
                case "080":
                    code = myTI.ToTitleCase("HSM OBJECT_CLASS_INCONSISTENT");
                    break;
                case "081":
                    code = myTI.ToTitleCase("HSM OBJECT_CLASS_INVALID");
                    break;
                case "082":
                    code = myTI.ToTitleCase("HSM OBJECT_HANDLE_INVALID");
                    break;

                case "090":
                    code = myTI.ToTitleCase("HSM OPERATION_ACTIVE");
                    break;
                case "091":
                    code = myTI.ToTitleCase("HSM OPERATION_NOT_INITIALIZED");
                    break;
                case "0A0":
                    code = myTI.ToTitleCase("HSM PIN_INCORRECT");
                    break;
                case "0A1":
                    code = myTI.ToTitleCase("HSM PIN_INVALID");
                    break;
                case "0A2":
                    code = myTI.ToTitleCase("HSM PIN_LEN_RANGE");
                    break;
                case "0A3":
                    code = myTI.ToTitleCase("HSM PIN_EXPIRED");
                    break;
                case "0A4":
                    code = myTI.ToTitleCase("HSM PIN_LOCKED");
                    break;

                case "0B0":
                    code = myTI.ToTitleCase("HSM SESSION_CLOSED");
                    break;
                case "0B1":
                    code = myTI.ToTitleCase("HSM SESSION_COUNT");
                    break;
                case "0B2":
                    code = myTI.ToTitleCase("HSM SESSION_EXCLUSIVE_EXISTS");
                    break;
                case "0B3":
                    code = myTI.ToTitleCase("HSM SESSION_HANDLE_INVALID");
                    break;
                case "0B4":
                    code = myTI.ToTitleCase("HSM SESSION_PARALLEL_NOT_SUPPORTED");
                    break;
                case "0B5":
                    code = myTI.ToTitleCase("HSM SESSION_READ_ONLY");
                    break;
                case "0B6":
                    code = myTI.ToTitleCase("HSM SESSION_EXISTS");
                    break;
                case "0B7":
                    code = myTI.ToTitleCase("HSM SESSION_READ_ONLY_EXISTS");
                    break;
                case "0B8":
                    code = myTI.ToTitleCase("HSM SESSION_READ_WRITE_SO_EXIST");
                    break;

                case "0C0":
                    code = myTI.ToTitleCase("HSM SIGNATURE_INVALID");
                    break;
                case "0C1":
                    code = myTI.ToTitleCase("HSM SIGNATURE_LEN_RANGE");
                    break;
                case "0D0":
                    code = myTI.ToTitleCase("HSM TEMPLATE_INCOMPLETE");
                    break;
                case "0D1":
                    code = myTI.ToTitleCase("HSM TEMPLATE_INCONSISTENT");
                    break;
                case "0E0":
                    code = myTI.ToTitleCase("HSM TOKEN_NOT_PRESENT");
                    break;
                case "0E1":
                    code = myTI.ToTitleCase("HSM TOKEN_NOT_RECOGNIZED");
                    break;
                case "0E2":
                    code = myTI.ToTitleCase("HSM TOKEN_WRITE_PROTECTED");
                    break;
                case "0F0":
                    code = myTI.ToTitleCase("HSM UNWRAPPING_KEY_HANDLE_INVALID");
                    break;
                case "0F1":
                    code = myTI.ToTitleCase("HSM UNWRAPPING_KEY_SIZE_RANGE");
                    break;
                case "0F2":
                    code = myTI.ToTitleCase("HSM UNWRAPPING_KEY_TYPE_INCONSISTENT");
                    break;


                case "100":
                    code = myTI.ToTitleCase("HSM USER_ALREADY_LOGGED_IN");
                    break;
                case "101":
                    code = myTI.ToTitleCase("HSM USER_NOT_LOGGED_IN");
                    break;
                case "102":
                    code = myTI.ToTitleCase("HSM USER_PIN_NOT_INITIALIZED");
                    break;
                case "103":
                    code = myTI.ToTitleCase("HSM USER_TYPE_INVALID");
                    break;
                case "104":
                    code = myTI.ToTitleCase("HSM USER_ANOTHER_ALREADY_LOGGED_IN");
                    break;
                case "105":
                    code = myTI.ToTitleCase("HSM USER_TOO_MANY_TYPES");
                    break;
                case "110":
                    code = myTI.ToTitleCase("HSM WRAPPED_KEY_INVALID");
                    break;
                case "112":
                    code = myTI.ToTitleCase("HSM WRAPPED_KEY_LEN_RANGE");
                    break;
                case "113":
                    code = myTI.ToTitleCase("HSM WRAPPING_KEY_HANDLE_INVALID");
                    break;
                case "114":
                    code = myTI.ToTitleCase("HSM WRAPPING_KEY_SIZE_RANGE");
                    break;
                case "115":
                    code = myTI.ToTitleCase("HSM WRAPPING_KEY_TYPE_INCONSISTENT");
                    break;
                case "191":
                    code = myTI.ToTitleCase("HSM CRYPTOKI_ALREADY_INITIALIZE");
                    break;
                case "120":
                    code = myTI.ToTitleCase("HSM RANDOM_SEED_NOT_SUPPORTED");
                    break;
                case "121":
                    code = myTI.ToTitleCase("HSM RANDOM_NO_RNG");
                    break;
                case "130":
                    code = myTI.ToTitleCase("HSM DOMAIN_PARAMS_INVALID");
                    break;
                case "150":
                    code = myTI.ToTitleCase("HSM BUFFER_TOO_SMALL");
                    break;
                case "160":
                    code = myTI.ToTitleCase("HSM SAVED_STATE_INVALID");
                    break;
                case "170":
                    code = myTI.ToTitleCase("HSM INFORMATION_SENSITIVE");
                    break;
                case "180":
                    code = myTI.ToTitleCase("HSM STATE_UNSAVEABLE");
                    break;
                case "190":
                    code = myTI.ToTitleCase("HSM CRYPTOKI_NOT_INITIALIZED");
                    break;
                case "1A0":
                    code = myTI.ToTitleCase("HSM MUTEX_BAD");
                    break;
                case "1A1":
                    code = myTI.ToTitleCase("HSM MUTEX_NOT_LOCKED");
                    break;

                default:
                    code = myTI.ToTitleCase("Unknown error");
                    break;

            }

            return code;
        }

        public string APDURESPCODE(APDUResponse apduResp)
        {
            //string sw1 = apduResp.SW1.ToString("X02");
            //string sw2 = apduResp.SW1.ToString("X02");
            string code = "";

            if (apduResp.SW1 == 0x90 && apduResp.SW2 == 0x00)
            {
                code=  myTI.ToTitleCase("Normal ending of the command");
                return code;
            }
            switch (apduResp.SW1)
            {
                case 0x61:
                    code= myTI.ToTitleCase("Issue get_response command");
                    break;
                case 0x62:
                    code= myTI.ToTitleCase("State of non-volatile memory unchanged");
                    switch (apduResp.SW2)
                    {
                        case 0x00:
                            code= myTI.ToTitleCase("No information given");
                            break;
                        case 0x81:
                            code= myTI.ToTitleCase("Part of returned data may be corrupted");
                            break;
                        case 0x82:
                            code= myTI.ToTitleCase("End of file/record reached before reading Le bytes");
                            break;
                        case 0x83:
                            code= myTI.ToTitleCase("Selected file invalidated");
                            break;
                        case 0x84:
                            code= myTI.ToTitleCase("FCI is invalid");
                            break;
                    }
                    break;
                case 0x63:
                    code= myTI.ToTitleCase("State of non-volatile memory changed. ");
                    switch (apduResp.SW2)
                    {
                        case 0x00:
                            code= myTI.ToTitleCase("No information given");
                            break;
                        case 0x81:
                            code= myTI.ToTitleCase("File filled up by the last write");
                            break;
                    }
                    break;
                case 0x64:
                    code= myTI.ToTitleCase("State of non-volatile memory unchanged");
                    break;
                case 0x65:
                    code= myTI.ToTitleCase("State of non-volatile memory changed. ");
                    switch (apduResp.SW2)
                    {
                        case 0x00:
                            code= myTI.ToTitleCase("No information given");
                            break;
                        case 0x81:
                            code= myTI.ToTitleCase("Memory failure");
                            break;
                    }
                    break;
                case 0x66:
                    code= myTI.ToTitleCase("Security-related error");
                    break;
                case 0x67:
                    switch (apduResp.SW2)
                    {
                        case 0x00:
                            code= myTI.ToTitleCase("Wrong length");
                            break;
                    }
                    break;
                case 0x68:
                    code= myTI.ToTitleCase("Functions in CLA not supported. ");
                    switch (apduResp.SW2)
                    {
                        case 0x00:
                            code= myTI.ToTitleCase("No information given");
                            break;
                        case 0x81:
                            code= myTI.ToTitleCase("Logical channel not supported");
                            break;
                        case 0x82:
                            code= myTI.ToTitleCase("Secure messaging not supported");
                            break;
                    }
                    break;
                case 0x69:
                    code= myTI.ToTitleCase("Command not allowed. ");
                    switch (apduResp.SW2)
                    {
                        case 0x00:
                            code= myTI.ToTitleCase("No information given");
                            break;
                        case 0x81:
                            code= myTI.ToTitleCase("Command incompatible with file structure");
                            break;
                        case 0x82:
                            code= myTI.ToTitleCase("Security status not satisfied");
                            break;
                        case 0x83:
                            code= myTI.ToTitleCase("Authentication method blocked");
                            break;
                        case 0x84:
                            code= myTI.ToTitleCase("Referenced data invalidated");
                            break;
                        case 0x85:
                            code= myTI.ToTitleCase("Conditions of use not satisfied");
                            break;
                        case 0x86:
                            code= myTI.ToTitleCase("Command not allowed (no current EF)");
                            break;
                        case 0x87:
                            code= myTI.ToTitleCase("Expected SM data objects missing");
                            break;
                        case 0x88:
                            code= myTI.ToTitleCase("Secure messaging data object incorrect");
                            break;
                    }
                    break;
                case 0x6A:
                    switch (apduResp.SW2)
                    {
                        case 0x00:
                            code= myTI.ToTitleCase("No information given");
                            break;
                        case 0x80:
                            code= myTI.ToTitleCase("Incorrect parameters in the data field");
                            break;
                        case 0x81:
                            code= myTI.ToTitleCase("Function not supported");
                            break;
                        case 0x82:
                            code= myTI.ToTitleCase("File not found");
                            break;
                        case 0x83:
                            code= myTI.ToTitleCase("Record not found");
                            break;
                        case 0x84:
                            code= myTI.ToTitleCase("Not enough memory space in the file");
                            break;
                        case 0x85:
                            code= myTI.ToTitleCase("Lc inconsistent with TLV structure");
                            break;
                        case 0x86:
                            code= myTI.ToTitleCase("Incorrect parameters P1-P2");
                            break;
                        case 0x87:
                            code= myTI.ToTitleCase("Lc inconsistent with P1-P2");
                            break;
                        case 0x88:
                            code= myTI.ToTitleCase("Referenced data not found");
                            break;
                        default:
                            code= myTI.ToTitleCase("Wrong parameter(s) P1-P2. ");
                            break;
                    }
                    break;
                case 0x6B:
                    if (apduResp.SW2 == 0x00)
                        code= myTI.ToTitleCase("Wrong parameter(s) P1-P2");
                    break;
                case 0x6C:
                    code= myTI.ToTitleCase("Incorrect Le. SW2 indicates the exact length");
                    break;
                case 0x6D:
                    if (apduResp.SW2 == 0x00)
                        code= myTI.ToTitleCase("Instruction code not supported or invalid");
                    break;
                case 0x6E:
                    if (apduResp.SW2 == 0x00)
                        code= myTI.ToTitleCase("Class not supported");
                    break;
                case 0x6F:
                    if (apduResp.SW2 == 0x00)
                        code= myTI.ToTitleCase("No precise diagnosis");
                    break;
                default:
                    code= myTI.ToTitleCase("Unknown error code");
                    break;
            }
            
            return code;

        }


        /// <summary>
        /// Process an APDU sequence and execute each of its commands in the sequence order
        /// </summary>
        /// <param name="apduSequenceName">Name of the sequence to play</param>
        /// <returns>APDUResponse object of the last commad executed</returns>
        public APDUResponse ProcessSequence(string apduSequenceName)
        {
            return ProcessSequence(apduSequenceName, null);
        }


        /// <summary>
        /// Process an APDU sequence and execute each of its commands in the sequence order
        /// </summary>
        /// <param name="apduSequenceName">Name of the sequence to play</param>
        /// <param name="seqParam">An array of SequenceParam object used as parameters for the sequence</param>
        /// <returns>APDUResponse object of the last command executed</returns>
        //public APDUResponse ProcessSequence(string apduSequenceName,  Dictionary<string, string> seqParam)
        public APDUResponse ProcessSequence(string apduSequenceName, SequenceParameter seqParam)
        {
            APDUResponse apduResp = null;
            //Dictionary<string, string> l_seqParam = null;
            SequenceParameter l_seqParam = null;

            // Get the sequence
            XmlNode apduSeq = SequenceByName(apduSequenceName);

            if (apduSeq == null)
                throw new ApduCommandException(ApduCommandException.NoSuchSequence);

            // Process the params of the sequence
            l_seqParam = ProcessParams(seqParam, apduSeq.Attributes);

            // Get the list of commands to execute
            XmlNodeList xmlCmdList = apduSeq.ChildNodes;
            for (int nI = 0; nI < xmlCmdList.Count; nI++)
                apduResp = ProcessSeqCmd(xmlCmdList.Item(nI), l_seqParam);

            return apduResp;
        }


        /// <summary>
        /// Gets an APDU command by name
        /// </summary>
        /// <param name="apduName">APDU name</param>
        /// <returns>An APDUCommand object, null if the command was not found</returns>
        public APDUCommand APDUByName(string apduName)
        {
            APDUCommand apduCmd = null;

            if (m_xmlApduList != null)
            {
                for (int nI = 0; nI < m_xmlApduList.Count; nI++)
                {
                    XmlNode apdu = m_xmlApduList.Item(nI);

                    string sName = apdu.Attributes[xmlAttrName].Value;
                    if (sName == apduName)
                    {
                        apduCmd = APDUDB("00", "A4", "04", "00", "A0000000031010","07");
                        break;
                    }
                }
            }

            return apduCmd;
        }
        public string Convert_ASCIIToHex(string str)
        {
            int length = str.Length / 2;
            string hexString = length.ToString("X");
            if (hexString.Length == 1)
            {
                hexString = "0" + hexString;
            }
            return hexString;
        }
        #region Private methods


        /// <summary>
        /// Builds an APDUCommand object from an XmlNode representing the command.
        /// 
        /// This command uses the result of a previous command to fill some paramaters
        /// P3 in this case represents the length expected by the command
        /// P3 = "R,0:SW1?xx"
        ///     m_bReplay is set to true
        ///		m_bSW1Cond is set with the value xx
        ///		m_bCheckSW1 is set to true
        ///		When the command is called, if SW1 == xx, the command is played a 
        ///		second time with Le = resp.SW2
        ///
        /// P3 = "R,xx:DRyy"
        ///     m_bReplay is set to true
        ///     m_bLeData is set to true
        ///     m_nDataId is set to yy
        ///     Le is set to xx for the first call of the command
        ///     Then the command is replayed with Le = Le + resp.Data[m_nDataId - 1]
        /// 
        ///	P3 = "SW2"
        ///		if SW1 == 0x9F on the previous call to a command, m_bLeSW2 is set to true
        ///		if m_bLeSW2 if true, Le is replaced with resp.SW2
        ///		
        ///	P3 = "Dxx"
        ///		if resp.Data id not null from the previous command,
        ///		xx is used as the index of the byte that gives Le in the response data
        ///		Le = Data[xx]
        /// </summary>
        /// <param name="xmlApdu">XML representation of the command</param>
        /// <returns>An APDUCommand object build from the XML data</returns>
        private APDUCommand APDUFromXml(XmlNode xmlApdu)
        {
            XmlElement apduElt = (XmlElement)xmlApdu;

            m_bLeData = false;
            m_bCheckSW1 = false;
            m_bReplay = false;

            // Get command detail
            string sClass =  (string)xmlApdu.Attributes["Class"].Value;
            string sIns =  (string)xmlApdu.Attributes["Ins"].Value;
            string sP1 = (string)xmlApdu.Attributes["P1"].Value;
            string sP2 = (string)xmlApdu.Attributes["P2"].Value;
            string sP3 = (string)xmlApdu.Attributes["P3"].Value;

            sP3 = sP3.ToUpper();
            string sData =  apduElt.GetAttribute("Data");

            byte bP1 = 0;
            byte bP2 = 0;
            byte bP3 = 0;
            byte bLe = 0;
            byte bClass = byte.Parse(sClass, NumberStyles.AllowHexSpecifier);
            byte bIns = byte.Parse(sIns, NumberStyles.AllowHexSpecifier);
            if (sP1 != "" && sP1 != "@")
                bP1 = byte.Parse(sP1, NumberStyles.AllowHexSpecifier);
            if (sP2 != "" && sP2 != "@")
                bP2 = byte.Parse(sP2, NumberStyles.AllowHexSpecifier);

            int nId = 0;
            int nId2 = 0;

            // Process P3 parameter
            if (sP3.IndexOf("DR") != -1)
            {
                // Use data byte of previous command, index value follows D
                try
                {
                    int nIdx = int.Parse(sP3.Substring(sP3.IndexOf("DR") + 2));
                    if ((m_apduResp != null) && (m_apduResp.Data != null))
                        bLe = m_apduResp.Data[nIdx - 1];
                    else
                        bLe = 0;
                }
                catch
                {
                    throw new ApduCommandException(ApduCommandException.ParamP3Format);
                }
            }
            else if (sP3.IndexOf("DL") != -1)
            {
                bP3 = (byte)(sData.Length / 2);
                bLe = 0;
            }
            else if (sP3.IndexOf(paramSW2) != -1)
            {
                if (m_bLeSW2)
                {
                    // Use SW2 parameter of previous command
                    bLe = m_apduResp.SW2;
                }
                else
                    bLe = 0;
            }
            else if ((nId = sP3.IndexOf('R')) == 0)
            {
                m_bReplay = true;
                if (sP3[++nId] == ',')
                {
                    nId2 = sP3.IndexOf(':');
                    if (nId2 != -1)
                    {
                        bLe = byte.Parse(sP3.Substring(nId + 1, nId2 - nId - 1));
                    }
                    else
                        throw new ApduCommandException(ApduCommandException.ParamP3Format);
                }
                else if (sP3[nId] == ':')
                {
                    bLe = 0;
                }

                if (sP3.IndexOf(paramSW1, nId) != -1)
                {
                    if ((nId2 = sP3.IndexOf('?', nId)) != -1)
                    {
                        m_bCheckSW1 = true;
                        m_bSW1Cond = byte.Parse(sP3.Substring(nId2 + 1), NumberStyles.AllowHexSpecifier);
                    }
                    else
                        throw new ApduCommandException(ApduCommandException.ParamP3Format);
                }
                else if ((nId2 = sP3.IndexOf("DR", nId)) != -1)
                {
                    m_bLeData = true;
                    m_nDataId = short.Parse(sP3.Substring(nId2 + 2));
                }
                else
                    throw new ApduCommandException(ApduCommandException.ParamP3Format);
            }
            else if (sP3 != "")
            {
                bP3 = byte.Parse(sP3, NumberStyles.AllowHexSpecifier);
                if (sData.Length == 0)
                    bLe = bP3;
            }

            byte[] baData = null;
            if (bP3 != 0 && sData.Length != 0)
            {
                baData = new byte[bP3];
                for (int nJ = 0; nJ < sData.Length; nJ += 2)
                    baData[nJ / 2] = byte.Parse(sData.Substring(nJ, 2), NumberStyles.AllowHexSpecifier);
                bLe = 0;
            }

            return new APDUCommand(bClass, bIns, bP1, bP2, baData, bLe);
        }



        private APDUCommand APDUDB(string Class, string Ins, string P1, string P2, string APDUData, string P3 )
        {
            //XmlElement apduElt = (XmlElement)xmlApdu;

            m_bLeData = false;
            m_bCheckSW1 = false;
            m_bReplay = false;

            // Get command detail
            string sClass = Class;
            string sIns = Ins;
            string sP1 = P1;
            string sP2 = P2;
            string sP3 = P3;

            sP3 = sP3.ToUpper();
            string sData = APDUData;
            byte bP1 = 0;
            byte bP2 = 0;
            byte bP3 = 0;
            byte bLe = 0;
            byte bClass = byte.Parse(sClass, NumberStyles.AllowHexSpecifier);
            byte bIns = byte.Parse(sIns, NumberStyles.AllowHexSpecifier);
            if (sP1 != "" && sP1 != "@")
                bP1 = byte.Parse(sP1, NumberStyles.AllowHexSpecifier);
            if (sP2 != "" && sP2 != "@")
                bP2 = byte.Parse(sP2, NumberStyles.AllowHexSpecifier);

            int nId = 0;
            int nId2 = 0;

            // Process P3 parameter
            if (sP3.IndexOf("DR") != -1)
            {
                // Use data byte of previous command, index value follows D
                try
                {
                    int nIdx = int.Parse(sP3.Substring(sP3.IndexOf("DR") + 2));
                    if ((m_apduResp != null) && (m_apduResp.Data != null))
                        bLe = m_apduResp.Data[nIdx - 1];
                    else
                        bLe = 0;
                }
                catch
                {
                    throw new ApduCommandException(ApduCommandException.ParamP3Format);
                }
            }
            else if (sP3.IndexOf("DL") != -1)
            {
                bP3 = (byte)(sData.Length / 2);
                bLe = 0;
            }
            else if (sP3.IndexOf(paramSW2) != -1)
            {
                if (m_bLeSW2)
                {
                    // Use SW2 parameter of previous command
                    bLe = m_apduResp.SW2;
                }
                else
                    bLe = 0;
            }
            else if ((nId = sP3.IndexOf('R')) == 0)
            {
                m_bReplay = true;
                if (sP3[++nId] == ',')
                {
                    nId2 = sP3.IndexOf(':');
                    if (nId2 != -1)
                    {
                        bLe = byte.Parse(sP3.Substring(nId + 1, nId2 - nId - 1));
                    }
                    else
                        throw new ApduCommandException(ApduCommandException.ParamP3Format);
                }
                else if (sP3[nId] == ':')
                {
                    bLe = 0;
                }

                if (sP3.IndexOf(paramSW1, nId) != -1)
                {
                    if ((nId2 = sP3.IndexOf('?', nId)) != -1)
                    {
                        m_bCheckSW1 = true;
                        m_bSW1Cond = byte.Parse(sP3.Substring(nId2 + 1), NumberStyles.AllowHexSpecifier);
                    }
                    else
                        throw new ApduCommandException(ApduCommandException.ParamP3Format);
                }
                else if ((nId2 = sP3.IndexOf("DR", nId)) != -1)
                {
                    m_bLeData = true;
                    m_nDataId = short.Parse(sP3.Substring(nId2 + 2));
                }
                else
                    throw new ApduCommandException(ApduCommandException.ParamP3Format);
            }
            else if (sP3 != "")
            {
                bP3 = byte.Parse(sP3, NumberStyles.AllowHexSpecifier);
                if (sData.Length == 0)
                    bLe = bP3;
            }

            byte[] baData = null;
            if (bP3 != 0 && sData.Length != 0)
            {
                baData = new byte[bP3];
                for (int nJ = 0; nJ < sData.Length; nJ += 2)
                    baData[nJ / 2] = byte.Parse(sData.Substring(nJ, 2), NumberStyles.AllowHexSpecifier);
                bLe = 0;
            }

            return new APDUCommand(bClass, bIns, bP1, bP2, baData, bLe);
        }

        /// <summary>
        /// Executes an APDU command
        /// </summary>
        /// <param name="apduCmd">APDUCommand object to execute</param>
        /// <returns>APDUResponse object of the response</returns>
        private APDUResponse ExecuteApduCommand(APDUCommand apduCmd)
        {
            byte bLe = 0;

            // Send the command
            APDUResponse m_apduResp = m_iCard.Transmit(apduCmd);
            AddLog(new APDULog(apduCmd, m_apduResp));

            // Check if SW2 can be used as Le for the next call
            if (m_apduResp.SW1 == 0x9F)
                m_bLeSW2 = true;
            else
                m_bLeSW2 = false;

            if (m_bReplay)
            {
                if (m_bCheckSW1 && (m_apduResp.SW1 == m_bSW1Cond))
                {
                    // Replay the command with Le = SW2 of response
                    bLe = m_apduResp.SW2;
                    m_bCheckSW1 = false;
                }
                else if (m_bLeData)
                {
                    // Replay the command with Le = Le + Data[m_nDataId - 1] of response
                    bLe = (byte)(m_apduResp.Data[m_nDataId - 1] + apduCmd.Le);
                    m_bLeData = false;
                }

                // Replay the command
                apduCmd = new APDUCommand(
                    apduCmd.Class,
                    apduCmd.Ins,
                    apduCmd.P1,
                    apduCmd.P2,
                    apduCmd.Data,
                    bLe);

                m_apduResp = m_iCard.Transmit(apduCmd);
                AddLog(new APDULog(apduCmd, m_apduResp));

                m_bReplay = false;
            }

            return m_apduResp;
        }


        /// <summary>
        /// Gets the XML node for a Sequence of APDUs
        /// </summary>
        /// <param name="name">Name of the sequence</param>
        /// <returns>XmlNode of the sequence</returns>
        private XmlNode SequenceByName(string name)
        {
            XmlNode apduSeq = null;

            if (m_xmlSequenceList != null)
            {
                for (int nI = 0; nI < m_xmlSequenceList.Count; nI++)
                {
                    apduSeq = m_xmlSequenceList.Item(nI);

                    string sName = apduSeq.Attributes[xmlAttrName].Value;
                    if (sName == name)
                        break;
                    else
                        apduSeq = null;
                }
            }

            return apduSeq;
        }


        /// <summary>
        /// Process the parameters of a Sequence. If a parameter of the same name is found in the list of parameters
        /// it overrides the XML parameter of the sequence
        /// </summary>
        /// <param name="seqParam">List of parameters</param>
        /// <param name="xmlSeqParam">Parameters of the XML sequence</param>
        /// <returns>The list of parameters to used to process the sequence of APDU commands</returns>
//        private Dictionary<string, string> ProcessParams(Dictionary<string, string> seqParam, XmlAttributeCollection xmlSeqParam)
        private SequenceParameter ProcessParams(SequenceParameter seqParam, XmlAttributeCollection xmlSeqParam)
        {
            //Dictionary<string, string> l_seqParam = new Dictionary<string, string>();
            SequenceParameter l_seqParam = new SequenceParameter();

            int nNbParam = xmlSeqParam.Count;

            for (int nI = 0; nI < nNbParam; nI++)
            {
                XmlNode xNode = xmlSeqParam.Item(nI);

                string name = xNode.Name;
                string val = xNode.Value;

                // Check if a val overrides the XML parameter of Sequence
                if (seqParam != null)
                {
                    try
                    {
                        val = seqParam[name];
                    }
                    catch
                    {
                    }
                }

                l_seqParam.Add(name, val);
            }

            return l_seqParam;
        }


        /// <summary>
        /// Builds an APDUParam object from the parameters of a command and a set of parameter for a sequence
        /// </summary>
        /// <param name="xmlAttrs">List of parameters of the APDU</param>
        /// <param name="seqParam">List of parameters of the sequence</param>
        /// <returns>APDUParam object</returns>
//        private APDUParam BuildCommandParam(XmlAttributeCollection xmlAttrs, Dictionary<string, string> seqParam)
        private APDUParam BuildCommandParam(XmlAttributeCollection xmlAttrs, SequenceParameter seqParam)
        {
            APDUParam apduParam = null;
            byte[] baData = null;
            string sVal = null;

            apduParam = new APDUParam();

            for (int nI = 0; nI < xmlAttrs.Count; nI++)
            {
                XmlNode xmlParam = xmlAttrs.Item(nI);
                switch (xmlParam.Name)
                {
                    case xmlAttrP1:
                    {
                        try
                        {
                            sVal = seqParam[xmlParam.Value];
                        }
                        catch
                        {
                            sVal = xmlParam.Value;
                        }
                        finally
                        {
                            apduParam.P1 = byte.Parse(sVal, NumberStyles.AllowHexSpecifier);
                        }
                        break;
                    }

                    case xmlAttrP2:
                    {
                        try
                        {
                            sVal = seqParam[xmlParam.Value];
                        }
                        catch
                        {
                            sVal = xmlParam.Value;
                        }
                        finally
                        {
                            apduParam.P2 = byte.Parse(sVal, NumberStyles.AllowHexSpecifier);
                        }
                        break;
                    }

                    case xmlAttrData:
                    {
                        try
                        {
                            sVal = seqParam[xmlParam.Value];
                        }
                        catch
                        {
                            sVal = xmlParam.Value;
                        }
                        finally
                        {
                            int nLen = sVal.Length / 2;
                            if (nLen != 0)
                            {
                                baData = new byte[nLen];
                                for (int nJ = 0; nJ < nLen; nJ++)
                                    baData[nJ] = byte.Parse(sVal.Substring(nJ * 2, 2), NumberStyles.AllowHexSpecifier);

                                apduParam.Data = baData;
                            }
                        }
                        break;
                    }
                }
            }

            return apduParam;
        }


        /// <summary>
        /// Process a command of a sequence of APDU
        /// </summary>
        /// <param name="xmlCmd">XML node representing the command</param>
        /// <param name="seqParam">List of parameters of the sequence</param>
        /// <returns>APDUResponse object of command executed</returns>
//        private APDUResponse ProcessSeqCmd(XmlNode xmlCmd, Dictionary<string, string> seqParam)
        private APDUResponse ProcessSeqCmd(XmlNode xmlCmd, SequenceParameter seqParam)
        {
            bool bApdu = false;
            bool bSeq = false;
            string sApduName = null;
            string sSeqName = null;
            APDUResponse apduResp = null;

            // Get the APDU or Sequence name
            try
            {
                // Get the Apdu name to run
                sApduName = xmlCmd.Attributes[xmlAttrApdu].Value;
                bApdu = true;
            }
            catch
            {
            }
            finally
            {
                try
                {
                    sSeqName = xmlCmd.Attributes[xmlAttrSequence].Value;
                    bSeq = true;
                }
                catch
                {
                }

                if ((bSeq | bApdu) == false)
                    throw new ApduCommandException(ApduCommandException.MissingApduOrCommand);
            }

            if (bApdu)
            {
                APDUParam apduParams = BuildCommandParam(xmlCmd.Attributes, seqParam);
                apduResp = ProcessCommand(sApduName, apduParams);
            }

            if (bSeq)
            {
                // Process a sub sequence
                apduResp = ProcessSequence(sSeqName, seqParam);
            }

            return apduResp;
        }

        private void AddLog(APDULog apduLog)
        {
            m_logList.Add(apduLog);
        }
        #endregion


        #region Card Authentication Starts
        /******************************** Card Authentication Starts*****************************/
        public void Authentication(string Application = null)
        {
            try
            {
                Auth = false;
                if (Application == null)
                    goto DirectInitUpdate;
                string Length = (Application.Length / 2).ToString("X02");
                m_apduLogString += String.Format("{0} | ===========================================================================\n", System.DateTime.Now);
                m_apduLogString += String.Format("{0} | Authentication Called for AID [{1}]\n", System.DateTime.Now, Application);
                apduResp = ProcessCommand("00", "A4", "04", "00", Application, Length);

                if (apduResp.SW1 == 0x61)
                {
                    if (apduResp.Data != null)
                    {
                        StringBuilder sDataOut = new StringBuilder(apduResp.Data.Length * 2);
                        for (int nI = 0; nI < apduResp.Data.Length; nI++)
                            sDataOut.AppendFormat("{0:X02}", apduResp.Data[nI]);

                        //MessageBox.Show(ByteArrayToString(apduResp.Data));
                    }
                    apduResp = ProcessCommand("00", "C0", "00", "00", "", apduResp.SW2.ToString("X02"));
                    if (apduResp.SW1 == 0x90 && apduResp.SW2 == 0x00)
                    {
                        if (apduResp.Data != null)
                        {
                            StringBuilder sDataOut = new StringBuilder(apduResp.Data.Length * 2);
                            for (int nI = 0; nI < apduResp.Data.Length; nI++)
                                sDataOut.AppendFormat("{0:X02}", apduResp.Data[nI]);
                        }
                    }
                }
                if (apduResp.SW1 != 0x90 && apduResp.SW2 != 0x00)
                {
                    //Error
                   
                }
            DirectInitUpdate:
                if (IsGemalto)
                {
                    GetDATA();
                }
                InitializeUpdate();
            }
            catch (Exception ex)
            {
                //Exception
            }
        }
        private void GetDATA(string command = "80,CA,DF,50")
        {
            try
            {
                apduResp = ProcessCommand(command.Split(',')[0], command.Split(',')[1], command.Split(',')[2], command.Split(',')[3], "", "00");

                if (apduResp.SW1 == 0x6C)
                {
                    if (apduResp.Data != null)
                    {
                        StringBuilder sDataOut = new StringBuilder(apduResp.Data.Length * 2);
                        for (int nI = 0; nI < apduResp.Data.Length; nI++)
                            sDataOut.AppendFormat("{0:X02}", apduResp.Data[nI]);
                    }


                    //************************Select FCI*******************************
                    apduResp = ProcessCommand(command.Split(',')[0], command.Split(',')[1], command.Split(',')[2], command.Split(',')[3], "", apduResp.SW2.ToString("X02"));
                }
                if (apduResp.SW1 == 0x90 && apduResp.SW2 == 0x00)
                {
                    if (apduResp.Data != null)
                    {
                        StringBuilder sDataOut = new StringBuilder(apduResp.Data.Length * 2);
                        for (int nI = 0; nI < apduResp.Data.Length; nI++)
                            sDataOut.AppendFormat("{0:X02}", apduResp.Data[nI]);
                    }
                }

                if (command != "80,CA,9F,7F") GetDATA("80,CA,9F,7F");
                return;
            }
            catch (Exception ex)
            {
                return;
            }
        }
        public void InitializeUpdate()
        {
            Auth = false;
            m_apduLogString += String.Format("{0} | ===========================================================================\n", System.DateTime.Now);
            m_apduLogString += String.Format("{0} | InitializeUpdate Called\n", System.DateTime.Now);
            try
            {
                //************************InitializeUpdate*******************************
                apduResp = ProcessCommand("80", "50", "00", "00", InitUpdateFixData, "08");
                if (apduResp.SW1 == 0x61)
                {
                    if (apduResp.Data != null)
                    {
                        StringBuilder sDataOut = new StringBuilder(apduResp.Data.Length * 2);
                        for (int nI = 0; nI < apduResp.Data.Length; nI++)
                            sDataOut.AppendFormat("{0:X02}", apduResp.Data[nI]);
                    }
                    apduResp = ProcessCommand("00", "C0", "00", "00", "", apduResp.SW2.ToString("X02"));
                }
                if (apduResp.SW1 == 0x90 && apduResp.SW2 == 0x00)
                {
                    if (apduResp.Data != null)
                    {
                        StringBuilder sDataOut = new StringBuilder(apduResp.Data.Length * 2);
                        for (int nI = 0; nI < apduResp.Data.Length; nI++)
                            sDataOut.AppendFormat("{0:X02}", apduResp.Data[nI]);
                        InitupdateResp = BitConverter.ToString(apduResp.Data).Replace("-", "");
                        m_apduLogString += String.Format("{0} | InitupdateResp [{1}]\n", System.DateTime.Now, InitupdateResp);
                        CardSeq = InitupdateResp.Substring(24, 4);
                        m_apduLogString += String.Format("{0} | CardSeq [{1}]\n", System.DateTime.Now, CardSeq);
                        if (IsGemalto)
                        {
                            CardKeyData = InitupdateResp.Substring(0, 4) + InitupdateResp.Substring(8, 8);
                        }
                        else
                        {
                            CardKeyData = InitupdateResp.Substring(8, 12);
                        }
                        m_apduLogString += String.Format("{0} | CardKeyData [{1}]\n", System.DateTime.Now, CardKeyData);

                        //********Encryption Start********]
                        CardChallenge = InitupdateResp.Substring(28, 12);
                        m_apduLogString += String.Format("{0} | CardChallenge [{1}]\n", System.DateTime.Now, CardChallenge);
                    }
                    if (NonDerived)
                        GenSessionKeyWithKMC();
                    else
                        DriveKey();

                }
                else
                {
                    //Error 
                }
            }
            catch (Exception ex)
            {
                //toolStripStatusLabel2.Text = ex.ToString();
                
            }
        }
        public bool GenSessionKeyWithKMC()
        {
            try
            {
                //*************************Key Derivation using KMC*****************************
                //*************************SESSION KEY GENERATION WITH KMC*****************************
                SKUenc = tDesEncrypt(encryptionKey.Trim(), String.Format("0182{0}000000000000000000000000", CardSeq), "CBC");
                m_apduLogString += String.Format("{0} | SKUenc [{1}]\n", System.DateTime.Now, SKUenc);
                SKUmac = tDesEncrypt(encryptionKey.Trim(), String.Format("0101{0}000000000000000000000000", CardSeq), "CBC");
                m_apduLogString += String.Format("{0} | SKUmac [{1}]\n", System.DateTime.Now, SKUmac);
                SKUdek = tDesEncrypt(encryptionKey.Trim(), String.Format("0181{0}000000000000000000000000", CardSeq), "CBC");
                m_apduLogString += String.Format("{0} | SKUdek [{1}]\n", System.DateTime.Now, SKUdek);
                return CardCryptogram();
            }
            catch (Exception ex)
            {
                //toolStripStatusLabel2.Text = ex.ToString();
                return false;
            }
        }
        public bool DriveKey()
        {
            try
            {
                //*************************Key Derivation using KMC*****************************
                Kenc = String.Format("{0}F001{0}0F01", CardKeyData);
                Kenc = tDesEncrypt(encryptionKey.Trim(), Kenc, "ECB");
                Kmac = String.Format("{0}F002{0}0F02", CardKeyData);
                Kmac = tDesEncrypt(encryptionKey.Trim(), Kmac, "ECB");
                Kdek = String.Format("{0}F003{0}0F03", CardKeyData);
                Kdek = tDesEncrypt(encryptionKey.Trim(), Kdek, "ECB");
                return GenSessionKeyWithDerivedKMC();
            }
            catch (Exception ex)
            {
                return false;
            }
        }
        public bool GenSessionKeyWithDerivedKMC()
        {
            try
            {
                //*************************SESSION KEY GENERATION WITH DERIVED KMC or DERIVATION*****************************
                SKUenc = tDesEncrypt(Kenc, String.Format("0182{0}000000000000000000000000", CardSeq), "CBC");
                SKUmac = tDesEncrypt(Kmac, String.Format("0101{0}000000000000000000000000", CardSeq), "CBC");
                SKUdek = tDesEncrypt(Kdek, String.Format("0181{0}000000000000000000000000", CardSeq), "CBC");
                return CardCryptogram();
            }
            catch (Exception ex)
            {
                //toolStripStatusLabel2.Text = ex.ToString();
                return false;
            }
        }
        public bool CardCryptogram()
        {
            m_apduLogString += String.Format("{0} | CardCryptogram Called\n", System.DateTime.Now);
            try
            {
                //*************************Calculation for Card Cryptogram:*****************************
                CardCrypto = String.Format("{0}{1}{2}8000000000000000", InitUpdateFixData, CardSeq, CardChallenge);
                m_apduLogString += String.Format("{0} | CardCrypto [{1}]\n", System.DateTime.Now, CardCrypto);

                CardAuthCryptogram = tDesEncrypt(SKUenc, CardCrypto, "CBC");
                m_apduLogString += String.Format("{0} | CardAuthCryptogram [{1}]\n", System.DateTime.Now, CardAuthCryptogram);
                if (InitupdateResp.Substring(InitupdateResp.Length - 16) == CardAuthCryptogram.Substring(CardAuthCryptogram.Length - 16))
                {
                    return HostCryptogram();
                }
                return false;
            }
            catch (Exception ex)
            {
                //toolStripStatusLabel2.Text = ex.ToString();
                return false;
            }
        }
        public bool HostCryptogram()
        {
            try
            {
                //*************************Calculation for Host Cryptogram:*****************************
                HostCrypto = String.Format("{0}{1}{2}8000000000000000", CardSeq, CardChallenge, InitUpdateFixData);
                HostAuthCryptogram = tDesEncrypt(SKUenc, HostCrypto, "CBC");
                HostAuthCryptogram = HostAuthCryptogram.Substring(HostAuthCryptogram.Length - 16);
                return ExternalAuthentucation();
            }
            catch (Exception ex)
            {
                //toolStripStatusLabel2.Text = ex.Message;
                return false;
            }
        }
        public bool ExternalAuthentucation()
        {
            try
            {
                string CMACdata = String.Format("8482000010{0}800000", HostAuthCryptogram);
                string CMACResult = CMAC(SKUmac, CMACdata, "CBC", "0000000000000000");//divide and cmac partone of cmacdata 
                string ExternalAuth = HostAuthCryptogram.Trim() + CMACResult.Trim();
                apduResp = ProcessCommand("84", "82", "00", "00", ExternalAuth, "10");
                if (apduResp.SW1 == 0x90 && apduResp.SW2 == 0x00)
                {
                    if (apduResp.Data != null)
                    {
                        StringBuilder sDataOut = new StringBuilder(apduResp.Data.Length * 2);
                        for (int nI = 0; nI < apduResp.Data.Length; nI++)
                            sDataOut.AppendFormat("{0:X02}", apduResp.Data[nI]);
                    }
                    Auth = true;
                    return true;
                }
                else
                {
                    //Error 
                    return false;
                }

            }
            catch (Exception ex)
            {
                //toolStripStatusLabel2.Text = ex.Message;
                return false;
            }
        }
        /********************************Card Authentication Ends*****************************/
        #endregion


        // Summary:
        //     Do the personalization of given StoreDataList DGIs by selecting the given AID on connected card with reader .
        //
        // Parameters:
        //   StoreDataList:
        //     The list of DGIs in format of TLV. (Must Start Length of Data. Example If 
        //                                                          Data Length <128 then length between 00 to 7F 
        //                                                          Data Length <255 then it should be start with 81 and length between 80 to EF
        //                                                          Data Length >=255 then it should be start with 82 and length greater or equal to FF
        //                                                          Exaple: 7FData, 81EfData, 82FFFFData)
        //  AID:
        //      AID which need to select for personalization like Visa/Machip/PSE/PPSE etc.
        // References:
        //  APDUResp:
        //      APDU responce received on last command (9000 in case of success and return TRUE).
        //  ErrorAPDUCmd:
        //      Last APDU command which send to card.
        // Exceptions:
        //   T:System.ArgumentNullException:
        //     The s parameter is null.
        public bool Personalization(string StoreDataList, int DataLengthChar, string AID)
        {
            bool IsEncrypted = false;
            try
            {
                m_apduLogString += String.Format("{0} | ===========================================================================\n", System.DateTime.Now);
                m_apduLogString += String.Format("{0} | Personalization Called....\n", System.DateTime.Now);
                if (StoreDataList != null)
                {
                    TLVDatas = new List<string>();
                    String APDUData = null;
                    int APDUDataLenByte = 0, APDUDataLenChar = 0;
                    if (StoreDataList.Length == DataLengthChar)
                    {
                        while (StoreDataList.Length > 6)           // DGI -> 4 char and Length -> 2 char (minimum)
                        {
                            if (StoreDataList.Substring(4, 2) == "82")
                            {
                                //3 Byte Length
                                APDUDataLenByte = Convert.ToInt16(StoreDataList.Substring(6, 4), 16);       //4 char length padded with 00
                                APDUDataLenChar = APDUDataLenByte * 2;
                                if (StoreDataList.Length >= (4 + 2 + 4 + APDUDataLenChar))                  //DGI -> 4 char, 82 -> 2 char, Len -> 4 char and DataLen in char
                                {
                                    APDUData = StoreDataList.Substring(0, 4);                               //DGI 4 char
                                    APDUData += "FF";                                                       //At Place of 82 added FF
                                    APDUData += StoreDataList.Substring(6, 4);                              //Length 4 char
                                    APDUData += StoreDataList.Substring(10, APDUDataLenChar);               //Actual Data
                                    StoreDataList = StoreDataList.Substring(4 + 2 + 4 + APDUDataLenChar);   //Removed Extracted Data
                                }
                                else
                                {
                                    //Error
                                    return false;
                                }

                            }
                            else if (StoreDataList.Substring(4, 2) == "81")
                            {
                                //2 Byte Length
                                APDUDataLenByte = Convert.ToInt16(StoreDataList.Substring(6, 2), 16);
                                APDUDataLenChar = APDUDataLenByte * 2;
                                if (StoreDataList.Length >= (4 + 2 + 2 + APDUDataLenChar))                  //DGI -> 4 char, 81 -> 2 char, Len -> 2 char and DataLen in char
                                {
                                    APDUData = StoreDataList.Substring(0, 4);                               //DGI 4 char
                                    APDUData += StoreDataList.Substring(6, 2);                              //Length 2 char and removed 81
                                    APDUData += StoreDataList.Substring(8, APDUDataLenChar);                //Actual Data
                                    StoreDataList = StoreDataList.Substring(4 + 2 + 2 + APDUDataLenChar);   //Removed Extracted Data
                                }
                                else
                                {
                                    //Error
                                    return false;
                                }
                            }
                            else
                            {
                                //1 Byte Length
                                APDUDataLenByte = Convert.ToInt16(StoreDataList.Substring(4, 2), 16);
                                APDUDataLenChar = APDUDataLenByte * 2;
                                if (StoreDataList.Length >= (4 + 2 + APDUDataLenChar))                      //DGI -> 4 char, Len -> 2 char and DataLen in char
                                {
                                    APDUData = StoreDataList.Substring(0, 4);                               //DGI 4 char
                                    APDUData += StoreDataList.Substring(4, 2);                              //Length 2 char
                                    APDUData += StoreDataList.Substring(6, APDUDataLenChar);                //Actual Data
                                    StoreDataList = StoreDataList.Substring(4 + 2 + APDUDataLenChar);       //Removed Extracted Data
                                }
                                else
                                {
                                    //Error
                                    return false;
                                }
                            }
                            //Adding APDU in list.
                            TLVDatas.Add(APDUData);
                            APDUData = null;
                        }

                        //Start Personalization or sending APDU commands

                        //Authentication


                        Authentication(AID);
                        if (!Auth)
                            return Auth;
                        string Data = null, TLVData = null;
                        int Counter = 0;
                        bool bLastCommand = false;
                        for (int i = 0; i < TLVDatas.Count; i++)
                        {
                            IsEncrypted = false;
                            if (i == TLVDatas.Count-1)
                                bLastCommand = true;
                            TLVData = TLVDatas[i];
                            Data = TLVData.Substring(6);
                            if (TLVData.StartsWith("82") || TLVData.StartsWith("83"))
                            {
                                //Encrypted Data
                                Data += "80";                             //80 Padding required for 8201-8205 or 8301-8305 Data for encryption.
                                int ZeroPaddLen = 16 - (Data.Length % 16);                      // No of Zero Padding in Data after 80.
                                Data = Data.PadRight((Data.Length + ZeroPaddLen), '0');         //0 Padding to make it 64 bit length
                                Data = tDesEncrypt(SKUdek, Data, "ECB");                      // Send same command by Service
                                TLVData = TLVData.Substring(0, 4) + (Data.Length/2).ToString("X02") + Data;        //DGI + LEN + Data
                                TLVDatas[i] = TLVData;
                                IsEncrypted = true;
                            }
                            else if (TLVData.StartsWith("8000"))
                            {
                                //Encrypted Data
                                if (Data.Length % 32 == 0)
                                {
                                    string udkDec = Data.Substring(0, 32);
                                    udkDec = tDesEncrypt(SKUdek, udkDec, "ECB");
                                    string encudkDec = Data.Substring(32, 32);
                                    encudkDec = tDesEncrypt(SKUdek, encudkDec, "ECB");
                                    string macudkkDec = Data.Substring(64, 32);
                                    macudkkDec = tDesEncrypt(SKUdek, macudkkDec, "ECB");
                                    Data = udkDec + encudkDec + macudkkDec;
                                    TLVData = TLVData.Substring(0, 4) + (Data.Length / 2).ToString("X02") + Data;        //DGI + LEN + Data
                                    TLVDatas[i] = TLVData;
                                }
                                else
                                {
                                    //Error
                                    return false;
                                }
                                IsEncrypted = true;
                            }
                            else if (TLVData.StartsWith("8010"))
                            {
                                //Encrypted Data
                                IsEncrypted = true;
                            }
                            else if ((TLVData.Substring(0, 4) == "A006") || (TLVData.Substring(0, 4) == "A016"))
                            {
                                Data = tDesEncrypt(SKUdek, Data, "ECB");
                                TLVData = TLVData.Substring(0, 4) + (Data.Length / 2).ToString("X02") + Data;             //DGI + LEN + Data
                                IsEncrypted = true;
                            }
                            TLVDatas[i] = TLVData;
                            if (!StoreDataAll(TLVData, IsEncrypted, true, bLastCommand, false))
                            {
                                return false;
                            }
                        }
                        return true;
                    }
                    else
                    {
                        //Error
                        return false;
                    }
                }
                else
                {
                    //Error
                    return false;
                }
            }
            catch (Exception ex)
            {
                //Exception
                return false;
            }
        }
        public bool StoreDataAll(string DFData, bool IsEncrypted, bool UseSequence, bool bLastCommand, bool bSecure)
        {
            Counter++;
            string[] lpCommand = new string[5];
            string s1 = string.Empty;
            string s2 = string.Empty;
            int dataLength = 0;
            string response = string.Empty;
            try
            {
                if (IsEncrypted)
                {
                    if (bSecure)
                    {
                        lpCommand[0] = "84";
                    }
                    else
                    {
                        lpCommand[0] = "80";
                    }
                    lpCommand[2] = "60";
                }
                else
                {
                    if (bSecure)
                    {
                        lpCommand[0] = "84";
                    }
                    else
                    {
                        lpCommand[0] = "80";
                    }
                    lpCommand[2] = "00";
                }
                lpCommand[1] = "E2";
                lpCommand[3] = "00";
                if (bLastCommand)
                    lpCommand[2] = ((byte.Parse(lpCommand[2], NumberStyles.AllowHexSpecifier)) + 0x80).ToString("X");//Last command if is encrypted or not.
                if (UseSequence)
                    lpCommand[3] = Counter.ToString("X02");
                // Set command length +3 for DGI and its length
                dataLength = DFData.Length / 2;
                s1 = string.Empty;
                s2 = string.Empty;
                if (dataLength < 255)
                {
                    s1 = DFData;
                }
                else
                {
                    if (DFData.Substring(4, 2) == "82")
                    {
                        DFData = DFData.Substring(0, 4) + "FF" + DFData.Substring(6);
                    }
                    s1 = DFData.Substring(0, 510);
                    s2 = DFData.Substring(510, DFData.Length - 510);
                }



                //Length = (s1.Length / 2) < 17 ? "0" + (s1.Length / 2).ToString("X") : (s1.Length / 2).ToString("X");
                lpCommand[4] = (s1.Length / 2).ToString("X02");
                apduResp = ProcessCommand(lpCommand[0], lpCommand[1], lpCommand[2], lpCommand[3], s1, lpCommand[4]);
                if (apduResp.SW1 == 0x90 && apduResp.SW2 == 0x00 && s2.Length > 0)
                {
                    Counter++;
                    //lpCommand[3] = hexCounter.ToString("X02");
                    lpCommand[3] = Counter.ToString("X02");
                    lpCommand[4] = (s2.Length / 2).ToString("X02");
                    apduResp = ProcessCommand(lpCommand[0], lpCommand[1], lpCommand[2], lpCommand[3], s2, lpCommand[4]);
                }
            }
            catch (Exception ex)
            {
                response = ex.Message;
                return false;
            }
            return true;
        }

        public bool InstallCommand(string CommandData)
        {
            bool res = false;
            try
            {
                m_apduLogString += String.Format("{0} | ===========================================================================\n", System.DateTime.Now);
                m_apduLogString += String.Format("{0} | Install Command Called for Data [{1}]\n", System.DateTime.Now, CommandData);
                apduResp = ProcessCommand("80", "E6", "0C", "00", CommandData, (CommandData.Length / 2).ToString("X02"));
                if (apduResp.SW1 == 0x61)
                {
                    if (apduResp.Data != null)
                    {
                        StringBuilder sDataOut = new StringBuilder(apduResp.Data.Length * 2);
                        for (int nI = 0; nI < apduResp.Data.Length; nI++)
                            sDataOut.AppendFormat("{0:X02}", apduResp.Data[nI]);
                    }
                    apduResp = ProcessCommand("00", "C0", "00", "00", "", apduResp.SW2.ToString("X02"));
                    if (apduResp.SW1 == 0x90 && apduResp.SW2 == 0x00)
                    {
                        if (apduResp.Data != null)
                        {
                            StringBuilder sDataOut = new StringBuilder(apduResp.Data.Length * 2);
                            for (int nI = 0; nI < apduResp.Data.Length; nI++)
                                sDataOut.AppendFormat("{0:X02}", apduResp.Data[nI]);
                        }
                        return true;
                    }
                    else
                    {
                        if (apduResp.SW1 != 0x90 && apduResp.SW2 != 0x00)
                        {
                            //Error
                            m_apduLogString += String.Format("{0} | Error to send apdu command[{1}]\n", System.DateTime.Now, CommandData);
                            return false;
                        }
                    }
                }
                else
                {
                    return false;
                }
            }
            catch (Exception ex)
            {
                //response = ex.Message;
                m_apduLogString += String.Format("{0} | Error to send apdu command[{1}]\n", System.DateTime.Now, CommandData);
                m_apduLogString += String.Format("{0} | Error to send apdu command[{1}]\n", System.DateTime.Now, ex.ToString());
                return false;
            }
            return res;
        }

        public bool DeleteCommand(string CommandData)
        {
            try
            {
                m_apduLogString += String.Format("{0} | ===========================================================================\n", System.DateTime.Now);
                m_apduLogString += String.Format("{0} | Delete Command Called for Data [{1}]\n", System.DateTime.Now, CommandData);
                apduResp = ProcessCommand("80", "E4", "00", "00", CommandData, (CommandData.Length/2).ToString("X02"));
                if (apduResp.SW1 == 0x61)
                {
                    if (apduResp.Data != null)
                    {
                        StringBuilder sDataOut = new StringBuilder(apduResp.Data.Length * 2);
                        for (int nI = 0; nI < apduResp.Data.Length; nI++)
                            sDataOut.AppendFormat("{0:X02}", apduResp.Data[nI]);
                    }
                    apduResp = ProcessCommand("00", "C0", "00", "00", "", apduResp.SW2.ToString("X02"));
                    if (apduResp.SW1 == 0x90 && apduResp.SW2 == 0x00)
                    {
                        if (apduResp.Data != null)
                        {
                            StringBuilder sDataOut = new StringBuilder(apduResp.Data.Length * 2);
                            for (int nI = 0; nI < apduResp.Data.Length; nI++)
                                sDataOut.AppendFormat("{0:X02}", apduResp.Data[nI]);
                        }
                    }
                }
                if (apduResp.SW1 != 0x90 && apduResp.SW2 != 0x00)
                {
                    //Error
                    return false;
                }
            }
            catch (Exception ex)
            {
                //response = ex.Message;
                return false;
            }
            return true;
        }

    }
}
