﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Serialization;

namespace SmartCardPlayer
{
    [XmlRoot(ElementName = "NODE")]
    public class NODE
    {
        [XmlAttribute(AttributeName = "Issuer")]
        public string Issuer { get; set; }
        [XmlAttribute(AttributeName = "Exponent")]
        public string Exponent { get; set; }
        [XmlAttribute(AttributeName = "Index")]
        public string Index { get; set; }
        [XmlAttribute(AttributeName = "RID")]
        public string RID { get; set; }
        [XmlAttribute(AttributeName = "Modulus")]
        public string Modulus { get; set; }
        [XmlAttribute(AttributeName = "Length")]
        public string Length { get; set; }
        [XmlAttribute(AttributeName = "SHA1")]
        public string SHA1 { get; set; }
        [XmlAttribute(AttributeName = "Environment")]
        public string Environment { get; set; }
        [XmlAttribute(AttributeName = "Expires")]
        public string Expires { get; set; }
    }

    [XmlRoot(ElementName = "CA_List")]
    public class CA_List
    {
        [XmlElement(ElementName = "NODE")]
        public List<NODE> NODE { get; set; }
    }

}