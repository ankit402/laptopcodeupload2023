﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Runtime.InteropServices;
using SDKShim;
using System.Drawing;
using System.Drawing.Printing;
using System.Windows.Forms;
using System.Data;
using System.IO;
using System.Threading;
using System.Diagnostics;
using Microsoft.Win32;
using System.Net;

namespace MagicardProLibrary
{
    public class RioPro
    {
        enum RibbonType { YMCKO = 0, KO = 1, YMCKOK = 2, Mono = 4, MonoEx = 8, HYMCKO = 128 }
        static private IntPtr hSession = IntPtr.Zero;
        static private IntPtr hDC = IntPtr.Zero;
        static private PrinterSettings ps = new PrinterSettings();
        static private PrintDialog pd = new PrintDialog();
        static private Graphics g;
       // public CustomTraceListener objCustomTracetLogging;
        private bool bChip = false;
        private bool bMag = false;
        private bool bPrint = false;
        LogClass Log = new LogClass();
       
        string Connection_Mode;
        SDK.MagData MagData = new SDK.MagData();
        string Printer_IP;
        int rc = 0;
        string path = System.IO.Path.GetDirectoryName(System.Reflection.Assembly.GetEntryAssembly().Location)+ @"\RioProError.txt";
        //public RioPro()
        //{
        //    try
        //    {
        //        objCustomTracetLogging = new CustomTraceListener("Log.Logfiles\\RioPro-" + System.DateTime.Now.ToString("yyyyMMdd") + ".log");
        //        objReadConfig = new ReadConfig();
        //        if (objReadConfig.ReturnValue("PRINTER_CONNECTION_MODE", false) != null)
        //        {
        //            Connection_Mode = objReadConfig.ReturnValue("PRINTER_CONNECTION_MODE", true);
        //            if (Connection_Mode!="USB")
        //            {
        //                Printer_IP = objReadConfig.ReturnValue("PRINTER_IP", false);
        //            }
        //            else
        //            {
        //                Log.LogFile("Printer Connected Mode " + Connection_Mode);
        //            }
        //        }
        //        Log.LogFile("RioPro Object created ...");
        //    }
        //    catch (Exception ex)
        //    {
        //        Log.LogFile("Exception on creating Rio Pro Object. Exception: " + ex.ToString() + ex.StackTrace, 1);
        //    }
        //}
        //public RioPro(bool bEnableChip, bool bEnableMagstripe, bool bEnablePrinting)
        //{
        //    try
        //    {
        //        objReadConfig = new ReadConfig();
        //        if (objReadConfig.ReturnValue("PRINTER_CONNECTION_MODE", false) != null)
        //        {
        //            Connection_Mode = objReadConfig.ReturnValue("PRINTER_CONNECTION_MODE", true);
        //            if (Connection_Mode!="USB")
        //            {
        //                Printer_IP = objReadConfig.ReturnValue("PRINTER_IP", false);
        //                Log.LogFile("PrinterIP" + Printer_IP); 
        //            }
        //            else
        //            {
        //                Log.LogFile("Printer Connected Mode " + Connection_Mode);
        //            }                 
        //        }
        //        bChip = bEnableChip;
        //        bMag = bEnableMagstripe;
        //        bPrint = bEnablePrinting;
        //        Log.LogFile("Chip[" + bChip.ToString() + "]  Magstripe[" + bMag.ToString() + "]  Print[" + bPrint.ToString() + "]");
        //        Log.LogFile("RioPro Object created ...");
        //    }
        //    catch (Exception ex)
        //    {
        //        objCustomTracetLogging.WriteLine("Exception: " + ex.ToString() + ex.StackTrace);
        //    }
        //}
        #region === Open Session ===
        public bool connect()
        {
            int hSession_value = 0;
            ps = pd.PrinterSettings;
            g = ps.CreateMeasurementGraphics();
            hDC = g.GetHdc();
            SDK.Config Config = (new KeyValuePair<SDK.Config, string>(SDK.Config.Normal, "Normal").Key);
            SDK.Return SDKReturn = SDK.ID_OpenSession(hDC, out hSession, Config);
            hSession_value = (int)hSession;
            if (SDKReturn != SDK.Return.Success)
            {
                SDK.ID_CloseSession(hSession);
                //connect();
                return false;
            }
            else
            {
                //Call the SDK to get the printer model
                if (SDK.ID_PrinterType(hSession) != SDK.PrinterType.Rio)
                {
                    MessageBox.Show("Use with DTC Only",
                                    "Invalid Printer",
                                    MessageBoxButtons.OK);
                    SDK.ID_CloseSession(hSession);
                    Log.LogFile("Prnter session close");
                }
                else
                {
                    Cursor.Current = Cursors.WaitCursor;
                    if (PrinterIsReady())
                    {
                        if (SDK.ID_PrinterType(hSession) == SDK.PrinterType.RioPro360)
                        {
                            SDK.PrinterInfo PrinterInfo = new SDK.PrinterInfo();
                            SDKReturn = SDK.ID_PrinterInfo(hSession, PrinterInfo);
                            if (SDKReturn != SDK.Return.Success)
                            {
                                SDK.ID_CloseSession(hSession);
                                Log.LogFile("Printer Session closed try to initialization");
                                GetPrinterConnectiontype();
                                Log.LogFile("Getprtinterconnectiontype");
                                return false;
                            }
                            else
                            {
                                Log.LogFile("Open - GetPrinterInfo [" + SDKReturn + "]");
                                GetPrinterConnectiontype();
                                Log.LogFile("PrinterConnected : [" + PrinterInfo.bPrinterConnected + "]Model No. [" + PrinterInfo.eModel + "] Model: [" + PrinterInfo.sModel + "] PrinterSerial: [" + PrinterInfo.sPrinterSerial + "] PrintheadSerial: [" + PrinterInfo.sPrintheadSerial + "] PCBSerial: [" + PrinterInfo.sPCBSerial + "] FirmwareVersion: [" + PrinterInfo.Firmware.Version + "]");
                            }
                        }
                    }
                    else
                    {

                        MessageBox.Show("Printer not Found or unable to run","",
                                        MessageBoxButtons.OK);
                        return false;
                    }
                }
                //Application.DoEvents();                
            }
            return true;
        }
        public int connect_ptr()
        {
            int hSession_value = 0;
            hSession = IntPtr.Zero;
            ps = pd.PrinterSettings;
            g = ps.CreateMeasurementGraphics();
            hDC = g.GetHdc();
            //((KeyValuePair<SDK.Config, string>)SessionConfigBox.SelectedItem).Key;
            SDK.Config Config = (new KeyValuePair<SDK.Config, string>(SDK.Config.Normal, "Normal").Key);
            SDK.Return SDKReturn = SDK.ID_OpenSession(hDC, out hSession, Config);
            hSession_value = (int)hSession;
            if (SDKReturn != SDK.Return.Success)
            {
                // HandleError("OpenSession", SDKReturn);
                SDK.ID_CloseSession(hSession);
                connect_ptr();
                Log.LogFile("OpenSession" + SDKReturn);
            }
            else
            {
                //Call the SDK to get the printer model
                if (SDK.ID_PrinterType(hSession) != SDK.PrinterType.RioPro360)
                {
                    MessageBox.Show("Use with DTC Only",
                                    "Invalid Printer",
                                    MessageBoxButtons.OK);
                    SDK.ID_CloseSession(hSession);
                }
                else
                {
                    Cursor.Current = Cursors.WaitCursor;
                    if (PrinterIsReady())
                    {
                        if (SDK.ID_PrinterType(hSession) == SDK.PrinterType.RioPro360)
                        {
                            SDK.PrinterInfo PrinterInfo = new SDK.PrinterInfo();
                            SDKReturn = SDK.ID_PrinterInfo(hSession, PrinterInfo);
                            if (SDKReturn != SDK.Return.Success)
                            {
                                // HandleError("Open - GetPrinterInfo", SDKReturn);
                                Log.LogFile("Open - GetPrinterInfo [" + SDKReturn + "]");
                                Log.LogFile("PrinterConnected : [" + PrinterInfo.bPrinterConnected + "]Model No. [" + PrinterInfo.eModel + "] Model: [" + PrinterInfo.sModel + "] PrinterSerial: [" + PrinterInfo.sPrinterSerial + "] PrintheadSerial: [" + PrinterInfo.sPrintheadSerial + "] PCBSerial: [" + PrinterInfo.sPCBSerial + "] FirmwareVersion: [" + PrinterInfo.Firmware.Version + "]");
                            }
                            else
                            {
                                Log.LogFile("[Open - GetPrinterInfo]" + SDKReturn);
                                Log.LogFile("PrinterConnected : [" + PrinterInfo.bPrinterConnected + "]Model No. [" + PrinterInfo.eModel + "] Model: [" + PrinterInfo.sModel + "] PrinterSerial: [" + PrinterInfo.sPrinterSerial + "] PrintheadSerial: [" + PrinterInfo.sPrintheadSerial + "] PCBSerial: [" + PrinterInfo.sPCBSerial + "] FirmwareVersion: [" + PrinterInfo.Firmware.Version + "]");
                            }
                        }
                    }
                }
            }
            if (hSession_value != 0)
            {
                return hSession_value;
            }
            else
            {
                return 0;
            }
        }
        private bool PrinterIsReady()
        {
            return (SDK.ID_PrinterStatus(hSession) == SDK.PrinterStatus.Ready);
            Log.LogFile("Printer Ready");
        }

        public bool Reset()
        {
            bool connect_return = connect();
            if (connect_return == true)  // connection check
            {
                bool prt_status = Status();
                if (prt_status == true)  // printer status check
                {
                    SDK.Return SDKReturn = SDK.ID_RestartPrinter(hSession);
                    //Thread.Sleep(22000);
                    WaitForPrinterToFinish();
                    Log.LogFile("Printer Reset Successfully");
                    return prt_status;
                }
                else
                {
                    bool clrrep = ClearResponse();
                    if (clrrep)
                    {
                      Log.LogFile("clrreponse Sucess");
                      return prt_status;
                    }
                    else
                    {
                        Log.LogFile("clrreponse Failed");
                        return prt_status;
                    }
                    return prt_status;  
                }
            }
            else
            {
                Log.LogFile("Printer connection not found");
                hSession = IntPtr.Zero;
                return connect_return;
            }
        }

        public bool ClearResponse()
        {
            SDK.Return SDKReturn = SDK.ID_CleanPrinter(hSession);
            if (SDKReturn != SDK.Return.Success)
            {
                HandleError("CleanPrinter", SDKReturn);
                return false;
            }
            else
            {
                WaitForPrinterToFinish();
                return true;
            }
        }

        public bool EjectCard()
        {
            SDK.Return SDKReturn = SDK.ID_EjectCard(hSession);
            if (SDKReturn != SDK.Return.Success)
            {
                Log.LogFile("Card Ejected failed [" + SDKReturn + "]");
                return false;
            }
            else
            {
                WaitForPrinterToFinish();
                bool prt_status = Status();
                if (prt_status == true)
                {
                    Log.LogFile("Card Eject Success");
                    return true;
                }
                else
                {

                    return false;
                }
            }
        }

        public bool Status()
        {
            string msg;
            switch (SDK.ID_PrinterStatus(hSession))
            {
                case SDK.PrinterStatus.Ready: msg = "Printer is READY"; break;
                case SDK.PrinterStatus.Offline: msg = "Printer is OFFLINE"; break;
                case SDK.PrinterStatus.Error: msg = "Printer is in ERROR"; break;
                case SDK.PrinterStatus.Busy: msg = "Printer is in Busy"; break;
                default: msg = "Unknown Printer Status"; break;
            }
            if (msg == "Printer is READY")
            {
                return true;
            }
            else
            {
                return false;
            }
        }

        #endregion
        public int PersonalizeChip(DataSet dsPrintingData, ref string sMsg)
        {
            DialogResult dr;
            sMsg = string.Empty;
            int iRet = 0;
            int i = 0;
            int pStatus = 0;
            Log.LogFile("Moving card to Chip Module...");
            if (bChip)
            {
                Log.LogFile("Preparing Chip Data ...");
                Log.LogFile("Personalizing Chip...");
                string CardNumber = string.Empty;
                int iChipWaitTime = 0;
                while (dsPrintingData.Tables[0].Rows.Count != i)
                {
                    if (dsPrintingData.Tables[0].Rows[i]["FIELDNAME"].ToString().ToUpper() == "CARD NUMBER")
                    {
                        CardNumber = dsPrintingData.Tables[0].Rows[i]["VALUE"].ToString();
                        Log.LogFile("CardNumber[" + CardNumber.Substring(0, 7) + "** **** " + CardNumber.Substring(15, 4) + "]", 1);
                        if (CardNumber == "")
                        {
                            sMsg = "Card Number Empty";
                            return 0x99;
                        }
                        iChipWaitTime = (int)dsPrintingData.Tables[0].Rows[i]["ChipWaitTime"];
                        break;
                    }
                    i++;
                }
                string check_sf = "Smart Factory running and Socket Listening";
                if (check_sf == "Smart Factory running and Socket Listening")
                {
                    string GetRowChip = "C:\\Program Files\\OMA Emirates\\NanoPerso\\EmbossingDLLs\\CHIP\\Row.chp";
                    string RowChip = "C:\\Program Files\\OMA Emirates\\NanoPerso\\EmbossingDLLs\\Row.chp";
                    File.Copy(GetRowChip, RowChip, true);
                    StreamReader srFile = new StreamReader(RowChip);
                    string sline = srFile.ReadLine();
                    srFile.Close();
                    string oldCardnumber = sline.Substring(12, 16);
                    sline = sline.Replace(oldCardnumber, CardNumber.Replace(" ", ""));
                    sline = sline.Replace("No Error", "NotPerso");
                    StreamWriter swFile = new StreamWriter(RowChip);
                    swFile.Write(sline);
                    swFile.Flush();
                    swFile.Close();
                    Log.LogFile("Calling ChipManager.exe");
                    Process.Start("C:\\Program Files\\OMA Emirates\\NanoPerso\\EmbossingDLLs\\ChipManager.exe", "\"" + RowChip);
                    int iCycleCount = 0;
                    bool chip = false;
                    Thread.Sleep(iChipWaitTime);
                    srFile = new StreamReader(RowChip);
                    sline = srFile.ReadLine();
                    srFile.Close();
                    while (iChipWaitTime >= iCycleCount)
                    {
                        srFile = new StreamReader(RowChip);
                        sline = srFile.ReadLine();
                        srFile.Close();
                        if (sline.IndexOf("NotPerso") == 3)
                        {
                            //Chip Not Perso
                            //Loop Continue after 3 Sec
                            if ((iChipWaitTime - iCycleCount) >= 3000)
                            {
                                iCycleCount = iCycleCount + 3000;
                                Thread.Sleep(3000);
                            }
                            //Time Out
                            else if ((iChipWaitTime - iCycleCount) == 0)
                                break;
                            //Time left less then 3 Sec, Loop Continue after left Sec.
                            else
                            {
                                iCycleCount = iCycleCount + (iChipWaitTime - iCycleCount);
                                Thread.Sleep(iChipWaitTime - iCycleCount);
                            }
                        }
                        else if (sline.IndexOf("No Error") == 3)
                        {
                            //sucess
                            chip = true;
                            sMsg = "Successful :" + sline.Substring(3, 8);
                            Log.LogFile("Chip Personalization [Successfull]");
                            return 0;
                        }
                        else
                        {
                            //Chip Failed
                            sMsg = "Failed : " + sline.Substring(3, 8);
                            Log.LogFile("sMsg " + sMsg);
                            break;
                        }
                    }
                    if (!chip && sMsg == "")
                    {
                        sMsg = "Failed : Time out";
                        Log.LogFile("sMsg" + sMsg, 1);
                        return -1;
                    }
                }
                else
                {
                    sMsg = "Unable to connect Smart Factory";
                    return -1;
                }
            }
            return 0;
        }

        private void HandleError(string action, SDK.Return result)
        {
            string error;
            switch (result)
            {
                case SDK.Return.Timeout: error = "ID_TIMEOUT"; break;
                case SDK.Return.Error: error = "ID_ERROR"; break;
                case SDK.Return.PrinterError: error = "ID_PRINTER_ERROR"; break;
                case SDK.Return.DriverNotCompliant: error = "ID_DRIVER_NOTCOMPLIANT"; break;
                case SDK.Return.OpenPrinterError: error = "ID_OPENPRINTER_ERROR"; break;
                case SDK.Return.RemoteCommError: error = "ID_REMOTECOMM_ERROR"; break;
                case SDK.Return.LocalCommError: error = "ID_LOCALCOMM_ERROR"; break;
                case SDK.Return.SpoolerNotEmpty: error = "ID_SPOOLER_NOT_EMPTY"; break;
                case SDK.Return.RemoteCommInUse: error = "ID_REMOTECOMM_IN_USE"; break;
                case SDK.Return.LocalCommInUse: error = "ID_LOCALCOMM_IN_USE"; break;
                case SDK.Return.ParamError: error = "ID_PARAM_ERROR"; break;
                case SDK.Return.InvalidSession: error = "ID_INVALID_SESSION"; break;
                default: error = "Unknown API Error - " + result; break;
            }
            MessageBox.Show(action + ": " + error);
        }
        public bool Flip_Card()
        {
            bool result = false;
            SDK.Return SDKReturn = SDK.ID_FlipCard(hSession);
            if (SDKReturn != SDK.Return.Success)
            {
                //HandleError("FlipCard", SDKReturn);
                Log.LogFile("Card flip Failed " + SDKReturn);
            }
            else
            {
                WaitForPrinterToFinish();
                Log.LogFile("Card flip Successfully");
            }
            return true;
        }
        public string LogErrorandMsg(string Msg)
        {
            string prtMsg = "";
            try
            {
                if (!File.Exists(@"Log.Logfiles\RioProError.txt"))
                {
                    File.CreateText(@"Log.Logfiles\RioProError.txt");
                }
                prtMsg = File.ReadAllText(@"Log.Logfiles\RioProError.txt");
                prtMsg = Msg;
            }
            catch (Exception ex)
            {
                prtMsg = "Unable to get response from Printer. Cause:" + ex.ToString();
            }

            return prtMsg;
        }
        public bool Feed_Card()
        {
            //open session          
            // feed mode  for contactcard --> ChipCard
            SDK.FeedMode mode = (new KeyValuePair<SDK.FeedMode, string>(SDK.FeedMode.ChipCard, "ChipCard").Key);
            //hSession = (IntPtr)hSession_val;
            // feed card
            SDK.Return SDKReturn = SDK.ID_FeedCard(hSession, mode, 0);
            if (SDKReturn != SDK.Return.Success)
            {
                Log.LogFile("Card feed Failed ");
                return false;
            }
            else
            {
                if (!WaitForPrinterToFinish())
                {
                    Log.LogFile("Card feed Failed ");
                    return false;
                }
                else
                {
                    return true;
                }
            }
        }
        public int PrintCard(DataSet dsPrintingData, DataSet dsMagData, ref string sMsg, ref bool MagDone, ref bool PrintDone)
        {
            int rc = 0;
            int FileCount = 0;
            IntPtr FrontDC, BackDC, FrontResinDC, BackResinDC;
            SDK.Return SDKReturn;
            SDK.TextDef TextDefn = new SDK.TextDef();
            #region Encoding
            if (bMag)
            {
                Log.LogFile("Preparing Encoding Data...");
                SDK.EjectMode ejectmode = (new KeyValuePair<SDK.EjectMode, string>(SDK.EjectMode.Off, "Off").Key);
                SDK.Return ejectSDKReturn = SDK.ID_EjectMode(hSession, SDK.Action.Write, ref ejectmode);
                bool Coercitivity = (dsMagData.Tables[0].Rows[0]["COERCIVITY"].ToString() == "High" ? true : false);
                Log.LogFile("Coercitivity[" + dsMagData.Tables[0].Rows[0]["COERCIVITY"].ToString() + "-" + Coercitivity.ToString() + "]");
                string track1 = dsMagData.Tables[0].Rows[0]["TRACK1"].ToString();
                //rc = EncodeMagstripe(0, track1);  // Rio Pro [0] track1 [1] Track2 [2] Track3  
                //// sMsg =   Log.LogFile("Printing Track 1");
                //if (rc != 0)
                //{
                //    sMsg = "Error at track1 encoding\nMagstrip of card or MagData or Mag Encoder Head issue.\n\nPlease check the logs for exact error.";
                //    return rc;
                //}
                string track2 = dsMagData.Tables[0].Rows[0]["TRACK2"].ToString();
                rc = EncodeMagstripe(1, track2);
                // sMsg = Log.LogfileErrorandMsg("Printing Track 2");
                if (rc != 0)
                {
                    sMsg = "Error at track2 encoding\nMagstrip of card or MagData or Mag Encoder Head issue.\n\nPlease check the logs for exact error.";
                    return rc;
                }
                bool result = MagRead();
                if (result)
                {
                    MagDone = true;
                }
                else
                {
                    MagDone = false;
                    rc = 1;
                    sMsg = "Magdone Failed";
                    sMsg = sMsg + "\nError at track1 & track2 encoding\nMagstrip of card or MagData or Mag Encoder Head issue.\n\nPlease check the logs for exact error.";
                    return rc;
                }
            }
            #endregion

            #region Printing
            if (bPrint)
            {
                Log.LogFile("Preparing Printing Data...");
				Log.LogFile("Printing Data Count ["+ dsPrintingData.Tables[0].Rows.Count+"]");
				SDK.PrintSetting PrintSettings = new SDK.PrintSetting();
                SDK.PrintSetting OldPrintSettings = new SDK.PrintSetting();
                SDKReturn = SDK.ID_CanvasInit(hSession, out FrontDC, SDK.Canvas.Front);
                foreach (DataRow drField in dsPrintingData.Tables[0].Rows)
                {
					Log.LogFile("Printing Data Count [" + drField["SIDE"].ToString().Trim() + "]");
					if (drField["SIDE"].ToString().Trim() == "Rear" || drField["SIDE"].ToString().Trim() == "1")//CardBack Check
                    {
                        SDK.CardSetting BackSettings = new SDK.CardSetting();
                        SDK.CardSetting OldBackSettings = new SDK.CardSetting();
                        SDKReturn = SDK.ID_CardSettings(hSession, SDK.Action.Read, SDK.Side.Back, OldBackSettings);
                        BackSettings = OldBackSettings;
                        SDKReturn = SDK.ID_CardSettings(hSession, SDK.Action.Write, SDK.Side.Back, BackSettings);
                        // Data for Printing
                        SDKReturn = SDK.ID_CanvasInit(hSession, out BackDC, SDK.Canvas.Back);
                        TextDefn.FontName = drField["Font"].ToString();
                        TextDefn.FontSize = (int)drField["size"];
                        TextDefn.FontStyle = 0;
                        TextDefn.X = (int)drField["X"];
                        TextDefn.Y = (int)drField["Y"];
                        TextDefn.Angle = 0;
                        TextDefn.Text = drField["value"].ToString();
                        Log.LogFile("Value [" + drField["value"].ToString() + "] Font [" + drField["Font"].ToString() + "] X [" + drField["X"].ToString() + "] Y [" + drField["Y"].ToString() + "] Size [" + drField["size"] + "]");
                        //Call the SDK function to draw the text on the canvas
                        SDKReturn = SDK.ID_DrawText(hSession,
                                                    false ? SDK.Canvas.BackResin : SDK.Canvas.Back,
                                                    TextDefn);
                        if (SDKReturn != SDK.Return.Success)
                        {
                            HandleError("DrawTextback", SDKReturn);
                            break;
                        }
                    }
                    // end of rear Canvas printing                   
                    if (drField["SIDE"].ToString().Trim() == "Front" || drField["SIDE"].ToString().Trim() == "0")
                    {
                        SDKReturn = SDK.ID_PrintSettings(hSession, SDK.Action.Read, OldPrintSettings);
                        if (SDKReturn != SDK.Return.Success)
                        {
                            HandleError("OldPrintSettings", SDKReturn);
                            break;
                        }
                        PrintSettings = OldPrintSettings;
                        //Determine which sides of the card need to be printed                   
                        PrintSettings.Duplex = SDK.Duplex.Both;
                        //Change the print settings for the card
                        SDKReturn = SDK.ID_PrintSettings(hSession, SDK.Action.Write, PrintSettings);
                        if (SDKReturn != SDK.Return.Success)
                        {
                            HandleError("WritePrintSettings", SDKReturn);
                            break;
                        }
                        //Change the print settings for the card
                        TextDefn.FontName = drField["Font"].ToString();
                        TextDefn.FontSize = (int)drField["size"];
                        TextDefn.FontStyle = 0;
                        TextDefn.X = (int)drField["X"];
                        TextDefn.Y = (int)drField["Y"];
                        TextDefn.Angle = 0;
                        TextDefn.Text = drField["value"].ToString();
                        //Call the SDK function to draw the text on the canvas 
                        try
                        {
                            Log.LogFile("Value [" + drField["value"].ToString() + "] Font [" + drField["Font"].ToString() + "] X [" + drField["X"].ToString() + "] Y [" + drField["Y"].ToString() + "] Size [" + drField["size"] + "]");
                        }
                        catch (Exception ex)
                        {
                            Log.LogFile(ex.ToString());
                        }
                        SDKReturn = SDK.ID_DrawText(hSession, false ? SDK.Canvas.FrontResin : SDK.Canvas.Front, TextDefn);
                        if (SDKReturn != SDK.Return.Success)
                        {
                            Log.LogFile("Unable to Draw Text for Value [" + drField["value"].ToString() + "]");
                            HandleError("DrawTextFront", SDKReturn);
                            break;
                        }
                    }
                }
            }
            #endregion
            //Print the Card
            SDKReturn = SDK.ID_PrintCard(hSession);
            if (SDKReturn != SDK.Return.Success)
            {
                PrintDone = false;
                HandleError("PrintCard", SDKReturn);
                Log.LogFile("Thermal Printing  Failed");
                //break;
            }
            else
            {
                PrintDone = true;
                Log.LogFile("Thermal Printing  Success");
            }
            if (PrintDone)// && MagDone)
            {
                sMsg = "";
                return 0;
            }
            else
            {
                sMsg = "Printing Error";
                return 1;
            }
        }
        private bool WaitForPrinterToFinish()
        {
            Cursor.Current = Cursors.WaitCursor;
            SDK.Return SDKReturn;
            do
            {
                //Repeat the wait until response is not timeout
                SDKReturn = SDK.ID_WaitForPrinter(hSession);
            } while (SDKReturn == SDK.Return.Timeout);
            if (SDKReturn != SDK.Return.Success)
            {
                Log.LogFile("Printer Response " + SDKReturn);
                return false;
            }
            else
            {
                return true;
            }
            //Cursor.Current = Cursors.Default;
        }
        public bool MagRead()
        {
            byte Tracks = 0;
            SDK.EncodingSpec EncodingSpec = (new KeyValuePair<SDK.EncodingSpec, string>(SDK.EncodingSpec.ISO, "ISO").Key);
            if (true) Tracks |= 1;
            if (true) Tracks |= 2;
            if (Tracks == 0)
            {
                return false;
            }
            SDK.Return SDKReturn;
            SDKReturn = SDK.ID_ReadMagTracks(hSession, MagData, EncodingSpec, Tracks);
            if (SDKReturn != SDK.Return.Success)
            {
                return false;
            }
            else
            {
                string track1 = MagData.tk1;
                string track2 = MagData.tk2;
                // Split string on spaces.
                // ... This will separate all the words.
                string[] track1_value = track1.Split('^');
                string[] track2_value = track2.Split('=');
                string card = string.Empty;
                string name = string.Empty;
                string extra = string.Empty;
                string card1 = string.Empty;
                string extra2 = string.Empty;
                foreach (string word in track1_value)
                {
                    card = track1_value[0].Substring(1, 7) + "** ****" + track1_value[0].Substring(13, 4) + "^";
                    name = track1_value[1].Substring(0, 8) + "** ****" + track1_value[1].Substring(16, 4) + "^";
                    extra = track1_value[2].Substring(0, 12) + "** ****" + track1_value[2].Substring(13, 4);
                }
                string t1 = card + name + extra;
                foreach (string word1 in track2_value)
                {
                    card1 = track2_value[0].Substring(0, 7) + "** ****" + track2_value[0].Substring(10, 4) + "=";
                    extra2 = track2_value[1].Substring(0, 7) + "** ****" + track2_value[1].Substring(13, 4);
                }
                Log.LogFile("Track1 Value [ " + card + name + extra + " ] Track2 Value [ " + card1 + extra2+" ]");
                Log.LogFile("(Track 1): " + (MagData.tk1_pass != 0 ? ("PASS") : "FAIL"));
                Log.LogFile("(Track 2): " + (MagData.tk2_pass != 0 ? ("PASS") : "FAIL"));
                return true;
            }
        }
        public int EncodeMagstripe(int iTrackNumber, string sTrackData)
        {
            int result = -1;
            SDK.MagDef Encode = new SDK.MagDef();
            SDK.MagText magText = new SDK.MagText();
            Encode.Verify = SDK.Verify.On; // Verify Mag_Encoding //
            Encode.Track[iTrackNumber].CharCount = decimal.ToByte(sTrackData.Length);
            Encode.Track[iTrackNumber].Data = sTrackData;
            SDK.Return SDKReturn = SDK.ID_EncodeMag(hSession, Encode);
            SDK.EncodingSpec EncodingSpec = (new KeyValuePair<SDK.EncodingSpec, string>(SDK.EncodingSpec.ISO, "ISO").Key);
            SDKReturn = SDK.ID_ReadMag(hSession, MagData, EncodingSpec);
            if (SDKReturn != SDK.Return.Success)
            {
                result = -1;
            }
            else
            {
                result = 0;
            }
            return result;
        }
        
        public void GetPrinterConnectiontype()
        {
            string msg;
            switch (SDK.ID_ConnectionType(hSession))
            {
                case SDK.ConnectionType.USB: msg = "USB"; break;
                case SDK.ConnectionType.Ethernet: msg = "Ethernet"; break;
                case SDK.ConnectionType.File: msg = "File"; break;
                default: msg = "Unknown"; break;
            }
            Log.LogFile("GetPrinterConnectiontype [" + msg + "]");
        }
    }
}

