﻿using System;
using System.Collections.Generic;

using System.Web;
using System.IO;
using System.Net;
using System.Diagnostics;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using System.Net.NetworkInformation;
using System.ComponentModel;
using System.Net.Sockets;
using System.Text;
using System.Security.Principal;
using Microsoft.Win32;

namespace MagicardProLibrary 
{      
    class LogClass
    {
        public string file_path = System.IO.Path.GetDirectoryName(System.Reflection.Assembly.GetEntryAssembly().Location);
        StreamWriter log;  
        byte[] pSerial = new byte[8];

        public void LogFile(string msg, int isDBtrue = 0)
        {
            StackTrace st = new StackTrace();
            StackFrame sf = st.GetFrame(1);
            string mtd_name = string.Format(sf.GetMethod().Name);
            string message = msg;
            string file_name = "RioPro";
            string extn = ".log";
            string logfile = file_path + "\\" + file_name + "-" + DateTime.Now.ToString("ddMMyyyy") + extn;
            writeLog(logfile, mtd_name, message, isDBtrue);
        }

        public void writeLog(string logfile, string mtd_name, string message, int isDBTrue)
        {
          
            try
            {
                if (!System.IO.Directory.Exists(file_path))
                {
                    System.IO.Directory.CreateDirectory(file_path);
                }
                if (!File.Exists(logfile))
                {
                    log = File.CreateText(logfile);
                }
                else
                {
                    log = File.AppendText(logfile);
                }
                if (isDBTrue == 1)
                    //objPrinterDAL.InsertLogRecord(DateTime.Now, getBranchID("BRANCH"), getBranchID("BRANCHNAME"), getmacAddress(), "0", mtd_name, message);
                log.WriteLine(DateTime.Now + "\t||" + getmacAddress() + "\t||" + getBranchID("BRANCH") + "\t||" + mtd_name + "\t||" + message);
                log.Close();
            }
            catch (Exception ex)
            {
                log.WriteLine(DateTime.Now + "\t||" + mtd_name + "\t|| Exception Occured in Log Writing: " + ex.Message);
                log.Close();
            }
        }

        public string getmacAddress()
        {
            NetworkInterface[] nics = NetworkInterface.GetAllNetworkInterfaces();     
            int j = 0;
            PhysicalAddress address = nics[j].GetPhysicalAddress();
            string nametext = WindowsIdentity.GetCurrent().Name;
            return nametext;
        }

        private string getBranchID(string value)
        {
            string szBranch,szBranchName,szStationId;
            const string REGKEY_MAIN = @"SOFTWARE\NanoCritiX\";
            RegistryKey regKey = Registry.LocalMachine.OpenSubKey(REGKEY_MAIN);
            string ret_value = string.Empty;
            
            if (value == "BRANCH")
            {
                szBranch = regKey.GetValue("BRANCH").ToString();
                if (szBranch == "" || szBranch == null)
                {
                    szBranch = regKey.GetValue("BRANCHID").ToString();
                }
                ret_value= szBranch;
            }
            if (value == "BRANCHNAME")
            {
                szBranchName = regKey.GetValue("BRANCHNAME").ToString();
                ret_value= szBranchName;
            }
            if (value == "STATIONID")
            {
                szStationId = regKey.GetValue("STATIONID").ToString();
                ret_value= szStationId;
            }
            return ret_value;         
        }
    }
}
