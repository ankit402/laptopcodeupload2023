﻿using System;
using System.Collections.Generic;
using System.Text;

namespace MagicardProLibrary
{
    interface iEmbossing
    {
        bool Connect();
        int connect_ptr();
        bool Reset();
        string PrintCards(string BranchID, string ProfileID);
    }
}
