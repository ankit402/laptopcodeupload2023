﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Data;
using System.Data.SqlClient;
using System.Threading;
using System.Windows.Forms;
using SDKShim;
using System.IO;

namespace MagicardProLibrary
{
    public class Embossing : iEmbossing
    {
        RioPro objPrinter;
        bool bPrinterConnected = true;
       // DAL objPrinterDAL;
        LogClass Log=new LogClass();
        LogClass log = new LogClass();
        int hSession_val = 0;
        IntPtr hSession = IntPtr.Zero;
       //CustomTraceListener objCustomTracetLogging;
        public bool Connect()
        {
            if (objPrinter == null)
            {
                objPrinter = new RioPro();
            }
            return objPrinter.connect();
        }
        public int connect_ptr()
        {
            if (objPrinter == null)
            {
                objPrinter = new RioPro(); 
            }
            return objPrinter.connect_ptr();
        }
        public bool Reset()
        {
            if (objPrinter == null)
            {
                objPrinter = new RioPro(); 
            }
            return objPrinter.Reset();
        }
        public bool Reset(string profileID)  
        {
            if (objPrinter == null)
            {
                objPrinter = new RioPro();
            }
            return objPrinter.Reset();
        }
        public bool EjectCard()
        {
            if (objPrinter == null)
            {
                objPrinter = new RioPro();
            }
            return objPrinter.EjectCard();
        }
        public bool Status()
        {
            if (objPrinter == null)
            {
                objPrinter = new RioPro();
            }
            return objPrinter.Status();
        }
        public bool FeedCard()
        {
            if (objPrinter == null)
            {
                objPrinter = new RioPro();
            }
            return objPrinter.Feed_Card();
        }
        public string PrintCards(string BranchID, string ProfileID)
        {
            string[] line = null;
            string sMsg = string.Empty;
            bool statusvalue = Status();
           if (statusvalue==false)
           {
                  connect_ptr();
                  //sMsg = "Error: Printer isn't connected & connection status failed.";
                  //return sMsg;          
           }
            Log.LogFile("Print Cards Called for Branch[" + BranchID + "] Print ID ["+""+"] and ProfileID[" + ProfileID + "]");      
            //objPrinterDAL = new DAL();
            try
            {
                Log.LogFile("Calling GetPrintingProfileDetails for ProfileID[" + ProfileID + "]", 0);
               // DataSet dsPrintingProfileDetails = objPrinterDAL.GetPrintingProfileDetails(ProfileID);
                Log.LogFile("Calling GetPrintingRecords for Branch[" + BranchID + "] and Profile ID[" + ProfileID + "] Print ID ["+""+"]", 0);
               // DataSet dsPrintingRecords = objPrinterDAL.GetPrintingRecords(BranchID, ProfileID);
                DataSet dsPrintingRecordData = new DataSet();
                DataSet dsEncodingData = new DataSet();
               /// bool bEnablechip = (bool)dsPrintingProfileDetails.Tables[0].Rows[0]["Chip"];
               // bool bEnableMag = (bool)dsPrintingProfileDetails.Tables[0].Rows[0]["Mag"];
               // bool bEnablePrint = (bool)dsPrintingProfileDetails.Tables[0].Rows[0]["Print"];
                bool bChipDone = false;
                bool bMagDone = false;
                bool bPrintDone = false;
                int iCylceCount = 0;
                int iWaitCylces = 0;
                bool bSmarFactoryWorkCompleted = false;
                //if (bEnablechip)
                //{
                //   // iWaitCylces = (int)dsPrintingProfileDetails.Tables[0].Rows[0]["ChipWait"];
                //}
                //objPrinter = new RioPro(bEnablechip, bEnableMag, bEnablePrint);
                //if (!objPrinter.connect())
                //{
                //    Log.LogFile("Printer Not Connected");

                //    //if (objPrinterDAL.ReadErrorMsg("Printer Not Connected") == "")
                //    //    return "Printer Not Connected";
                //    //else
                //    //    return objPrinterDAL.ReadErrorMsg("Printer Not Connected");
                //}
                if (objPrinter.connect())//if bPrinterConnected is true
                {
                    // objPrinter.Feed_Card();  // condition for feed card here     
                    if (!objPrinter.Feed_Card())
                    {
						Log.LogFile("Feedcard Failed");
						//return objPrinterDAL.ReadErrorMsg("Feedcard Failed");
                        
                    }
                    else if(objPrinter.Feed_Card())
                    {
                       // Log.LogFile("Total Lines to be Printed [" + dsPrintingRecords.Tables[0].Rows.Count + "]");
        //                if (dsPrintingRecords.Tables[0].Rows.Count > 0)
        //                {
        //                    foreach (DataRow drPrintingRecord in dsPrintingRecords.Tables[0].Rows)
        //                    {
        //                        bSmarFactoryWorkCompleted = false;
        //                       // dsPrintingRecordData = objPrinterDAL.GetPrintingRecordData(drPrintingRecord["ProfileID"].ToString(), drPrintingRecord[""""].ToString());
        //                        //Log.LogFile("ProfileID : " + drPrintingRecord[""""].ToString() + """ : " + drPrintingRecord["ProfileID"].ToString());
        //                        if (bEnableMag)
								//{
								//	//dsEncodingData = objPrinterDAL.GetEncodingRecordData(drPrintingRecord["ProfileID"].ToString(), drPrintingRecord[""""].ToString());

								//}
                                  
        //                        int boolReply = 0x00;
        //                        if (bEnablechip)
        //                        {
        //                            boolReply = objPrinter.PersonalizeChip(dsPrintingRecordData, ref  sMsg);
        //                            Log.LogFile("Reply from PersonalizeChip[" + boolReply + "] and sMsg[" + sMsg + "]");
        //                            if (boolReply == -123)
        //                            {
        //                                Log.LogFile("No Card Inside the printer.Please insert the card");
        //                                //    Log.LogFile(sMsg);
        //                                if (objPrinterDAL.ReadErrorMsg("No Card in the Feeder") == "")
        //                                    return sMsg;
        //                                else
        //                                    return objPrinterDAL.ReadErrorMsg("No Card in the Feeder");
        //                            }
        //                            else
        //                            {
        //                                while (iWaitCylces >= iCylceCount)
        //                                {
        //                                    if (true)
        //                                    {
        //                                        bSmarFactoryWorkCompleted = true;
        //                                        bChipDone = true;
        //                                        break;
        //                                    }
        //                                    iCylceCount = iCylceCount + 1000;
        //                                    Log.LogFile("Going to sleep for 1 Sec");
        //                                    Thread.Sleep(1000);
        //                                }
        //                            }
        //                            //Log.LogFile("Check For Chip : " + iCylceCount.ToString() + " and Chip Status : " + objPrinterDAL.ReadChipStatus(drPrintingRecord[""""].ToString()));
								//	if (true)
								//	{
								//		bSmarFactoryWorkCompleted = true;
								//		bChipDone = true;
								//		break;
								//	}
								//	Log.LogFile("Exit from While Loop");
        //                            if (!bSmarFactoryWorkCompleted)
        //                            {
        //                                objPrinter.EjectCard();
        //                                //Log.LogFile("" CycleCount[" + iCylceCount.ToString() + "]");
        //                                if (boolReply == 0)
        //                                    boolReply = 0x99;
        //                            }
        //                        }
        //                        else
        //                            boolReply = 0x00;
        //                        if (boolReply == 0)
        //                        {
								//	Log.LogFile("Print Card called with Encoding Data["+dsEncodingData.Tables[0].Rows.Count+"] Printing Data["+dsPrintingRecordData.Tables[0].Rows.Count+"]" );
								//	boolReply = objPrinter.PrintCard(dsPrintingRecordData, dsEncodingData, ref sMsg, ref bMagDone, ref bPrintDone);
        //                            Log.LogFile("Print Card Reply[" + boolReply + "]");
        //                        }
        //                        else
        //                        {
        //                            if (File.Exists(@"C:\Program Files\OMA Emirates\NanoPerso\Smart Factory\" +
        //                                                DateTime.Today.Date.ToString("ddMM") + "\\SmartFactoryLastError.Log"))
        //                            {
        //                                line =
        //                                    System.IO.File.ReadAllLines(
        //                                        @"C:\Program Files\OMA Emirates\NanoPerso\Smart Factory\" +
        //                                        DateTime.Today.Date.ToString("ddMM") + "\\SmartFactoryLastError.Log");
        //                                foreach (var str in line)
        //                                {
        //                                    if (str.StartsWith("Message : "))
        //                                        sMsg = "Printing failed : " +
        //                                               str.Replace("Message : ", "Chip personalization failed, ") + "\n";
        //                                    else if (str.StartsWith("Detail : "))
        //                                        sMsg = sMsg + str.Replace("Detail : ", "") + "\n";
        //                                    else if (str.StartsWith("Recommendation : "))
        //                                        sMsg = sMsg + str.Replace("Recommendation : ", "") + "\n";
        //                                }
        //                            }
        //                            else
        //                                sMsg = "Chip personalization Failed\nTimeOut occurred during personalization.\nPlease Contact with OMA S/W Support or Check Smart factory Log";
        //                        }
        //                        if (boolReply == 0)
        //                        {
        //                           // Log.LogFile("Print ID[" + drPrintingRecord[""""].ToString() + "] Bool Reply[" + boolReply.ToString() + "] sMsg[" + sMsg + "] Chip[" + bChipDone + "] Mag[" + bMagDone + "] Print[" + bPrintDone + "]");
        //                           // objPrinterDAL.UpdatePrintRecord(drPrintingRecord[""""].ToString(), boolReply.ToString(), sMsg, bChipDone, bMagDone, bPrintDone);
        //                            //Log.LogFile("Print record Updated");

        //                            if (!objPrinter.EjectCard())
        //                            {
        //                                objPrinter.Reset();
        //                                Log.LogFile("Card Not Ejected Successfully");
        //                                Log.LogFile("***********************************Printed Successfully but Failed to Eject***********************************");
        //                            }
        //                            else
        //                            {
        //                                Log.LogFile("Calling Eject Method");
        //                               // objPrinter.EjectCard();
        //                                Log.LogFile("Card Ejected Successfully");
        //                                // 
        //                                Log.LogFile("***********************************Printed Successfully***********************************");
        //                            }
        //                        }
        //                        else
        //                        {
        //                            Log.LogFile("Printing failed:" + sMsg);
        //                            Log.LogFile("***********************************Printing Failed***********************************");
        //                            objPrinter.EjectCard();
        //                            //if (objPrinterDAL.ReadErrorMsg(sMsg) == "")
        //                            //    return sMsg;
        //                            //else
        //                            //    return objPrinterDAL.ReadErrorMsg(sMsg);
        //                        }
        //                    }
        //                }
        //                else
        //                {
        //                    sMsg = "Error: No Records found for Printing.\n\nPlease Check the Records and try to print again.";
        //                    Log.LogFile(sMsg);
        //                    return sMsg;
        //                }
                    }
                }
                else
                {
                    return "Error: Printer Not Connected";
                }
                Log.LogFile("Printing Success");
                sMsg = "Printing Success";   // return resoponse for printing 
                return sMsg;
            }
            catch (Exception ex)
            {
               Log.LogFile("Message: " + sMsg + "- Exception: " + ex.ToString());
                return sMsg;
            }
        }
    }
}
