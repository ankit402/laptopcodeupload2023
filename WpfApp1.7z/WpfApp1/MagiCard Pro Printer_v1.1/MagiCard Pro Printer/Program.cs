﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data.SqlClient;
using System.Windows.Forms;

namespace MagiCard_Pro_Printer
{
    static class Program
    {
        /// <summary>
        /// The main entry point for the application.
        /// </summary>
        [STAThread]
        static void Main()
        {
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            Application.Run(new Form1());
        }
    }
	class DBConnection
	{
		public static SqlConnection getConnection()
		{
			//string DB_IP = ConfigurationSettings.AppSettings["Data Source"];
			//string DB_Name = ConfigurationSettings.AppSettings["Initial Catalog"];
			//string DB_User_Name = ConfigurationSettings.AppSettings["User Id"];
			//string DB_Pwd = ConfigurationSettings.AppSettings["DB_Name_Password"];
			string con = @"Data Source=192.168.0.200\SQLSERVER ;Initial Catalog=NcxPerso_NBO; User ID=NcxPerso;Password=NcxPerso";
			SqlConnection cn = new SqlConnection(con);
			return cn;
		}
	}
}
