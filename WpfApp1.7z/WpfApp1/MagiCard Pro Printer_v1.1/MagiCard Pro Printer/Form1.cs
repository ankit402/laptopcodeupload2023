﻿using System;
using System.Windows.Forms;
using System.Collections.Generic;
using System.Drawing;
using System.Drawing.Printing;
using System.Net;
using System.Diagnostics;
using SDKShim;
using MagicardProLibrary;
using System.IO;
using System.Threading;
using System.Runtime.InteropServices;
using Microsoft.Win32;
using System.Text;
using System.Data.Sql;
using System.Data.SqlClient;
using System.Data;
using System.Configuration;

namespace MagiCard_Pro_Printer
{
    public partial class Form1 : Form
    {
        #region === Initialisation ===

        private IntPtr hSession;
        static private IntPtr hDC = IntPtr.Zero;
        static private PrinterSettings ps = new PrinterSettings();
        static private PrintDialog pd = new PrintDialog();
        static private Graphics g;
        
            IntPtr FrontDC, BackDC, FrontResinDC, BackResinDC;
            SDK.TextDef TextDefn = new SDK.TextDef();
            SDK.ShapeDef ShapeDefn = new SDK.ShapeDef();
            SDK.LineDef LineDefn = new SDK.LineDef();
            SDK.ImageDef ImageDefn = new SDK.ImageDef();
            SDK.Return SDKReturn;
        MagicardProLibrary.Embossing objRio = new MagicardProLibrary.Embossing();
        string image_print  =System.IO.Path.GetDirectoryName(System.Reflection.Assembly.GetEntryAssembly().Location) + @"\Desert.jpg"; 
        public Form1()
        {
            InitializeComponent();
            InitSessionConfigBox();
            InitFeedCardBox();
            InitColorBoxes();
            InitEncodingTypeBox();
            InitCoercivityBox();
            InitParityBoxes();
            InitHandFeedBox();
            InitEjectModeBox();
            InitBPCBoxes();
            //InitSmartModeBox();
            InitBPIBoxes();
            InitLRCBoxes();
			comboBox2.SelectedIndex = 1;
            tabPage1.Enabled = false;
            //tabPage2.Enabled = false;
            tabPage4.Enabled = false;

        }
        #region === Child Methods ===

        private void HandleError(string action, SDK.Return result)
        {
            string error;

            switch (result)
            {
                case SDK.Return.Timeout: error = "ID_TIMEOUT"; break;
                case SDK.Return.Error: error = "ID_ERROR"; break;
                case SDK.Return.PrinterError: error = "ID_PRINTER_ERROR"; break;
                case SDK.Return.DriverNotCompliant: error = "ID_DRIVER_NOTCOMPLIANT"; break;
                case SDK.Return.OpenPrinterError: error = "ID_OPENPRINTER_ERROR"; break;
                case SDK.Return.RemoteCommError: error = "ID_REMOTECOMM_ERROR"; break;
                case SDK.Return.LocalCommError: error = "ID_LOCALCOMM_ERROR"; break;
                case SDK.Return.SpoolerNotEmpty: error = "ID_SPOOLER_NOT_EMPTY"; break;
                case SDK.Return.RemoteCommInUse: error = "ID_REMOTECOMM_IN_USE"; break;
                case SDK.Return.LocalCommInUse: error = "ID_LOCALCOMM_IN_USE"; break;
                case SDK.Return.ParamError: error = "ID_PARAM_ERROR"; break;
                case SDK.Return.InvalidSession: error = "ID_INVALID_SESSION"; break;
                default: error = "Unknown API Error - " + result; break;
            }
            MessageBox.Show(action + ": " + error);
        }
        private bool PrinterIsReady()
        {
            return (SDK.ID_PrinterStatus(hSession) == SDK.PrinterStatus.Ready);
        }
        #endregion
        #region === Hand Feed ===

        Dictionary<SDK.HandFeed, string> handfeedkp = new Dictionary<SDK.HandFeed, string>()
        {
            {SDK.HandFeed.On,  "On" },  
            {SDK.HandFeed.Off, "Off"}, 
        };

        private void InitHandFeedBox()
        {
            HandFeedBox.DataSource = new BindingSource(handfeedkp, null);
            HandFeedBox.DisplayMember = "Value";
        }

        private void HandFeedToMsgBox(SDK.Action Action, SDK.HandFeed mode)
        {
            string sep = Separator(Action);
            textBox2.AppendText("Hand Feed" + sep + handfeedkp[mode] + Environment.NewLine);
            textBox2.AppendText(Environment.NewLine);
        }

        private void SetHandFeedBox(SDK.HandFeed mode)
        {
            HandFeedBox.Text = handfeedkp[mode];
        }

        private SDK.Return GetHandFeed(ref SDK.HandFeed Mode)
        {
            SDK.Return SDKReturn = SDK.ID_HandFeed(hSession, SDK.Action.Read, ref Mode);
            if (SDKReturn != SDK.Return.Success)
            {
                HandleError("GetHandFeed", SDKReturn);
            }
            return SDKReturn;
        }

        private void HandFeedButton_Click(object sender, EventArgs e)
        {
            Cursor.Current = Cursors.WaitCursor;

            SDK.HandFeed mode = ((KeyValuePair<SDK.HandFeed, string>)HandFeedBox.SelectedItem).Key;

            if (PrinterActionIsGet())
            {
                if (GetHandFeed(ref mode) == SDK.Return.Success)
                {
                    SetHandFeedBox(mode);
                    HandFeedToMsgBox(SDK.Action.Read, mode);
                }
            }
            else
            {
                SDK.Return SDKReturn = SDK.ID_HandFeed(hSession, SDK.Action.Write, ref mode);
                if (SDKReturn != SDK.Return.Success)
                {
                    HandleError("SetHandFeed", SDKReturn);
                }
                else
                {
                    HandFeedToMsgBox(SDK.Action.Write, mode);
                }
            }

            Cursor.Current = Cursors.Default;
        }

        #endregion
      
        private void InitSessionConfigBox()
        {
            SessionConfigBox.DataSource = new BindingSource(openconfigkp, null);
            SessionConfigBox.DisplayMember = "Value";
            SessionConfigBox.SelectedItem = SDK.Config.Normal;
        }
        private SDK.Return GetIPSettings(ref SDK.IPData settings)
        {
            SDK.Return SDKReturn = SDK.ID_IPSettings(hSession, SDK.Action.Read, settings);
            if (SDKReturn != SDK.Return.Success)
            {
                HandleError("GetIPSettings", SDKReturn);
            }
            return SDKReturn;
        }
        #endregion
        private Boolean ProntoPrinter()
        {
            if (SDK.ID_PrinterType(hSession) != SDK.PrinterType.Enduro)
            {
                return false;
            }
			return true;
        }
        Dictionary<SDK.Config, string> openconfigkp = new Dictionary<SDK.Config, string>()
        {
            {SDK.Config.Normal, "Config Normal"},
        };
        private void SetSmartOffset(int Offset)
        {
            //SmartOffsetBox.Value = Offset;
        }
        public void opessessionset() 
        {
            ps = pd.PrinterSettings;
            g = ps.CreateMeasurementGraphics();
            hDC = g.GetHdc();
            SDK.Config Config = ((KeyValuePair<SDK.Config, string>)SessionConfigBox.SelectedItem).Key;
            SDK.Return SDKReturn = SDK.ID_OpenSession(hDC, out hSession, Config);
            if (SDKReturn != SDK.Return.Success)
            {
                HandleError("OpenSession", SDKReturn);
            }
            else
            {
                //Call the SDK to get the printer model
                if (SDK.ID_PrinterType(hSession) == SDK.PrinterType.Enduro)
                {
                    MessageBox.Show("Use with DTC Only",
                                    "Invalid Printer",
                                    MessageBoxButtons.OK);
                    SDK.ID_CloseSession(hSession);
                }
                else
                {
                    OpenSessionButton.Visible = false;
                    SessionConfigBox.Visible = false;
                    Cursor.Current = Cursors.WaitCursor;
                    if (PrinterIsReady())
                    {
                        if (SDK.ID_PrinterType(hSession) == SDK.PrinterType.Enduro)
                        {
                            SDK.PrinterInfo PrinterInfo = new SDK.PrinterInfo();
                            SDKReturn = SDK.ID_PrinterInfo(hSession, PrinterInfo);
                            if (SDKReturn != SDK.Return.Success)
                            {
                                HandleError("Open - GetPrinterInfo", SDKReturn);
                            }
                        }
                    }
                    EnableControls(true);
                    Cursor.Current = Cursors.Default;
                }
            }
            Application.DoEvents();       
        }      
        #region === Restart Printer ===

        private void RestartButton_Click(object sender, EventArgs e)
        { 
            objRio.Reset();
           
        }
        #endregion
        //----------------------------------------------------------------------
        private void WaitForPrinterToFinish()
        {
            Cursor.Current = Cursors.WaitCursor;
            SDK.Return SDKReturn;
           
            //do
            //{
            //    //Repeat the wait until response is not timeout
            //    SDKReturn = SDK.ID_WaitForPrinter(hSession);
            //} while (SDKReturn == SDK.Return.Timeout);
            //if (SDKReturn != SDK.Return.Success)
            //{
            //    MessageBox.Show("Printer Response" + SDKReturn);

            //}
            //else
            //{
            //    MessageBox.Show("Card Printed Succesfully");
            //}
        }

        //----------------------------------------------------------------------
        //*********************************************************************

        #region === Feed card ===

        Dictionary<SDK.FeedMode, string> feedcardkp = new Dictionary<SDK.FeedMode, string>()
        {
            {SDK.FeedMode.ChipCard,    "Contact"},     
            {SDK.FeedMode.Contactless, "ContactLess"}, 
        };

        private void InitFeedCardBox()
        {
            FeedCardBox.DataSource = new BindingSource(feedcardkp, null);
            FeedCardBox.DisplayMember = "Value";
        }

        private void FeedCardButton_Click(object sender, EventArgs e)
        {
            //open session
            int hSession_val = objRio.connect_ptr();
            // feed mode  for contactcard --> ChipCard
            SDK.FeedMode mode = (new KeyValuePair<SDK.FeedMode, string>(SDK.FeedMode.ChipCard,"ChipCard").Key);
            hSession = (IntPtr)hSession_val;
            // feed card
            SDK.Return SDKReturn =  SDK.ID_FeedCard(hSession, mode, 0);
            //ID_PRINTER_ERROR
           
            if (SDKReturn != SDK.Return.Success)
            {
                HandleError("Feedcard", SDKReturn);
            }
            else
            {
               // WaitForPrinterToFinish();
                SDK.Return sdk = SDK.ID_ErrorResponse(hSession, 0);
                
            }
        }

        #endregion
        private void EnableControls(bool state)
        {
            //Buttons
            FeedCardButton.Visible = state;
            FeedCardButton.Enabled = state;
            FeedCardBox.Visible = state;
            FeedCardBox.Enabled = state;

            EjectCardButton.Enabled = state;
            FlipCardButton.Enabled = state;
            PrintTestCardButton.Enabled = state;
            //CleanPrinterButton.Enabled = state;
            RestartButton.Enabled = state;
            //GenCommandButton.Enabled = state;
            //GenCommandBox.Enabled = state;
            //EraseCardButton.Enabled = state;
            //EraseArea_BotLXBox.Enabled = state;
            //EraseArea_BotLYBox.Enabled = state;
            //EraseArea_TopRXBox.Enabled = state;
            //EraseArea_TopRYBox.Enabled = state;
            //EraseCount.Enabled = state;
            //ErrorResponseButton.Enabled = state;
            //ErrorResponseBox.Enabled = state;
            PrinterGetRadio.Enabled = state;
            PrinterSetRadio.Enabled = state;
            HandFeedButton.Enabled = state;
            EjectModeButton.Enabled = state;
            HorzEjectButton.Enabled = state;
            SmartModeButton.Enabled = state;
            SmartOffsetButton.Enabled = state;
            EraseSpeedButton.Enabled = state;
            IPSettingsButton.Enabled = state;

           // PrinterGetSetControls(!PrinterGetRadio.Checked);
        }
        //*********************************************************************

        #region === Eject Card ===

        private void EjectCardButton_Click(object sender, EventArgs e)
        {
            objRio.EjectCard();
        }

        #endregion

        //*********************************************************************

        #region === Flip Card ===

        private void FlipCardButton_Click(object sender, EventArgs e)
        {
            SDK.Return SDKReturn = SDK.ID_FlipCard(hSession);
            if (SDKReturn != SDK.Return.Success)
            {
                HandleError("FlipCard", SDKReturn);
            }
            else
            {
                WaitForPrinterToFinish();
            }
        }

        #endregion

        //*********************************************************************

        #region === Print Test Card ===

        private void PrintTestCardButton_Click(object sender, EventArgs e)
        {
            //SDK.Return SDKReturn = SDK.ID_PrintTestCard(hSession);
            SDK.Return SDKReturn = SDK.ID_PrintCard(hSession);
            if (SDKReturn != SDK.Return.Success)
            {
                HandleError("PrintCard", SDKReturn);
            }
            else
            {
                WaitForPrinterToFinish();
            }
        }

        #endregion
        Dictionary<Color, string> colorkp = new Dictionary<Color, string>()
        {
          {Color.Red,     "Red"},     
          {Color.Green,   "Green"},   
          {Color.Blue,    "Blue"},   
          {Color.Cyan,    "Cyan"},    
          {Color.Magenta, "Magenta"}, 
          {Color.Yellow,  "Yellow"},  
          {Color.White,   "White"},   
          {Color.Black,   "Black"},   
        };

        //This key pair is used for the shape fill list boxes and is the same
        // as colorkp but with 'Transparent' added
        Dictionary<Color, string> colorfillkp = new Dictionary<Color, string>();

        private void InitColorBoxes()
        {
            TextFrontColourBox.DataSource = new BindingSource(colorkp, null);
            TextFrontColourBox.DisplayMember = "Value";
            //N.B Transparent also in shape fill combo boxes
            foreach (var pair in colorkp)
            {
                colorfillkp.Add(pair.Key, pair.Value);
            }
            colorfillkp.Add(Color.Transparent, "Transparent");

          
        }
        Dictionary<SDK.EncodingSpec, string> encodingkp = new Dictionary<SDK.EncodingSpec, string>()
        {
            {SDK.EncodingSpec.ISO,  "ISO"},
            {SDK.EncodingSpec.JIS2, "JIS2"},
        };

        private void InitEncodingTypeBox()
        {
            EncodingTypeBox.DataSource = new BindingSource(encodingkp, null);
            EncodingTypeBox.DisplayMember = "Value";
        }

        Dictionary<SDK.Coercivity, string> coercivitykp = new Dictionary<SDK.Coercivity, string>()
        {
            {SDK.Coercivity.Default, "Default"},
            {SDK.Coercivity.HiCo,    "HiCo"},
            {SDK.Coercivity.LoCo,    "LoCo"},
        };

        private void InitCoercivityBox()
        {
            CoercivityBox.DataSource = new BindingSource(coercivitykp, null);
            CoercivityBox.DisplayMember = "Value";
        }

        Dictionary<SDK.BitsPerChar, string> bpckp = new Dictionary<SDK.BitsPerChar, string>()
        {
            {SDK.BitsPerChar.Default, "Default"}, 
            {SDK.BitsPerChar.BPC1,    "1"},       
            {SDK.BitsPerChar.BPC5,    "5"},       
            {SDK.BitsPerChar.BPC7,    "7"},       
        };

        private void InitBPCBoxes()
        {
            T1_BPCBox.DataSource = new BindingSource(bpckp, null);
            T1_BPCBox.DisplayMember = "Value";
            T2_BPCBox.DataSource = new BindingSource(bpckp, null);
            T2_BPCBox.DisplayMember = "Value";
          
        }
        Dictionary<SDK.BitsPerInch, string> bpikp = new Dictionary<SDK.BitsPerInch, string>()
        {
            {SDK.BitsPerInch.Default, "Default"}, 
            {SDK.BitsPerInch.BPI210,  "210"},     
            {SDK.BitsPerInch.BPI75,   "75"},      
        };

        private void InitBPIBoxes()
        {
            T1_BPIBox.DataSource = new BindingSource(bpikp, null);
            T1_BPIBox.DisplayMember = "Value";
            T2_BPIBox.DataSource = new BindingSource(bpikp, null);
            T2_BPIBox.DisplayMember = "Value";
          
        }

        Dictionary<SDK.Parity, string> paritykp = new Dictionary<SDK.Parity, string>()
        {
            {SDK.Parity.Default, "Default"},
            {SDK.Parity.Odd,     "Odd"},     
            {SDK.Parity.Even,    "Even"},    
            {SDK.Parity.Off,     "Off"},     
        };

        private void InitParityBoxes()
        {
            T1_ParityBox.DataSource = new BindingSource(paritykp, null);
            T1_ParityBox.DisplayMember = "Value";
            T2_ParityBox.DataSource = new BindingSource(paritykp, null);
            T2_ParityBox.DisplayMember = "Value";      
        }

        Dictionary<SDK.LRC, string> lrckp = new Dictionary<SDK.LRC, string>()
        {
            {SDK.LRC.Default, "Default"}, 
            {SDK.LRC.Odd,     "Odd"},     
            {SDK.LRC.Even,    "Even"},    
            {SDK.LRC.Off,     "Off"},     
        };

        public int EncodeMagstripe(int iTrackNumber, string sTrackData)
        {
            int i = -1;
            SDK.MagDef Encode = new SDK.MagDef();

            char[] track1 = new char[76];
            char[] track2 = new char[37];
            if (iTrackNumber == 1)
            {
                track1 = sTrackData.ToCharArray();
                string s_track1 = new string(track1);
                Encode.Track[0].Data = s_track1.ToString();
                Encode.Track[0].CharCount = decimal.ToByte(s_track1.Length);
                SDK.Return SDKReturn = SDK.ID_EncodeMag(hSession, Encode);
                if (SDKReturn != SDK.Return.Success)
                {
                    HandleError("EncodeMag", SDKReturn);
                }
                else
                {
                    WaitForPrinterToFinish();
                }
            }
            return 0;
        }
        private void InitLRCBoxes()
        {
            T1_LRCBox.DataSource = new BindingSource(lrckp, null);
            T1_LRCBox.DisplayMember = "Value";
            T2_LRCBox.DataSource = new BindingSource(lrckp, null);
            T2_LRCBox.DisplayMember = "Value";         
        }
        //*********************************************************************
        #region === Print Button ===

        private void PrintButton_Click(object sender, EventArgs e)
        {
            try
            {
                int hSession_value = 0;
                hSession = IntPtr.Zero;
                ps = pd.PrinterSettings;
                g = ps.CreateMeasurementGraphics();
                hDC = g.GetHdc();
                //((KeyValuePair<SDK.Config, string>)SessionConfigBox.SelectedItem).Key;
                SDK.Config Config = (new KeyValuePair<SDK.Config, string>(SDK.Config.Normal, "Normal").Key);
                SDK.Return SDKReturn = SDK.ID_OpenSession(hDC, out hSession, Config);
                hSession_value = (int)hSession;
                // Encode.EncodingSpec = ((KeyValuePair<SDK.EncodingSpec, string>)EncodingTypeBox.SelectedItem).Key;
                //  Encode.Coercivity = ((KeyValuePair<SDK.Coercivity, string>)CoercivityBox.SelectedItem).Key;
                //if (MagDataEnabled.Enabled)
                //{
                //    if (true)
                //    {
                //        Encode.Track[0].CharCount = decimal.ToByte(txt_Track1.TextLength);
                //        Encode.Track[0].Data = txt_Track1.Text;
                //    }

                //    if (true)
                //    {
                //        Encode.Track[1].CharCount = decimal.ToByte(txt_Track2.TextLength);
                //        Encode.Track[1].Data = txt_Track2.Text;
                //    }
                //     SDKReturn = SDK.ID_DrawMagText(hSession, SDK.Side.Front, magText);
                //    SDKReturn = SDK.ID_EncodeMag(hSession, Encode);
                //}
                //if (SDKReturn == SDK.Return.Success)
                //{
                //    SDK.EjectMode mode = (new KeyValuePair<SDK.EjectMode, string>(SDK.EjectMode.Off, "Off").Key);
                //}
                if (hSession_value != 0) // session remains printer perform 
                {
                    do
                    {
                        //Is there a front to be printed?
                        if (true)//CardFront.Checked
                        {

                            //Initialise Front Canvas
                            SDK.PrintSetting PrintSettings = new SDK.PrintSetting();
                            SDK.PrintSetting OldPrintSettings = new SDK.PrintSetting();

                            SDKReturn = SDK.ID_PrintSettings(hSession, SDK.Action.Read, OldPrintSettings);
                            if (SDKReturn != SDK.Return.Success)
                            {
                                HandleError("OldPrintSettings", SDKReturn);
                                break;
                            }
                            PrintSettings = OldPrintSettings;
                            SDK.EjectMode mode = (new KeyValuePair<SDK.EjectMode, string>(SDK.EjectMode.Off, "Off").Key);
                            //Determine which sides of the card need to be printed

                            PrintSettings.Duplex = SDK.Duplex.Both;

                            //Change the print settings for the card
                            SDKReturn = SDK.ID_PrintSettings(hSession, SDK.Action.Write, PrintSettings);
                            if (SDKReturn != SDK.Return.Success)
                            {
                                HandleError("WritePrintSettings", SDKReturn);
                                break;
                            }
                            SDKReturn = SDK.ID_CanvasInit(hSession, out FrontDC, SDK.Canvas.Front);
                            if (SDKReturn != SDK.Return.Success)
                            {
                                HandleError("CanvasInitFront", SDKReturn);
                                break;
                            }
                            if (true)//TextFrontEnabled.Checked
                            {
                                ImageDefn.X = 0;// (int)ImageFrontXUpDown.Value;
                                ImageDefn.Y = 0;// (int)ImageFrontYUpDown.Value;
                                ImageDefn.P1 = 0;// (int)ImageFrontP1UpDown.Value;
                                ImageDefn.P2 = 0;// (int)ImageFrontP2UpDown.Value;

                                ImageDefn.Filename = image_print;

                                //Call the SDK function to draw the image on the canvas
                                SDKReturn = SDK.ID_DrawImage(hSession,
                                                             false ? SDK.Canvas.FrontResin : SDK.Canvas.Front,
                                                             ImageDefn);
                                if (SDKReturn != SDK.Return.Success)
                                {
                                    HandleError("DrawImageFront", SDKReturn);
                                    break;
                                }

                                //Card Number 
                                TextDefn.FontName = "Arial";
                                TextDefn.FontSize = (int)cardnosize.Value;
                                //(new KeyValuePair<Color, string>(SDK.EjectMode.Off, "Off").Key);
                                TextDefn.FontColour = (new KeyValuePair<Color, string>(Color.White, "White").Key);
                                TextDefn.FontStyle = 0;
                                //Get the location and angle for the text
                                TextDefn.X = (int)TextFrontXUpDown.Value;
                                TextDefn.Y = (int)TextFrontYUpDown.Value;
                                TextDefn.Angle = 0;
                                //Get the text to be drawn
                                TextDefn.Text = txt_CardNumber.Text;
                                //Call the SDK function to draw the text on the canvas
                                SDKReturn = SDK.ID_DrawText(hSession, false ? SDK.Canvas.FrontResin : SDK.Canvas.Front, TextDefn);
                                if (SDKReturn != SDK.Return.Success)
                                {
                                    HandleError("DrawTextFront", SDKReturn);
                                    break;
                                }
                                //Name on Card
                                TextDefn.FontName = "Arial";
                                TextDefn.FontSize = (int)namesize.Value;
                                TextDefn.FontColour = (new KeyValuePair<Color, string>(Color.White, "White").Key);
                                TextDefn.FontStyle = 0;
                                TextDefn.X = (int)namex.Value;
                                TextDefn.Y = (int)namey.Value;
                                TextDefn.Angle = 0;
                                TextDefn.Text = txt_Name.Text;
                                //Call the SDK function to draw the text on the canvas
                                SDKReturn = SDK.ID_DrawText(hSession, false ? SDK.Canvas.FrontResin : SDK.Canvas.Front, TextDefn);
                                if (SDKReturn != SDK.Return.Success)
                                {
                                    HandleError("DrawTextFront", SDKReturn);
                                    break;
                                }
                                //Valid
                                TextDefn.FontName = "Arial";
                                TextDefn.FontSize = (int)namesize.Value;
                                TextDefn.FontColour = (new KeyValuePair<Color, string>(Color.White, "White").Key);
                                TextDefn.FontStyle = 0;
                                TextDefn.X = (int)validx.Value;
                                TextDefn.Y = (int)validy.Value;
                                TextDefn.Angle = 0;
                                TextDefn.Text = txt_Valid.Text;
                                //Call the SDK function to draw the text on the canvas
                                SDKReturn = SDK.ID_DrawText(hSession, false ? SDK.Canvas.FrontResin : SDK.Canvas.Front, TextDefn);
                                if (SDKReturn != SDK.Return.Success)
                                {
                                    HandleError("DrawTextFront", SDKReturn);
                                    break;
                                }
                                //expiry
                                TextDefn.FontName = "Arial";
                                TextDefn.FontSize = (int)namesize.Value;
                                TextDefn.FontColour = (new KeyValuePair<Color, string>(Color.White, "White").Key);
                                TextDefn.FontStyle = 0;
                                TextDefn.X = (int)expryx.Value;
                                TextDefn.Y = (int)expryy.Value;
                                TextDefn.Angle = 0;
                                TextDefn.Text = txt_Exp.Text;
                                //Call the SDK function to draw the text on the canvas
                                SDKReturn = SDK.ID_DrawText(hSession, false ? SDK.Canvas.FrontResin : SDK.Canvas.Front, TextDefn);
                                if (SDKReturn != SDK.Return.Success)
                                {
                                    HandleError("DrawTextFront", SDKReturn);
                                    break;
                                }
                            }
                        }
                        //-------------------------------------------------------------------
                        //Is there a back to be printed?
                        if (true)//CardBack.Checked
                        {
                            SDK.CardSetting BackSettings = new SDK.CardSetting();
                            SDK.CardSetting OldBackSettings = new SDK.CardSetting();
                            //Read the current settings for the Back of the card
                            SDKReturn = SDK.ID_CardSettings(hSession, SDK.Action.Read, SDK.Side.Back, OldBackSettings);
                            if (SDKReturn != SDK.Return.Success)
                            {
                                HandleError("OldCardSettings", SDKReturn);
                                break;
                            }
                            BackSettings = OldBackSettings;

                            if (SDKReturn != SDK.Return.Success)
                            {
                                HandleError("OldCardSettings", SDKReturn);
                                break;
                            }
                            BackSettings = OldBackSettings;
                            SDKReturn = SDK.ID_CardSettings(hSession, SDK.Action.Write, SDK.Side.Back, BackSettings);
                            if (SDKReturn != SDK.Return.Success)
                            {
                                HandleError("CardSettingsBack", SDKReturn);
                                break;
                            }
                            //Initialise Rear Canvas
                            SDKReturn = SDK.ID_CanvasInit(hSession, out BackDC, SDK.Canvas.Back);
                            if (SDKReturn != SDK.Return.Success)
                            {
                                HandleError("CanvasInitBack", SDKReturn);
                                break;
                            }
                            TextDefn.FontName = "Arial";
                            TextDefn.FontSize = (int)cvvsize.Value;
                            TextDefn.FontColour = ((KeyValuePair<Color, string>)TextFrontColourBox.SelectedItem).Key;
                            TextDefn.FontStyle = 0;
                            TextDefn.X = (int)cvvx.Value;
                            TextDefn.Y = (int)cvvy.Value;
                            TextDefn.Angle = 0;
                            TextDefn.Text = txt_CVV.Text;
                            //Call the SDK function to draw the text on the canvas
                            SDKReturn = SDK.ID_DrawText(hSession,
                                                        false ? SDK.Canvas.BackResin : SDK.Canvas.Back,
                                                        TextDefn);
                            if (SDKReturn != SDK.Return.Success)
                            {
                                HandleError("DrawTextback", SDKReturn);
                                break;
                            }
                        }
                        //-------------------------------------------------------------------
                        //Print the Card
                        SDKReturn = SDK.ID_PrintCard(hSession);
                        if (SDKReturn != SDK.Return.Success)
                        {
                            HandleError("PrintCard", SDKReturn);
                            break;
                        }
                        //Wait for the printing to complete
                        SDKReturn = SDK.ID_WaitForPrinter(hSession);
                        if (SDKReturn == SDK.Return.Success)
                        {
                            MessageBox.Show("Printer Successfully");
                        }
                        //WaitForPrinterToFinish();
                        objRio.EjectCard();

                        SDKReturn = SDK.ID_CloseSession(hSession);
                    }

                    while (false);  //End of single pass do..while loop

                }
                else
                {
                    MessageBox.Show("Cannot Print - Printer is not available");
                    return;
                }
            }
            catch (Exception ex) 
            {

                MessageBox.Show(ex.ToString());
            }
        }
        #endregion
        private void InitSmartModeBox()
        {
            SmartModeBox.DataSource = new BindingSource(smartmodekp, null);
            SmartModeBox.DisplayMember = "Value";
        }
        private string Separator(SDK.Action action)
        {
            return (action == SDK.Action.Read) ? ": " : " -> ";
        }
        private void SmartModeToMsgBox(SDK.Action Action, SDK.SmartMode mode)
        {
            string sep = Separator(Action);
            PrinterMsgBox.AppendText("Smart Mode" + sep + smartmodekp[mode] + Environment.NewLine);
            PrinterMsgBox.AppendText(Environment.NewLine);
        }
        #region === Eject Mode ===

        Dictionary<SDK.EjectMode, string> ejectmodekp = new Dictionary<SDK.EjectMode, string>()
        {
            {SDK.EjectMode.Off, "Off"}, 
            {SDK.EjectMode.On,  "On" },  
        };

        private void InitEjectModeBox()
        {
            EjectModeBox.DataSource = new BindingSource(ejectmodekp, null);
            EjectModeBox.DisplayMember = "Value";
        }

        private void EjectModeToMsgBox(SDK.Action Action, SDK.EjectMode mode)
        {
            textBox2.AppendText("Eject Mode"
                                     + Separator(Action)
                                     + ejectmodekp[mode]
                                     + Environment.NewLine);
            textBox2.AppendText(Environment.NewLine);
        }

        private void SetEjectModeBox(SDK.EjectMode mode)
        {
            EjectModeBox.Text = ejectmodekp[mode];
        }

        private SDK.Return GetEjectMode(ref SDK.EjectMode mode)
        {
            SDK.Return SDKReturn = SDK.ID_EjectMode(hSession, SDK.Action.Read, ref mode);
            if (SDKReturn != SDK.Return.Success)
            {
                HandleError("GetEjectMode", SDKReturn);
            }
            return SDKReturn;
        }
        private bool PrinterActionIsGet()
        {
            return PrinterGetRadio.Checked;
        }
        private void EjectModeButton_Click(object sender, EventArgs e)
        {
            int hSession_val = 0;
            hSession_val = objRio.connect_ptr();
            hSession = (IntPtr)hSession_val;
            Cursor.Current = Cursors.WaitCursor;

            SDK.EjectMode mode = ((KeyValuePair<SDK.EjectMode, string>)EjectModeBox.SelectedItem).Key;

            if (PrinterActionIsGet())
            {
                if (GetEjectMode(ref mode) == SDK.Return.Success)
                {
                    SetEjectModeBox(mode);
                    EjectModeToMsgBox(SDK.Action.Read, mode);
                }
            }
            else
            {
                SDK.Return SDKReturn = SDK.ID_EjectMode(hSession, SDK.Action.Write, ref mode);
                if (SDKReturn != SDK.Return.Success)
                {
                    HandleError("SetEjectMode", SDKReturn);
                }
                else
                {
                    EjectModeToMsgBox(SDK.Action.Write, mode);
                }
            }
            Cursor.Current = Cursors.Default;
        }

        #endregion

        #region === Smart Mode ===

        Dictionary<SDK.SmartMode, string> smartmodekp = new Dictionary<SDK.SmartMode, string>()
        {
            {SDK.SmartMode.Default, "Default"}, 
            {SDK.SmartMode.Platen,  "Platen"},  
            {SDK.SmartMode.XLI,     "XLI"},  
        };

        private void SetSmartModeBox(SDK.SmartMode mode)
        {
            SmartModeBox.Text = smartmodekp[mode];
        }

        private SDK.Return GetSmartMode(ref SDK.SmartMode Mode)
        {
            SDK.Return SDKReturn = SDK.ID_SmartMode(hSession, SDK.Action.Read, ref Mode);
            if (SDKReturn != SDK.Return.Success)
            {
                HandleError("GetSmartMode", SDKReturn);
            }
            return SDKReturn;
        }

        private void SmartModeButton_Click(object sender, EventArgs e)
        {
            Cursor.Current = Cursors.WaitCursor;
            SDK.SmartMode mode = ((KeyValuePair<SDK.SmartMode, string>)SmartModeBox.SelectedItem).Key;
            if (PrinterActionIsGet())
            {
                if (GetSmartMode(ref mode) == SDK.Return.Success)
                {
                    SetSmartModeBox(mode);
                    //SmartModeToMsgBox(SDK.Action.Read, mode);
                }
            }
            else
            {
                SDK.Return SDKReturn = SDK.ID_SmartMode(hSession, SDK.Action.Write, ref mode);
                if (SDKReturn != SDK.Return.Success)
                {
                    HandleError("SetSmartMode", SDKReturn);
                }
                else
                {
                    //SmartModeToMsgBox(SDK.Action.Write, mode);
                }
            }

            Cursor.Current = Cursors.Default;
        }

        #endregion


        #region === Encode Mag ===
        private void Encode_Mag() 
        {
            //int hSession_val = 0;
            //hSession_val= objRio.connect_ptr();
            //hSession = (IntPtr)hSession_val;
            int hSession_value = 0;
            hSession = IntPtr.Zero;
            ps = pd.PrinterSettings;
            g = ps.CreateMeasurementGraphics();
            hDC = g.GetHdc();
            //((KeyValuePair<SDK.Config, string>)SessionConfigBox.SelectedItem).Key;
            SDK.Config Config = (new KeyValuePair<SDK.Config, string>(SDK.Config.Normal, "Normal").Key);
            SDK.Return SDKReturn = SDK.ID_OpenSession(hDC, out hSession, Config);
            hSession_value = (int)hSession;
            //bool ret_value = false;
            SDK.MagDef Encode = new SDK.MagDef();
            SDK.MagText magText = new SDK.MagText();
           // Encode.EncodingSpec = ((KeyValuePair<SDK.EncodingSpec, string>)EncodingTypeBox.SelectedItem).Key;
          //  Encode.Coercivity = ((KeyValuePair<SDK.Coercivity, string>)CoercivityBox.SelectedItem).Key;
                if (true)
                {
                    Encode.Track[0].CharCount = decimal.ToByte(txt_Track1.TextLength);
                    Encode.Track[0].Data = txt_Track1.Text;   
                }

                if (true)
                {
                    Encode.Track[1].CharCount = decimal.ToByte(txt_Track2.TextLength);
                    Encode.Track[1].Data = txt_Track2.Text;                 
                }
               // SDK.Return SDKReturn = SDK.ID_EncodeMag(hSession, Encode);
                 SDKReturn = SDK.ID_DrawMagText(hSession, SDK.Side.Front, magText);
            SDK.EjectMode mode = (new KeyValuePair<SDK.EjectMode, string>(SDK.EjectMode.Off, "Off").Key);
            SDKReturn = SDK.ID_EncodeMag(hSession, Encode);
           
            if (SDKReturn == SDK.Return.Success)
				{
                // objRio.EjectCard();
                MessageBox.Show("done magencode");
            }
			else
				{
                MessageBox.Show("Failed to magencode");
				}
			}
        private void Encode_Mag(int hsession_value) 
        {
            SDK.MagDef Encode = new SDK.MagDef();

            Encode.EncodingSpec = ((KeyValuePair<SDK.EncodingSpec, string>)EncodingTypeBox.SelectedItem).Key;
            Encode.Coercivity = ((KeyValuePair<SDK.Coercivity, string>)CoercivityBox.SelectedItem).Key;
            if (true)
            {
                Encode.Track[0].CharCount = decimal.ToByte(txt_Track1.TextLength);
                Encode.Track[0].Data = txt_Track1.Text;
            }

            if (true)
            {
                Encode.Track[1].CharCount = decimal.ToByte(txt_Track2.TextLength);
                Encode.Track[1].Data = txt_Track2.Text;
            }
            hSession = (IntPtr)hsession_value;
            SDK.Return SDKReturn = SDK.ID_EncodeMag(hSession, Encode);
            if (SDKReturn != SDK.Return.Success)
            {
                HandleError("EncodeMag", SDKReturn);
			
            }
            else
            {
                //WaitForPrinterToFinish();
            }
        }
        #endregion
        private void button1_Click(object sender, EventArgs e)
        {
            Encode_Mag();
        }

        private void Get_Info_Click(object sender, EventArgs e)
        {
            PrinterModelButton_Click();
            PrinterInfoButton_Click();
        }

        #region === Printer Model ===

        private void PrinterModelButton_Click()
        {
            if ((SDK.ID_PrinterType(hSession) != SDK.PrinterType.Enduro))
            {
                MessageBox.Show("Only Valid for Enduro & Helix Family Printers",
                                "Invalid Printer",
                                MessageBoxButtons.OK);
            }
            else
            {
                string msg;
                SDK.Model model = (SDK.Model)SDK.ID_PrinterModel(hSession);
                
                
                PrinterMsgBox.AppendText(Environment.NewLine);
                
            }
        }
        #endregion

        #region === PrinterInfo ===

        private void PrinterInfoButton_Click()
        {
            Cursor.Current = Cursors.WaitCursor;

            SDK.PrinterInfo PrinterInfo = new SDK.PrinterInfo();
            SDK.Return SDKReturn = SDK.ID_PrinterInfo(hSession, PrinterInfo);
            if (SDKReturn != SDK.Return.Success)
            {
                HandleError("PrinterInfo", SDKReturn);
            }
            else
            {
                PrinterMsgBox.AppendText("PrinterConnected: " + PrinterInfo.bPrinterConnected + Environment.NewLine);
                PrinterMsgBox.AppendText("Model No.: " + PrinterInfo.eModel + Environment.NewLine);
                PrinterMsgBox.AppendText("Model: " + PrinterInfo.sModel + Environment.NewLine);
                PrinterMsgBox.AppendText("PrinterSerial: " + PrinterInfo.sPrinterSerial + Environment.NewLine);
                PrinterMsgBox.AppendText("PrintheadSerial: " + PrinterInfo.sPrintheadSerial + Environment.NewLine);
                PrinterMsgBox.AppendText("PCBSerial: " + PrinterInfo.sPCBSerial + Environment.NewLine);
                PrinterMsgBox.AppendText("FirmwareVersion: " + PrinterInfo.Firmware.Version + Environment.NewLine);

                PrinterMsgBox.AppendText("Printhead: ");
                switch (PrinterInfo.ePrintheadType)
                {
                    case 0: PrinterMsgBox.AppendText("KGE2" + Environment.NewLine); break;
                    case 1: PrinterMsgBox.AppendText("KEE1" + Environment.NewLine); break;
                    case 2: PrinterMsgBox.AppendText("KEE4" + Environment.NewLine); break;
                    default: PrinterMsgBox.AppendText("Unknown" + Environment.NewLine); break;
                }

                PrinterMsgBox.AppendText("Density: " + PrinterInfo.iDensity + Environment.NewLine);
                PrinterMsgBox.AppendText("HandFeed: "
                                      + handfeedkp[(PrinterInfo.iHandFeed != 0) ? SDK.HandFeed.On : SDK.HandFeed.Off]
                                      + Environment.NewLine);
                PrinterMsgBox.AppendText("CardsPrinted: " + PrinterInfo.iCardsPrinted + Environment.NewLine);
                PrinterMsgBox.AppendText("CardsOnPrinthead: " + PrinterInfo.iCardsOnPrinthead + Environment.NewLine);
                PrinterMsgBox.AppendText("DyePanelsPrinted: " + PrinterInfo.iDyePanelsPrinted + Environment.NewLine);
                PrinterMsgBox.AppendText("CleansSinceShipped: " + PrinterInfo.iCleansSinceShipped + Environment.NewLine);
                PrinterMsgBox.AppendText("DyePanelsSinceClean: " + PrinterInfo.iDyePanelsSinceClean + Environment.NewLine);
                PrinterMsgBox.AppendText("CardsSinceClean: " + PrinterInfo.iCardsSinceClean + Environment.NewLine);
                PrinterMsgBox.AppendText("CardsBetweenCleans: " + PrinterInfo.iCardsBetweenCleans + Environment.NewLine);

                PrinterMsgBox.AppendText("PrintHeadPosn: " + PrinterInfo.iPrintHeadPosn + Environment.NewLine);
                PrinterMsgBox.AppendText("ImageStartPosn: " + PrinterInfo.iImageStartPosn + Environment.NewLine);
                PrinterMsgBox.AppendText("ImageEndPosn: " + PrinterInfo.iImageEndPosn + Environment.NewLine);
                PrinterMsgBox.AppendText("MajorError: " + PrinterInfo.iMajorError + Environment.NewLine);
                PrinterMsgBox.AppendText("MinorError: " + PrinterInfo.iMinorError + Environment.NewLine);

                PrinterMsgBox.AppendText("TagUID: " + PrinterInfo.sTagUID + Environment.NewLine);
                PrinterMsgBox.AppendText("ShotsOnFilm: " + PrinterInfo.iShotsOnFilm + Environment.NewLine);
                PrinterMsgBox.AppendText("ShotsUsed: " + PrinterInfo.iShotsUsed + Environment.NewLine);
                PrinterMsgBox.AppendText("DyeFilmType " + PrinterInfo.sDyeFilmType + Environment.NewLine);
                PrinterMsgBox.AppendText("ColourLength: " + PrinterInfo.iColourLength + Environment.NewLine);
                PrinterMsgBox.AppendText("ResinLength: " + PrinterInfo.iResinLength + Environment.NewLine);
                PrinterMsgBox.AppendText("OvercoatLength: " + PrinterInfo.iOvercoatLength + Environment.NewLine);
                PrinterMsgBox.AppendText("DyeFlags: " + PrinterInfo.eDyeFlags + Environment.NewLine);
                PrinterMsgBox.AppendText("CommandCode: " + PrinterInfo.iCommandCode + Environment.NewLine);
                PrinterMsgBox.AppendText("DOB: " + PrinterInfo.iDOB + Environment.NewLine);
                PrinterMsgBox.AppendText("DyeFilmManuf: " + PrinterInfo.eDyeFilmManuf + Environment.NewLine);
                PrinterMsgBox.AppendText("DyeFilmProg: " + PrinterInfo.eDyeFilmProg + Environment.NewLine);

                String temp_string;
                if (PrinterInfo.iBitFields.HasFlag(SDK.InfoMask.EncodePlaten))
                    temp_string = smartmodekp[SDK.SmartMode.Platen];
                else if (PrinterInfo.iBitFields.HasFlag(SDK.InfoMask.EncodeXLI))
                    temp_string = smartmodekp[SDK.SmartMode.XLI];
                else
                    temp_string = smartmodekp[SDK.SmartMode.Default];
                PrinterMsgBox.AppendText("SmartMode: " + temp_string + Environment.NewLine);

                PrinterMsgBox.AppendText("SmartOffset: " + PrinterInfo.iSmartOffset + Environment.NewLine);

                if (PrinterInfo.iBitFields.HasFlag(SDK.InfoMask.EjectMode))
                    temp_string = ejectmodekp[SDK.EjectMode.On];
                else
                    temp_string = ejectmodekp[SDK.EjectMode.Off];
                PrinterMsgBox.AppendText("EjectMode: " + temp_string + Environment.NewLine);
            }

            Cursor.Current = Cursors.Default;
        }

        #endregion

        private void OpenSessionButton_Click(object sender, EventArgs e)
        {
            opessessionset();
        }

        private void btn_ChipTest_Click(object sender, EventArgs e)
        {
            int ret;
            ret = ChipTest(textBox3.Text, "", 30000);
            if (ret==0)
            {
                 MessageBox.Show("Personalization Successful");
            }
            else
            {
                MessageBox.Show("Personalization Failed");
            }     
        }

        public int ChipTest(string CardNumber, string sMsg, int iChipWaitTime = 30000)
        {
            int rc = -1;
            try
            {
                File.Copy("C:\\Program Files\\OMA Emirates\\NanoPerso\\EmbossingDLLs\\CHIP\\Row.chp", "C:\\Program Files\\OMA Emirates\\NanoPerso\\EmbossingDLLs\\Row.chp", true);
                StreamReader srFile = new StreamReader("C:\\Program Files\\OMA Emirates\\NanoPerso\\EmbossingDLLs\\Row.chp");
                string sline = srFile.ReadLine();
                srFile.Close();
                string oldCardnumber = sline.Substring(12, 16);
                sline = sline.Replace(oldCardnumber, CardNumber.Replace(" ", ""));
                sline = sline.Replace("No Error", "NotPerso");
                StreamWriter swFile = new StreamWriter("C:\\Program Files\\OMA Emirates\\NanoPerso\\EmbossingDLLs\\Row.chp");
                swFile.Write(sline);
                swFile.Flush();
                swFile.Close();
                Process.Start("C:\\Program Files\\OMA Emirates\\NanoPerso\\EmbossingDLLs\\ChipManager.exe", "\"" + "C:\\Program Files\\OMA Emirates\\NanoPerso\\EmbossingDLLs\\Row.chp");
                int iCycleCount = 0;
                bool chip = false;
                while (iChipWaitTime >= iCycleCount)
                {
                    srFile = new StreamReader("C:\\Program Files\\OMA Emirates\\NanoPerso\\EmbossingDLLs\\Row.chp");
                    sline = srFile.ReadLine();
                    srFile.Close();

                    if (sline.IndexOf("NotPerso") == 3)
                    {
                        //Chip Not Perso
                        //Loop Continue after 3 Sec
                        if ((iChipWaitTime - iCycleCount) >= 3000)
                        {
                            iCycleCount = iCycleCount + 3000;
                            Thread.Sleep(3000);
                        }
                        //Time Out
                        else if ((iChipWaitTime - iCycleCount) == 0)
                            break;
                        //Time left less then 3 Sec, Loop Continue after left Sec.
                        else
                        {
                            iCycleCount = iCycleCount + (iChipWaitTime - iCycleCount);
                            Thread.Sleep(iChipWaitTime - iCycleCount);
                        }
                    }
                    else if (sline.IndexOf("No Error") == 3)
                    {
                        //sucess
                        chip = true;
                        rc = 0;
                        break;
                    }
                    else
                    {
                        //Chip Failed
                        sMsg = "Failed : " + sline.Substring(3, 8);
                        break;
                    }
                }

                if (!chip && sMsg == "")
                    sMsg = "Failed : Time out";
                return rc;
            }
            catch (Exception ex)
            {
                sMsg = "Failed : Exception Occurred : \n" + ex.ToString() + "\n" + ex.StackTrace;
                return rc;
            }
        }

		private void button2_Click_1(object sender, EventArgs e)
		{
			
			SqlConnection cn = DBConnection.getConnection();
			SqlCommand cmd = new SqlCommand();
			cmd.Connection = cn;
			cn.Open();
			cmd.CommandType = CommandType.StoredProcedure;
			cmd.CommandText = "proc_print_mlc";
			SqlDataAdapter dataAdapter = new SqlDataAdapter();
			dataAdapter.SelectCommand = cmd;
			DataTable table = new DataTable();
			dataAdapter.Fill(table);
		}

		private void button3_Click_1(object sender, EventArgs e)
		{
			 bool retresult = objRio.Reset();
            if (retresult)
            {
                MessageBox.Show("Printer Reset Successfully");
            }
            else
            {
                MessageBox.Show("Printer Reset Failed");
            }
            SDKReturn = SDK.ID_CloseSession(hSession);
        }

		private void button4_Click(object sender, EventArgs e)
		{
            
          bool eject=  objRio.EjectCard();
            if (eject)
            {
                MessageBox.Show("Eject Successfully");
            }
		}

		private void comboBox2_SelectedIndexChanged(object sender, EventArgs e)
		{
			if (comboBox2.SelectedItem.ToString() == "Select")
			{
				//btn_getDB.Visible = false;
				//txt_DBServer.Visible = false;
				//cb_database.Items.Clear();
			}

			else if (comboBox2.SelectedItem.ToString() == "Other")
			{
				//btn_getDB.Visible = true;
				//txt_DBServer.Visible = true;
				//cb_database.Items.Clear();
			}
			else
			{
				//btn_getDB.Visible = true;
				//cb_database.Items.Clear();
			}
		}
		public void Check_DB()
		{
			List<string> list = new List<string>();
			string datasource = string.Empty;
			
			try
			{
				if (comboBox2.SelectedItem.ToString() == "Other")
				{ }
					//datasource = txt_DBServer.Text;
				else
					datasource = comboBox2.SelectedItem.ToString();

				string conString = "Data Source=" + datasource + ";User Id=NcxPerso;" + "Password=NcxPerso;Integrated Security=false;";

				using (SqlConnection con = new SqlConnection(conString))
				{
					con.Open();
					using (SqlCommand cmd = new SqlCommand("SELECT name from sys.databases", con))
					{
						using (IDataReader dr = cmd.ExecuteReader())
						{
							while (dr.Read())
							{
								list.Add(dr[0].ToString());
							}
						}
					}
				}
				comboBox3.DataSource = list;
				
			}
			catch (Exception ex)
			{
				MessageBox.Show(ex.Message);
			}

		}

		private void comboBox3_SelectedIndexChanged(object sender, EventArgs e)
		{
			List<string> list = new List<string>();
			string datasource = string.Empty;
			DataTable PsD = new DataTable();
			SqlDataReader dr;
			SqlCommand cmd = new SqlCommand();

			if (comboBox2.SelectedItem.ToString() == "Other")
			{ }
			//datasource = txt_DBServer.Text;
			else
				datasource = comboBox2.SelectedItem.ToString();
			string conString = "Initial Catalog=" + comboBox3.SelectedItem.ToString() + ";Data Source=" + datasource + ";User Id=NcxPerso;" + "Password=NcxPerso;Integrated Security=false;";

			using (SqlConnection con = new SqlConnection(conString))
			{
				try
				{
					con.Open();
					cmd = new SqlCommand();
					cmd.Connection = con;
					cmd.CommandType = CommandType.StoredProcedure;
					cmd.CommandText = "MLC_MULTICARDDATA";
					cmd.Parameters.AddWithValue("@CardNo", "");
					cmd.Parameters.AddWithValue("@BRANCHID", DBNull.Value);
					cmd.Parameters.AddWithValue("@STATIONID", DBNull.Value);
					cmd.Parameters.AddWithValue("@PHOTOFLAG", DBNull.Value);
					cmd.Parameters.AddWithValue("@SIGNFLAG", DBNull.Value);
					cmd.Parameters.AddWithValue("@PRODUCTCODE", DBNull.Value);
					cmd.Parameters.AddWithValue("@PLASTICCODE", DBNull.Value);
					dr = cmd.ExecuteReader();
					PsD.Load(dr);
					con.Close();
				}
				catch (Exception)
				{

					// throw;
				}
				//  return PsD; 

			}
			dgv_Records.DataSource = PsD;
		}

		private void button5_Click(object sender, EventArgs e)
		{
			Check_DB();
		}

		private void dgv_Records_CellContentClick(object sender, DataGridViewCellEventArgs e)
		{
			string card_number = string.Empty;
			if (e.ColumnIndex == 0)
			{
				card_number = dgv_Records.Rows[e.RowIndex].Cells[0].Value.ToString();
				txt_CardNumber.Text = card_number.Substring(0, 4) + " " + card_number.Substring(4, 4) + " " + card_number.Substring(8, 4) + " " + card_number.Substring(12, 4);
				txt_Valid.Text = dgv_Records.Rows[e.RowIndex].Cells[2].Value.ToString();
				txt_Exp.Text = dgv_Records.Rows[e.RowIndex].Cells[3].Value.ToString();
				txt_Name.Text = dgv_Records.Rows[e.RowIndex].Cells[1].Value.ToString();
				txt_CVV.Text = dgv_Records.Rows[e.RowIndex].Cells[4].Value.ToString();
				txt_Track1.Text = dgv_Records.Rows[e.RowIndex].Cells[5].Value.ToString();
				txt_Track2.Text = dgv_Records.Rows[e.RowIndex].Cells[6].Value.ToString();
				// MessageBox.Show(dgv_Records.Rows[e.RowIndex].Cells[0].Value.ToString());
				tabControl1.SelectedTab = tabPage3;
			}
		}

		private void button2_Click(object sender, EventArgs e)
        {
            /////////////track1 encoding///////////////////////
            //string t1 = "B4893281508693126^ABUSHAHLA/MOHAMMED K H    ^2005226137480000000000444000000";
            //string t = "*******";
            //t1 = t1.Remove(7,t.Length);
            //t1 = t1.Insert(7, t);
            //string t2 = t1.Remove(30, t.Length);
            //t2 = t2.Insert(30, t);
            //string t3 = t2.Remove(47, t.Length);
            //t3 = t3.Insert(47, t);
            ///////////////track2 encoding///////////////////////
            //string r = "5360280000000201=17062260000010000429";
            //r = r.Remove(6, t.Length);
            //r = r.Insert(6, t);
            //string a = r.Remove(20, t.Length);
            //a = a.Insert(20, t);
            //MessageBox.Show("Track1:  " + t3 + "\nTrack2:  " + a);
            string track1 = "1234567890123456";
            int l = track1.Length;
            string track2 = "5360280000000201=17062260000010000429";
            // Split string on spaces.
            // ... This will separate all the words.
            string[] track1_value = track1.Split('^');
            string[] track2_value = track2.Split('=');
            string card=string.Empty;
            string name = string.Empty;
            string extra = string.Empty;
            string card1 = string.Empty;
            string extra2 = string.Empty;
            foreach (string word in track1_value)
            {
               card = track1_value[0].Substring(0, 7) + "** ****" + track1_value[0].Substring(13, 4);// +"^";
               // name = track1_value[1].Substring(0, 8) + "** ****" + track1_value[1].Substring(16, 4) + "^";
               // extra = track1_value[2].Substring(0, 12) + "** ****" + track1_value[2].Substring(13, 4);         
            }
            foreach (var word1 in track2_value) 
            {
                card1  = track2_value[0].Substring(0, 7) + "** ****" + track2_value[0].Substring(10, 4) + "=";
                extra2 = track2_value[1].Substring(0, 7) + "** ****" + track2_value[1].Substring(13, 4);
            }
            MessageBox.Show("Track1 Value: " + card + name + extra + " Track2 Value : " + card1 + extra2);
        }
      //
        public void GetLastMessage()
        {
            string InfoMsgBox = string.Empty;
            StringBuilder Temp = new StringBuilder();
            SDK.Return SDKReturn = SDK.ID_LastMessage(hSession, Temp);
            if (SDKReturn != SDK.Return.Success)
            {
                HandleError("GetLastMessage", SDKReturn);
            }
            else
            {
                foreach (char c in Temp.ToString())
                {
                  //  createerrorlog(c == '\n' ? Environment.NewLine : c.ToString());
                }
               // createerrorlog(Environment.NewLine);
               // createerrorlog(Environment.NewLine);
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            GetLastMessage();
        }
    }
}
