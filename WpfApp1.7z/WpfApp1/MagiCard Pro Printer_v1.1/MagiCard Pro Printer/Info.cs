﻿/***************************************************************************/
/**                                                                       **/
/**                               MAGICARD                                **/
/**                                                                       **/
/***************************************************************************/
/**                                                                       **/
/**  PROJECT      : SDK C# Demo - DTC Printers                            **/
/**                                                                       **/
/**  MODULE NAME  : Info.cs                                               **/
/**                                                                       **/
/**  COPYRIGHT    : Magicard                                              **/
/**                                                                       **/
/***************************************************************************/
using System;
using System.Text;
using System.Windows.Forms;
using System.Collections.Generic;
using SDKShim;

namespace CSharpDemo
{
    public partial class SDK_CSDemo : Form
    {
        #region === Local Methods ===

        private void InitInfoTab()
        {
            InitPasswordBox();
        }

        private void ClearMsgBoxButton_Click(object sender, EventArgs e)
        {
            InfoMsgBox.Clear();
        }

        private bool PrinterIsReady()
        {
            return (SDK.ID_PrinterStatus(hSession) == SDK.PrinterStatus.Ready);
        }

        #endregion

        //----------------------------------------------------------------------

        #region === LastMessage ===

        private void LastMessageButton_Click(object sender, EventArgs e)
        {
            StringBuilder Temp = new StringBuilder();
            SDK.Return SDKReturn = SDK.ID_LastMessage(hSession, Temp);
            if (SDKReturn != SDK.Return.Success)
            {
                HandleError("GetLastMessage", SDKReturn);
            }
            else
            {
                foreach (char c in Temp.ToString())
                {
                    InfoMsgBox.AppendText(c == '\n' ? Environment.NewLine : c.ToString());
                }
                InfoMsgBox.AppendText(Environment.NewLine);
                InfoMsgBox.AppendText(Environment.NewLine);
            }
        }

        #endregion

        //----------------------------------------------------------------------

        #region === PrinterInfo ===

        private void PrinterInfoButton_Click(object sender, EventArgs e)
        {
            Cursor.Current = Cursors.WaitCursor;

            SDK.PrinterInfo PrinterInfo = new SDK.PrinterInfo();
            SDK.Return SDKReturn = SDK.ID_PrinterInfo(hSession, PrinterInfo);
            if (SDKReturn != SDK.Return.Success)
            {
                HandleError("PrinterInfo", SDKReturn);
            }
            else
            {
                InfoMsgBox.AppendText("PrinterConnected: " + PrinterInfo.bPrinterConnected + Environment.NewLine);
                InfoMsgBox.AppendText("Model No.: " + PrinterInfo.eModel + Environment.NewLine);
                InfoMsgBox.AppendText("Model: " + PrinterInfo.sModel + Environment.NewLine);
                InfoMsgBox.AppendText("PrinterSerial: " + PrinterInfo.sPrinterSerial + Environment.NewLine);
                InfoMsgBox.AppendText("PrintheadSerial: " + PrinterInfo.sPrintheadSerial + Environment.NewLine);
                InfoMsgBox.AppendText("PCBSerial: " + PrinterInfo.sPCBSerial + Environment.NewLine);
                InfoMsgBox.AppendText("FirmwareVersion: " + PrinterInfo.Firmware.Version + Environment.NewLine);

                InfoMsgBox.AppendText("Printhead: ");
                switch (PrinterInfo.ePrintheadType)
                {
                    case 0: InfoMsgBox.AppendText("KGE2" + Environment.NewLine); break;
                    case 1: InfoMsgBox.AppendText("KEE1" + Environment.NewLine); break;
                    case 2: InfoMsgBox.AppendText("KEE4" + Environment.NewLine); break;
                    default: InfoMsgBox.AppendText("Unknown" + Environment.NewLine); break;
                }

                InfoMsgBox.AppendText("Density: " + PrinterInfo.iDensity + Environment.NewLine);
                InfoMsgBox.AppendText("HandFeed: "
                                      + handfeedkp[(PrinterInfo.iHandFeed != 0) ? SDK.HandFeed.On : SDK.HandFeed.Off]
                                      + Environment.NewLine);
                InfoMsgBox.AppendText("CardsPrinted: " + PrinterInfo.iCardsPrinted + Environment.NewLine);
                InfoMsgBox.AppendText("CardsOnPrinthead: " + PrinterInfo.iCardsOnPrinthead + Environment.NewLine);
                InfoMsgBox.AppendText("DyePanelsPrinted: " + PrinterInfo.iDyePanelsPrinted + Environment.NewLine);
                InfoMsgBox.AppendText("CleansSinceShipped: " + PrinterInfo.iCleansSinceShipped + Environment.NewLine);
                InfoMsgBox.AppendText("DyePanelsSinceClean: " + PrinterInfo.iDyePanelsSinceClean + Environment.NewLine);
                InfoMsgBox.AppendText("CardsSinceClean: " + PrinterInfo.iCardsSinceClean + Environment.NewLine);
                InfoMsgBox.AppendText("CardsBetweenCleans: " + PrinterInfo.iCardsBetweenCleans + Environment.NewLine);

                InfoMsgBox.AppendText("PrintHeadPosn: " + PrinterInfo.iPrintHeadPosn + Environment.NewLine);
                InfoMsgBox.AppendText("ImageStartPosn: " + PrinterInfo.iImageStartPosn + Environment.NewLine);
                InfoMsgBox.AppendText("ImageEndPosn: " + PrinterInfo.iImageEndPosn + Environment.NewLine);
                InfoMsgBox.AppendText("MajorError: " + PrinterInfo.iMajorError + Environment.NewLine);
                InfoMsgBox.AppendText("MinorError: " + PrinterInfo.iMinorError + Environment.NewLine);

                InfoMsgBox.AppendText("TagUID: " + PrinterInfo.sTagUID + Environment.NewLine);
                InfoMsgBox.AppendText("ShotsOnFilm: " + PrinterInfo.iShotsOnFilm + Environment.NewLine);
                InfoMsgBox.AppendText("ShotsUsed: " + PrinterInfo.iShotsUsed + Environment.NewLine);
                InfoMsgBox.AppendText("DyeFilmType " + PrinterInfo.sDyeFilmType + Environment.NewLine);
                InfoMsgBox.AppendText("ColourLength: " + PrinterInfo.iColourLength + Environment.NewLine);
                InfoMsgBox.AppendText("ResinLength: " + PrinterInfo.iResinLength + Environment.NewLine);
                InfoMsgBox.AppendText("OvercoatLength: " + PrinterInfo.iOvercoatLength + Environment.NewLine);
                InfoMsgBox.AppendText("DyeFlags: " + PrinterInfo.eDyeFlags + Environment.NewLine);
                InfoMsgBox.AppendText("CommandCode: " + PrinterInfo.iCommandCode + Environment.NewLine);
                InfoMsgBox.AppendText("DOB: " + PrinterInfo.iDOB + Environment.NewLine);
                InfoMsgBox.AppendText("DyeFilmManuf: " + PrinterInfo.eDyeFilmManuf + Environment.NewLine);
                InfoMsgBox.AppendText("DyeFilmProg: " + PrinterInfo.eDyeFilmProg + Environment.NewLine);

                String temp_string;
                if (PrinterInfo.iBitFields.HasFlag(SDK.InfoMask.EncodePlaten))
                    temp_string = smartmodekp[SDK.SmartMode.Platen];
                else if (PrinterInfo.iBitFields.HasFlag(SDK.InfoMask.EncodeXLI))
                    temp_string = smartmodekp[SDK.SmartMode.XLI];
                else
                    temp_string = smartmodekp[SDK.SmartMode.Default];
                InfoMsgBox.AppendText("SmartMode: " + temp_string + Environment.NewLine);

                InfoMsgBox.AppendText("SmartOffset: " + PrinterInfo.iSmartOffset + Environment.NewLine);

                if (PrinterInfo.iBitFields.HasFlag(SDK.InfoMask.EjectMode))
                    temp_string = ejectmodekp[SDK.EjectMode.On];
                else
                    temp_string = ejectmodekp[SDK.EjectMode.Off];
                InfoMsgBox.AppendText("EjectMode: " + temp_string + Environment.NewLine);

                if (PrinterInfo.iBitFields.HasFlag(SDK.InfoMask.HorzEject))
                    temp_string = horzejectkp[SDK.HorzEject.On];
                else
                    temp_string = horzejectkp[SDK.HorzEject.Off];
                InfoMsgBox.AppendText("HorzEject: " + temp_string + Environment.NewLine);

                if (PrinterInfo.iBitFields.HasFlag(SDK.InfoMask.EraseSpeed))
                    temp_string = erasespeedkp[SDK.EraseSpeed.Quick];
                else
                    temp_string = erasespeedkp[SDK.EraseSpeed.Thorough];
                InfoMsgBox.AppendText("EraseSpeed: " + temp_string + Environment.NewLine + Environment.NewLine);
            }

            Cursor.Current = Cursors.Default;
        }

        #endregion

        //----------------------------------------------------------------------

        #region === Printer Status ===

        private void PrinterStatusButton_Click(object sender, EventArgs e)
        {
            string msg;
            switch (SDK.ID_PrinterStatus(hSession))
            {
                case SDK.PrinterStatus.Ready: msg = "Printer is READY"; break;
                case SDK.PrinterStatus.Offline: msg = "Printer is OFFLINE"; break;
                case SDK.PrinterStatus.Error: msg = "Printer is in ERROR"; break;
                default: msg = "Unknown Printer Status"; break;
            }
            InfoMsgBox.AppendText(msg + Environment.NewLine);
            InfoMsgBox.AppendText(Environment.NewLine);
        }

        #endregion

        //----------------------------------------------------------------------

        #region === SDK Version ===

        private void SDKVersionButton_Click(object sender, EventArgs e)
        {
            SDK.SDKVersion SDKVersion = new SDK.SDKVersion();

            SDK.Return SDKReturn = SDK.ID_SDKVersion(hSession, SDKVersion);
            if (SDKReturn != SDK.Return.Success)
            {
                HandleError("SDKVersion", SDKReturn);
            }
            else
            {
                InfoMsgBox.AppendText("Version: " + SDKVersion.Major
                                      + "." + SDKVersion.Minor
                                      + "." + SDKVersion.Build
                                      + "." + SDKVersion.Private
                                      + Environment.NewLine);
                InfoMsgBox.AppendText(Environment.NewLine);
            }
        }

        #endregion

        //----------------------------------------------------------------------

        #region === Connection Type ===

        private void ConnectionTypeButton_Click(object sender, EventArgs e)
        {
            string msg;
            switch (SDK.ID_ConnectionType(hSession))
            {
                case SDK.ConnectionType.USB: msg = "USB"; break;
                case SDK.ConnectionType.Ethernet: msg = "Ethernet"; break;
                case SDK.ConnectionType.File: msg = "File"; break;
                default: msg = "Unknown"; break;
            }
            InfoMsgBox.AppendText("Connection Type: " + msg + Environment.NewLine);
            InfoMsgBox.AppendText(Environment.NewLine);
        }

        #endregion

        //----------------------------------------------------------------------

        #region === Printer Model ===

        private void PrinterModelButton_Click(object sender, EventArgs e)
        {
            if ((SDK.ID_PrinterType(hSession) != SDK.PrinterType.Enduro)
            && (SDK.ID_PrinterType(hSession) != SDK.PrinterType.Helix))
            {
                MessageBox.Show("Only Valid for Enduro & Helix Family Printers",
                                "Invalid Printer",
                                MessageBoxButtons.OK);
            }
            else
            {
                string msg;
                SDK.Model model = (SDK.Model)SDK.ID_PrinterModel(hSession);
                if (model.HasFlag(SDK.Model.Pronto))
                    msg = "Pronto";
                else if (model.HasFlag(SDK.Model.RioPro))
                    msg = "Rio Pro";
                else if (model.HasFlag(SDK.Model.Helix))
                    msg = "Helix";
                else
                    msg = "Enduro";
                InfoMsgBox.AppendText("Printer - " + msg + Environment.NewLine);

                InfoMsgBox.AppendText("Capability:" + Environment.NewLine);
                if (model.HasFlag(SDK.Model.Fn_Magnetic))
                    InfoMsgBox.AppendText("MagStripe" + Environment.NewLine);
                if (model.HasFlag(SDK.Model.Fn_Duplex))
                    InfoMsgBox.AppendText("Duplex" + Environment.NewLine);
                if (model.HasFlag(SDK.Model.Fn_Rewrite))
                    InfoMsgBox.AppendText("Rewrite" + Environment.NewLine);
                if (model.HasFlag(SDK.Model.Fn_Chip))
                    InfoMsgBox.AppendText("Chip Encoding" + Environment.NewLine);
                if (model.HasFlag(SDK.Model.Fn_Contactless))
                    InfoMsgBox.AppendText("Contactless Encoding" + Environment.NewLine);
                if (model.HasFlag(SDK.Model.Fn_Extended))
                    InfoMsgBox.AppendText("Extended" + Environment.NewLine);
                if (model.HasFlag(SDK.Model.Fn_Ethernet))
                    InfoMsgBox.AppendText("Ethernet" + Environment.NewLine);
                if (model.HasFlag(SDK.Model.Fn_Laminate))
                    InfoMsgBox.AppendText("Laminator" + Environment.NewLine);

                InfoMsgBox.AppendText(Environment.NewLine);
            }
        }
        #endregion

        //----------------------------------------------------------------------

        #region === Printer Model ===

        private void SDKBitsButton_Click(object sender, EventArgs e)
        {
            InfoMsgBox.AppendText(SDK.ID_SDKBits() + " Bit SDK" + Environment.NewLine + Environment.NewLine);
        }
        #endregion

        //----------------------------------------------------------------------

        #region === Password ===

        private void PasswordBox_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (((KeyValuePair<SDK.Password, string>)PasswordBox.SelectedItem).Key == SDK.Password.Use)
            {
                Password2Label.Enabled = false;
                Password2.Enabled = false;
            }
            else
            {
                Password2Label.Enabled = true;
                Password2.Enabled = true;
            }
        }

        Dictionary<SDK.Password, string> passwordcmdkp = new Dictionary<SDK.Password, string>()
        {
            {SDK.Password.Set, "Set"},
            {SDK.Password.Use, "Use"},
        };

        private void InitPasswordBox()
        {
            PasswordBox.DataSource = new BindingSource(passwordcmdkp, null);
            PasswordBox.DisplayMember = "Value";
            PasswordBox.SelectedItem = SDK.Password.Set;
        }

        private void PasswordButton_Click(object sender, EventArgs e)
        {
            SDK.Password PasswordCmd = ((KeyValuePair<SDK.Password, string>)PasswordBox.SelectedItem).Key;

            SDK.Return SDKReturn = SDK.ID_Password(hSession, PasswordCmd, Password1.Text, Password2.Text);
            if (SDKReturn != SDK.Return.Success)
            {
                HandleError("Password", SDKReturn);
            }
        }
        #endregion
    }
}
