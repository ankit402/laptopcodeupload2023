﻿namespace MagiCard_Pro_Printer
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.tabPage3 = new System.Windows.Forms.TabPage();
            this.richTextBox1 = new System.Windows.Forms.RichTextBox();
            this.button4 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.button3 = new System.Windows.Forms.Button();
            this.SmartModeBox = new System.Windows.Forms.ComboBox();
            this.EncodingTypeBox = new System.Windows.Forms.ComboBox();
            this.T1_BPCBox = new System.Windows.Forms.ComboBox();
            this.CoercivityBox = new System.Windows.Forms.ComboBox();
            this.T1_BPIBox = new System.Windows.Forms.ComboBox();
            this.T1_ParityBox = new System.Windows.Forms.ComboBox();
            this.button1 = new System.Windows.Forms.Button();
            this.T1_LRCBox = new System.Windows.Forms.ComboBox();
            this.T2_BPCBox = new System.Windows.Forms.ComboBox();
            this.T2_BPIBox = new System.Windows.Forms.ComboBox();
            this.T2_ParityBox = new System.Windows.Forms.ComboBox();
            this.T2_LRCBox = new System.Windows.Forms.ComboBox();
            this.groupBox4 = new System.Windows.Forms.GroupBox();
            this.label16 = new System.Windows.Forms.Label();
            this.cvvsize = new System.Windows.Forms.NumericUpDown();
            this.exprysize = new System.Windows.Forms.NumericUpDown();
            this.validsize = new System.Windows.Forms.NumericUpDown();
            this.namesize = new System.Windows.Forms.NumericUpDown();
            this.cvvy = new System.Windows.Forms.NumericUpDown();
            this.cvvx = new System.Windows.Forms.NumericUpDown();
            this.expryy = new System.Windows.Forms.NumericUpDown();
            this.expryx = new System.Windows.Forms.NumericUpDown();
            this.validy = new System.Windows.Forms.NumericUpDown();
            this.validx = new System.Windows.Forms.NumericUpDown();
            this.namey = new System.Windows.Forms.NumericUpDown();
            this.namex = new System.Windows.Forms.NumericUpDown();
            this.cardnosize = new System.Windows.Forms.NumericUpDown();
            this.label125 = new System.Windows.Forms.Label();
            this.txt_CardNumber = new System.Windows.Forms.TextBox();
            this.TextFrontYUpDown = new System.Windows.Forms.NumericUpDown();
            this.label126 = new System.Windows.Forms.Label();
            this.TextFrontXUpDown = new System.Windows.Forms.NumericUpDown();
            this.label127 = new System.Windows.Forms.Label();
            this.label128 = new System.Windows.Forms.Label();
            this.MagDataEnabled = new System.Windows.Forms.CheckBox();
            this.label5 = new System.Windows.Forms.Label();
            this.txt_CVV = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.lblcvv = new System.Windows.Forms.Label();
            this.txt_Track2 = new System.Windows.Forms.TextBox();
            this.txt_Exp = new System.Windows.Forms.TextBox();
            this.txt_Track1 = new System.Windows.Forms.TextBox();
            this.txt_Valid = new System.Windows.Forms.TextBox();
            this.txt_Name = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.PrintButton = new System.Windows.Forms.Button();
            this.TextFrontColourBox = new System.Windows.Forms.ComboBox();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.dgv_Records = new System.Windows.Forms.DataGridView();
            this.button5 = new System.Windows.Forms.Button();
            this.comboBox3 = new System.Windows.Forms.ComboBox();
            this.comboBox2 = new System.Windows.Forms.ComboBox();
            this.textBox6 = new System.Windows.Forms.TextBox();
            this.db_password = new System.Windows.Forms.TextBox();
            this.label17 = new System.Windows.Forms.Label();
            this.db_user = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.flowLayoutPanel1 = new System.Windows.Forms.FlowLayoutPanel();
            this.OpenSessionButton = new System.Windows.Forms.Button();
            this.EjectCardButton = new System.Windows.Forms.Button();
            this.FlipCardButton = new System.Windows.Forms.Button();
            this.PrintTestCardButton = new System.Windows.Forms.Button();
            this.FeedCardButton = new System.Windows.Forms.Button();
            this.RestartButton = new System.Windows.Forms.Button();
            this.label12 = new System.Windows.Forms.Label();
            this.SessionConfigBox = new System.Windows.Forms.ComboBox();
            this.PrinterMsgBox = new System.Windows.Forms.TextBox();
            this.FeedCardBox = new System.Windows.Forms.ComboBox();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.ClearPrinterMsgButton = new System.Windows.Forms.Button();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.HandFeedBox = new System.Windows.Forms.ComboBox();
            this.HorzEjectBox = new System.Windows.Forms.ComboBox();
            this.HorzEjectButton = new System.Windows.Forms.Button();
            this.HandFeedButton = new System.Windows.Forms.Button();
            this.label11 = new System.Windows.Forms.Label();
            this.PrinterSetRadio = new System.Windows.Forms.RadioButton();
            this.PrinterGetRadio = new System.Windows.Forms.RadioButton();
            this.groupBox7 = new System.Windows.Forms.GroupBox();
            this.IPGatewayLabel = new System.Windows.Forms.Label();
            this.IPSubnetLabel = new System.Windows.Forms.Label();
            this.IPAddrLabel = new System.Windows.Forms.Label();
            this.IPGatewayBox = new System.Windows.Forms.TextBox();
            this.IPSubnetBox = new System.Windows.Forms.TextBox();
            this.IPAddrBox = new System.Windows.Forms.TextBox();
            this.IPSettingsButton = new System.Windows.Forms.Button();
            this.IPModeLabel = new System.Windows.Forms.Label();
            this.IPModeBox = new System.Windows.Forms.ComboBox();
            this.SmartOffsetBox = new System.Windows.Forms.NumericUpDown();
            this.SmartOffsetButton = new System.Windows.Forms.Button();
            this.SmartModeButton = new System.Windows.Forms.Button();
            this.comboBox1 = new System.Windows.Forms.ComboBox();
            this.EraseSpeedButton = new System.Windows.Forms.Button();
            this.EraseSpeedBox = new System.Windows.Forms.ComboBox();
            this.EjectModeButton = new System.Windows.Forms.Button();
            this.EjectModeBox = new System.Windows.Forms.ComboBox();
            this.Get_Info = new System.Windows.Forms.Button();
            this.label8 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.tabPage4 = new System.Windows.Forms.TabPage();
            this.btn_ChipTest = new System.Windows.Forms.Button();
            this.textBox4 = new System.Windows.Forms.TextBox();
            this.label10 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.textBox3 = new System.Windows.Forms.TextBox();
            this.tabControl1.SuspendLayout();
            this.tabPage3.SuspendLayout();
            this.groupBox4.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.cvvsize)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.exprysize)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.validsize)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.namesize)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.cvvy)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.cvvx)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.expryy)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.expryx)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.validy)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.validx)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.namey)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.namex)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.cardnosize)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.TextFrontYUpDown)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.TextFrontXUpDown)).BeginInit();
            this.tabPage1.SuspendLayout();
            this.groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgv_Records)).BeginInit();
            this.flowLayoutPanel1.SuspendLayout();
            this.tabPage2.SuspendLayout();
            this.groupBox3.SuspendLayout();
            this.groupBox7.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.SmartOffsetBox)).BeginInit();
            this.tabPage4.SuspendLayout();
            this.SuspendLayout();
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.tabPage3);
            this.tabControl1.Controls.Add(this.tabPage1);
            this.tabControl1.Controls.Add(this.tabPage2);
            this.tabControl1.Controls.Add(this.tabPage4);
            this.tabControl1.Location = new System.Drawing.Point(12, 0);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(549, 467);
            this.tabControl1.TabIndex = 2;
            // 
            // tabPage3
            // 
            this.tabPage3.Controls.Add(this.richTextBox1);
            this.tabPage3.Controls.Add(this.button4);
            this.tabPage3.Controls.Add(this.button2);
            this.tabPage3.Controls.Add(this.button3);
            this.tabPage3.Controls.Add(this.SmartModeBox);
            this.tabPage3.Controls.Add(this.EncodingTypeBox);
            this.tabPage3.Controls.Add(this.T1_BPCBox);
            this.tabPage3.Controls.Add(this.CoercivityBox);
            this.tabPage3.Controls.Add(this.T1_BPIBox);
            this.tabPage3.Controls.Add(this.T1_ParityBox);
            this.tabPage3.Controls.Add(this.button1);
            this.tabPage3.Controls.Add(this.T1_LRCBox);
            this.tabPage3.Controls.Add(this.T2_BPCBox);
            this.tabPage3.Controls.Add(this.T2_BPIBox);
            this.tabPage3.Controls.Add(this.T2_ParityBox);
            this.tabPage3.Controls.Add(this.T2_LRCBox);
            this.tabPage3.Controls.Add(this.groupBox4);
            this.tabPage3.Controls.Add(this.PrintButton);
            this.tabPage3.Controls.Add(this.TextFrontColourBox);
            this.tabPage3.Location = new System.Drawing.Point(4, 22);
            this.tabPage3.Name = "tabPage3";
            this.tabPage3.Size = new System.Drawing.Size(541, 441);
            this.tabPage3.TabIndex = 2;
            this.tabPage3.Text = "Printing Test";
            this.tabPage3.UseVisualStyleBackColor = true;
            // 
            // richTextBox1
            // 
            this.richTextBox1.Location = new System.Drawing.Point(3, 286);
            this.richTextBox1.Name = "richTextBox1";
            this.richTextBox1.Size = new System.Drawing.Size(530, 147);
            this.richTextBox1.TabIndex = 108;
            this.richTextBox1.Text = "Note: Please Install Printer on System and connect over USB mode, Then Go to Devi" +
    "ce and Printers to select Default Pritner for printing.    ";
            // 
            // button4
            // 
            this.button4.Location = new System.Drawing.Point(320, 255);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(90, 24);
            this.button4.TabIndex = 107;
            this.button4.Text = "EjectCard";
            this.button4.UseVisualStyleBackColor = true;
            this.button4.Click += new System.EventHandler(this.button4_Click);
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(506, 329);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(27, 23);
            this.button2.TabIndex = 105;
            this.button2.Text = "Load Data";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Visible = false;
            this.button2.Click += new System.EventHandler(this.button2_Click_1);
            // 
            // button3
            // 
            this.button3.Location = new System.Drawing.Point(224, 256);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(90, 24);
            this.button3.TabIndex = 106;
            this.button3.Text = "Reset Printer";
            this.button3.UseVisualStyleBackColor = true;
            this.button3.Click += new System.EventHandler(this.button3_Click_1);
            // 
            // SmartModeBox
            // 
            this.SmartModeBox.FormattingEnabled = true;
            this.SmartModeBox.Location = new System.Drawing.Point(506, 412);
            this.SmartModeBox.Name = "SmartModeBox";
            this.SmartModeBox.Size = new System.Drawing.Size(28, 21);
            this.SmartModeBox.TabIndex = 104;
            this.SmartModeBox.Visible = false;
            // 
            // EncodingTypeBox
            // 
            this.EncodingTypeBox.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.EncodingTypeBox.Location = new System.Drawing.Point(439, 385);
            this.EncodingTypeBox.Name = "EncodingTypeBox";
            this.EncodingTypeBox.Size = new System.Drawing.Size(30, 21);
            this.EncodingTypeBox.TabIndex = 99;
            this.EncodingTypeBox.Visible = false;
            // 
            // T1_BPCBox
            // 
            this.T1_BPCBox.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.T1_BPCBox.Location = new System.Drawing.Point(449, 412);
            this.T1_BPCBox.Name = "T1_BPCBox";
            this.T1_BPCBox.Size = new System.Drawing.Size(20, 21);
            this.T1_BPCBox.TabIndex = 43;
            this.T1_BPCBox.Visible = false;
            // 
            // CoercivityBox
            // 
            this.CoercivityBox.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.CoercivityBox.Location = new System.Drawing.Point(445, 358);
            this.CoercivityBox.Name = "CoercivityBox";
            this.CoercivityBox.Size = new System.Drawing.Size(24, 21);
            this.CoercivityBox.TabIndex = 100;
            this.CoercivityBox.Visible = false;
            // 
            // T1_BPIBox
            // 
            this.T1_BPIBox.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.T1_BPIBox.Location = new System.Drawing.Point(475, 331);
            this.T1_BPIBox.Name = "T1_BPIBox";
            this.T1_BPIBox.Size = new System.Drawing.Size(25, 21);
            this.T1_BPIBox.TabIndex = 44;
            this.T1_BPIBox.Visible = false;
            // 
            // T1_ParityBox
            // 
            this.T1_ParityBox.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.T1_ParityBox.Location = new System.Drawing.Point(506, 304);
            this.T1_ParityBox.Name = "T1_ParityBox";
            this.T1_ParityBox.Size = new System.Drawing.Size(24, 21);
            this.T1_ParityBox.TabIndex = 45;
            this.T1_ParityBox.Visible = false;
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(116, 256);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(102, 23);
            this.button1.TabIndex = 103;
            this.button1.Text = "Mag Encode";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // T1_LRCBox
            // 
            this.T1_LRCBox.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.T1_LRCBox.Location = new System.Drawing.Point(506, 385);
            this.T1_LRCBox.Name = "T1_LRCBox";
            this.T1_LRCBox.Size = new System.Drawing.Size(27, 21);
            this.T1_LRCBox.TabIndex = 46;
            this.T1_LRCBox.Visible = false;
            // 
            // T2_BPCBox
            // 
            this.T2_BPCBox.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.T2_BPCBox.Location = new System.Drawing.Point(475, 412);
            this.T2_BPCBox.Name = "T2_BPCBox";
            this.T2_BPCBox.Size = new System.Drawing.Size(25, 21);
            this.T2_BPCBox.TabIndex = 47;
            this.T2_BPCBox.Visible = false;
            // 
            // T2_BPIBox
            // 
            this.T2_BPIBox.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.T2_BPIBox.Location = new System.Drawing.Point(475, 304);
            this.T2_BPIBox.Name = "T2_BPIBox";
            this.T2_BPIBox.Size = new System.Drawing.Size(25, 21);
            this.T2_BPIBox.TabIndex = 48;
            this.T2_BPIBox.Visible = false;
            // 
            // T2_ParityBox
            // 
            this.T2_ParityBox.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.T2_ParityBox.Location = new System.Drawing.Point(475, 385);
            this.T2_ParityBox.Name = "T2_ParityBox";
            this.T2_ParityBox.Size = new System.Drawing.Size(25, 21);
            this.T2_ParityBox.TabIndex = 49;
            this.T2_ParityBox.Visible = false;
            // 
            // T2_LRCBox
            // 
            this.T2_LRCBox.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.T2_LRCBox.Location = new System.Drawing.Point(506, 358);
            this.T2_LRCBox.Name = "T2_LRCBox";
            this.T2_LRCBox.Size = new System.Drawing.Size(27, 21);
            this.T2_LRCBox.TabIndex = 50;
            this.T2_LRCBox.Visible = false;
            // 
            // groupBox4
            // 
            this.groupBox4.Controls.Add(this.label16);
            this.groupBox4.Controls.Add(this.cvvsize);
            this.groupBox4.Controls.Add(this.exprysize);
            this.groupBox4.Controls.Add(this.validsize);
            this.groupBox4.Controls.Add(this.namesize);
            this.groupBox4.Controls.Add(this.cvvy);
            this.groupBox4.Controls.Add(this.cvvx);
            this.groupBox4.Controls.Add(this.expryy);
            this.groupBox4.Controls.Add(this.expryx);
            this.groupBox4.Controls.Add(this.validy);
            this.groupBox4.Controls.Add(this.validx);
            this.groupBox4.Controls.Add(this.namey);
            this.groupBox4.Controls.Add(this.namex);
            this.groupBox4.Controls.Add(this.cardnosize);
            this.groupBox4.Controls.Add(this.label125);
            this.groupBox4.Controls.Add(this.txt_CardNumber);
            this.groupBox4.Controls.Add(this.TextFrontYUpDown);
            this.groupBox4.Controls.Add(this.label126);
            this.groupBox4.Controls.Add(this.TextFrontXUpDown);
            this.groupBox4.Controls.Add(this.label127);
            this.groupBox4.Controls.Add(this.label128);
            this.groupBox4.Controls.Add(this.MagDataEnabled);
            this.groupBox4.Controls.Add(this.label5);
            this.groupBox4.Controls.Add(this.txt_CVV);
            this.groupBox4.Controls.Add(this.label6);
            this.groupBox4.Controls.Add(this.lblcvv);
            this.groupBox4.Controls.Add(this.txt_Track2);
            this.groupBox4.Controls.Add(this.txt_Exp);
            this.groupBox4.Controls.Add(this.txt_Track1);
            this.groupBox4.Controls.Add(this.txt_Valid);
            this.groupBox4.Controls.Add(this.txt_Name);
            this.groupBox4.Controls.Add(this.label4);
            this.groupBox4.Controls.Add(this.label3);
            this.groupBox4.Controls.Add(this.label2);
            this.groupBox4.Controls.Add(this.label1);
            this.groupBox4.Location = new System.Drawing.Point(9, 3);
            this.groupBox4.Name = "groupBox4";
            this.groupBox4.Size = new System.Drawing.Size(524, 246);
            this.groupBox4.TabIndex = 2;
            this.groupBox4.TabStop = false;
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Location = new System.Drawing.Point(438, 83);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(47, 13);
            this.label16.TabIndex = 99;
            this.label16.Text = "Position:";
            // 
            // cvvsize
            // 
            this.cvvsize.Location = new System.Drawing.Point(320, 215);
            this.cvvsize.Maximum = new decimal(new int[] {
            99,
            0,
            0,
            0});
            this.cvvsize.Name = "cvvsize";
            this.cvvsize.Size = new System.Drawing.Size(45, 20);
            this.cvvsize.TabIndex = 98;
            this.cvvsize.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.cvvsize.Value = new decimal(new int[] {
            8,
            0,
            0,
            0});
            // 
            // exprysize
            // 
            this.exprysize.Location = new System.Drawing.Point(320, 188);
            this.exprysize.Maximum = new decimal(new int[] {
            99,
            0,
            0,
            0});
            this.exprysize.Name = "exprysize";
            this.exprysize.Size = new System.Drawing.Size(45, 20);
            this.exprysize.TabIndex = 97;
            this.exprysize.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.exprysize.Value = new decimal(new int[] {
            8,
            0,
            0,
            0});
            // 
            // validsize
            // 
            this.validsize.Location = new System.Drawing.Point(320, 164);
            this.validsize.Maximum = new decimal(new int[] {
            99,
            0,
            0,
            0});
            this.validsize.Name = "validsize";
            this.validsize.Size = new System.Drawing.Size(45, 20);
            this.validsize.TabIndex = 96;
            this.validsize.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.validsize.Value = new decimal(new int[] {
            8,
            0,
            0,
            0});
            // 
            // namesize
            // 
            this.namesize.Location = new System.Drawing.Point(320, 132);
            this.namesize.Maximum = new decimal(new int[] {
            99,
            0,
            0,
            0});
            this.namesize.Name = "namesize";
            this.namesize.Size = new System.Drawing.Size(45, 20);
            this.namesize.TabIndex = 95;
            this.namesize.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.namesize.Value = new decimal(new int[] {
            11,
            0,
            0,
            0});
            // 
            // cvvy
            // 
            this.cvvy.Location = new System.Drawing.Point(440, 215);
            this.cvvy.Maximum = new decimal(new int[] {
            642,
            0,
            0,
            0});
            this.cvvy.Name = "cvvy";
            this.cvvy.Size = new System.Drawing.Size(45, 20);
            this.cvvy.TabIndex = 94;
            this.cvvy.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.cvvy.Value = new decimal(new int[] {
            250,
            0,
            0,
            0});
            // 
            // cvvx
            // 
            this.cvvx.Location = new System.Drawing.Point(389, 215);
            this.cvvx.Maximum = new decimal(new int[] {
            1016,
            0,
            0,
            0});
            this.cvvx.Name = "cvvx";
            this.cvvx.Size = new System.Drawing.Size(45, 20);
            this.cvvx.TabIndex = 93;
            this.cvvx.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.cvvx.Value = new decimal(new int[] {
            600,
            0,
            0,
            0});
            // 
            // expryy
            // 
            this.expryy.Location = new System.Drawing.Point(440, 188);
            this.expryy.Maximum = new decimal(new int[] {
            642,
            0,
            0,
            0});
            this.expryy.Name = "expryy";
            this.expryy.Size = new System.Drawing.Size(45, 20);
            this.expryy.TabIndex = 92;
            this.expryy.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.expryy.Value = new decimal(new int[] {
            460,
            0,
            0,
            0});
            // 
            // expryx
            // 
            this.expryx.Location = new System.Drawing.Point(389, 188);
            this.expryx.Maximum = new decimal(new int[] {
            1016,
            0,
            0,
            0});
            this.expryx.Name = "expryx";
            this.expryx.Size = new System.Drawing.Size(45, 20);
            this.expryx.TabIndex = 91;
            this.expryx.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.expryx.Value = new decimal(new int[] {
            350,
            0,
            0,
            0});
            // 
            // validy
            // 
            this.validy.Location = new System.Drawing.Point(440, 162);
            this.validy.Maximum = new decimal(new int[] {
            642,
            0,
            0,
            0});
            this.validy.Name = "validy";
            this.validy.Size = new System.Drawing.Size(45, 20);
            this.validy.TabIndex = 90;
            this.validy.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.validy.Value = new decimal(new int[] {
            460,
            0,
            0,
            0});
            // 
            // validx
            // 
            this.validx.Location = new System.Drawing.Point(389, 162);
            this.validx.Maximum = new decimal(new int[] {
            1016,
            0,
            0,
            0});
            this.validx.Name = "validx";
            this.validx.Size = new System.Drawing.Size(45, 20);
            this.validx.TabIndex = 89;
            this.validx.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.validx.Value = new decimal(new int[] {
            150,
            0,
            0,
            0});
            // 
            // namey
            // 
            this.namey.Location = new System.Drawing.Point(440, 132);
            this.namey.Maximum = new decimal(new int[] {
            642,
            0,
            0,
            0});
            this.namey.Name = "namey";
            this.namey.Size = new System.Drawing.Size(45, 20);
            this.namey.TabIndex = 88;
            this.namey.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.namey.Value = new decimal(new int[] {
            550,
            0,
            0,
            0});
            // 
            // namex
            // 
            this.namex.Location = new System.Drawing.Point(389, 132);
            this.namex.Maximum = new decimal(new int[] {
            1016,
            0,
            0,
            0});
            this.namex.Name = "namex";
            this.namex.Size = new System.Drawing.Size(45, 20);
            this.namex.TabIndex = 87;
            this.namex.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.namex.Value = new decimal(new int[] {
            90,
            0,
            0,
            0});
            // 
            // cardnosize
            // 
            this.cardnosize.Location = new System.Drawing.Point(320, 101);
            this.cardnosize.Maximum = new decimal(new int[] {
            99,
            0,
            0,
            0});
            this.cardnosize.Name = "cardnosize";
            this.cardnosize.Size = new System.Drawing.Size(45, 20);
            this.cardnosize.TabIndex = 84;
            this.cardnosize.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.cardnosize.Value = new decimal(new int[] {
            14,
            0,
            0,
            0});
            // 
            // label125
            // 
            this.label125.AutoSize = true;
            this.label125.Location = new System.Drawing.Point(317, 83);
            this.label125.Name = "label125";
            this.label125.Size = new System.Drawing.Size(27, 13);
            this.label125.TabIndex = 83;
            this.label125.Text = "Size";
            // 
            // txt_CardNumber
            // 
            this.txt_CardNumber.Location = new System.Drawing.Point(98, 105);
            this.txt_CardNumber.Name = "txt_CardNumber";
            this.txt_CardNumber.Size = new System.Drawing.Size(202, 20);
            this.txt_CardNumber.TabIndex = 82;
            this.txt_CardNumber.Text = "1234 6500 0000 0022";
            // 
            // TextFrontYUpDown
            // 
            this.TextFrontYUpDown.Location = new System.Drawing.Point(440, 101);
            this.TextFrontYUpDown.Maximum = new decimal(new int[] {
            642,
            0,
            0,
            0});
            this.TextFrontYUpDown.Name = "TextFrontYUpDown";
            this.TextFrontYUpDown.Size = new System.Drawing.Size(45, 20);
            this.TextFrontYUpDown.TabIndex = 81;
            this.TextFrontYUpDown.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.TextFrontYUpDown.Value = new decimal(new int[] {
            400,
            0,
            0,
            0});
            // 
            // label126
            // 
            this.label126.AutoSize = true;
            this.label126.Location = new System.Drawing.Point(482, 84);
            this.label126.Name = "label126";
            this.label126.Size = new System.Drawing.Size(14, 13);
            this.label126.TabIndex = 80;
            this.label126.Text = "Y";
            // 
            // TextFrontXUpDown
            // 
            this.TextFrontXUpDown.Location = new System.Drawing.Point(389, 101);
            this.TextFrontXUpDown.Maximum = new decimal(new int[] {
            1016,
            0,
            0,
            0});
            this.TextFrontXUpDown.Name = "TextFrontXUpDown";
            this.TextFrontXUpDown.Size = new System.Drawing.Size(45, 20);
            this.TextFrontXUpDown.TabIndex = 79;
            this.TextFrontXUpDown.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.TextFrontXUpDown.Value = new decimal(new int[] {
            90,
            0,
            0,
            0});
            // 
            // label127
            // 
            this.label127.AutoSize = true;
            this.label127.Location = new System.Drawing.Point(420, 85);
            this.label127.Name = "label127";
            this.label127.Size = new System.Drawing.Size(14, 13);
            this.label127.TabIndex = 78;
            this.label127.Text = "X";
            // 
            // label128
            // 
            this.label128.AutoSize = true;
            this.label128.Location = new System.Drawing.Point(378, 84);
            this.label128.Name = "label128";
            this.label128.Size = new System.Drawing.Size(47, 13);
            this.label128.TabIndex = 77;
            this.label128.Text = "Position:";
            // 
            // MagDataEnabled
            // 
            this.MagDataEnabled.AutoSize = true;
            this.MagDataEnabled.Checked = true;
            this.MagDataEnabled.CheckState = System.Windows.Forms.CheckState.Checked;
            this.MagDataEnabled.Location = new System.Drawing.Point(6, 10);
            this.MagDataEnabled.Name = "MagDataEnabled";
            this.MagDataEnabled.Size = new System.Drawing.Size(47, 17);
            this.MagDataEnabled.TabIndex = 53;
            this.MagDataEnabled.Text = "Mag";
            this.MagDataEnabled.UseVisualStyleBackColor = true;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(20, 34);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(41, 13);
            this.label5.TabIndex = 3;
            this.label5.Text = "Track1";
            // 
            // txt_CVV
            // 
            this.txt_CVV.Location = new System.Drawing.Point(98, 209);
            this.txt_CVV.Name = "txt_CVV";
            this.txt_CVV.Size = new System.Drawing.Size(202, 20);
            this.txt_CVV.TabIndex = 52;
            this.txt_CVV.Text = "360";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(20, 67);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(41, 13);
            this.label6.TabIndex = 4;
            this.label6.Text = "Track2";
            // 
            // lblcvv
            // 
            this.lblcvv.AutoSize = true;
            this.lblcvv.Location = new System.Drawing.Point(20, 216);
            this.lblcvv.Name = "lblcvv";
            this.lblcvv.Size = new System.Drawing.Size(28, 13);
            this.lblcvv.TabIndex = 51;
            this.lblcvv.Text = "CVV";
            // 
            // txt_Track2
            // 
            this.txt_Track2.Location = new System.Drawing.Point(78, 60);
            this.txt_Track2.Name = "txt_Track2";
            this.txt_Track2.Size = new System.Drawing.Size(431, 20);
            this.txt_Track2.TabIndex = 10;
            this.txt_Track2.Text = "1234560000000022=190220119583210";
            // 
            // txt_Exp
            // 
            this.txt_Exp.Location = new System.Drawing.Point(98, 183);
            this.txt_Exp.Name = "txt_Exp";
            this.txt_Exp.Size = new System.Drawing.Size(202, 20);
            this.txt_Exp.TabIndex = 8;
            this.txt_Exp.Text = "06/03";
            // 
            // txt_Track1
            // 
            this.txt_Track1.Location = new System.Drawing.Point(78, 27);
            this.txt_Track1.Name = "txt_Track1";
            this.txt_Track1.Size = new System.Drawing.Size(431, 20);
            this.txt_Track1.TabIndex = 9;
            this.txt_Track1.Text = "B1234560000000022^MAGICARD PRO              ^19022011958300210000000";
            // 
            // txt_Valid
            // 
            this.txt_Valid.Location = new System.Drawing.Point(99, 157);
            this.txt_Valid.Name = "txt_Valid";
            this.txt_Valid.Size = new System.Drawing.Size(202, 20);
            this.txt_Valid.TabIndex = 7;
            this.txt_Valid.Text = "03/06";
            // 
            // txt_Name
            // 
            this.txt_Name.Location = new System.Drawing.Point(98, 131);
            this.txt_Name.Name = "txt_Name";
            this.txt_Name.Size = new System.Drawing.Size(202, 20);
            this.txt_Name.TabIndex = 6;
            this.txt_Name.Text = "MAGICARD PRO";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(20, 190);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(35, 13);
            this.label4.TabIndex = 2;
            this.label4.Text = "Expiry";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(20, 164);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(33, 13);
            this.label3.TabIndex = 2;
            this.label3.Text = "Valid ";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(20, 112);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(69, 13);
            this.label2.TabIndex = 1;
            this.label2.Text = "Card Number";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(20, 138);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(77, 13);
            this.label1.TabIndex = 0;
            this.label1.Text = "Name On Card";
            // 
            // PrintButton
            // 
            this.PrintButton.Location = new System.Drawing.Point(20, 255);
            this.PrintButton.Name = "PrintButton";
            this.PrintButton.Size = new System.Drawing.Size(90, 24);
            this.PrintButton.TabIndex = 50;
            this.PrintButton.Text = "Print";
            this.PrintButton.UseVisualStyleBackColor = true;
            this.PrintButton.Click += new System.EventHandler(this.PrintButton_Click);
            // 
            // TextFrontColourBox
            // 
            this.TextFrontColourBox.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.TextFrontColourBox.Items.AddRange(new object[] {
            "Black"});
            this.TextFrontColourBox.Location = new System.Drawing.Point(475, 358);
            this.TextFrontColourBox.Name = "TextFrontColourBox";
            this.TextFrontColourBox.Size = new System.Drawing.Size(25, 21);
            this.TextFrontColourBox.TabIndex = 86;
            this.TextFrontColourBox.Visible = false;
            // 
            // tabPage1
            // 
            this.tabPage1.Controls.Add(this.groupBox1);
            this.tabPage1.Controls.Add(this.button5);
            this.tabPage1.Controls.Add(this.comboBox3);
            this.tabPage1.Controls.Add(this.comboBox2);
            this.tabPage1.Controls.Add(this.textBox6);
            this.tabPage1.Controls.Add(this.db_password);
            this.tabPage1.Controls.Add(this.label17);
            this.tabPage1.Controls.Add(this.db_user);
            this.tabPage1.Controls.Add(this.label15);
            this.tabPage1.Controls.Add(this.label14);
            this.tabPage1.Controls.Add(this.flowLayoutPanel1);
            this.tabPage1.Controls.Add(this.label12);
            this.tabPage1.Controls.Add(this.SessionConfigBox);
            this.tabPage1.Controls.Add(this.PrinterMsgBox);
            this.tabPage1.Controls.Add(this.FeedCardBox);
            this.tabPage1.Location = new System.Drawing.Point(4, 22);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage1.Size = new System.Drawing.Size(541, 441);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "Setting";
            this.tabPage1.UseVisualStyleBackColor = true;
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.dgv_Records);
            this.groupBox1.Location = new System.Drawing.Point(18, 123);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(511, 182);
            this.groupBox1.TabIndex = 68;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "groupBox1";
            // 
            // dgv_Records
            // 
            this.dgv_Records.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgv_Records.Location = new System.Drawing.Point(5, 19);
            this.dgv_Records.Name = "dgv_Records";
            this.dgv_Records.Size = new System.Drawing.Size(500, 157);
            this.dgv_Records.TabIndex = 0;
            this.dgv_Records.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgv_Records_CellContentClick);
            // 
            // button5
            // 
            this.button5.Location = new System.Drawing.Point(428, 17);
            this.button5.Name = "button5";
            this.button5.Size = new System.Drawing.Size(101, 23);
            this.button5.TabIndex = 67;
            this.button5.Text = "Connect";
            this.button5.UseVisualStyleBackColor = true;
            this.button5.Click += new System.EventHandler(this.button5_Click);
            // 
            // comboBox3
            // 
            this.comboBox3.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBox3.FormattingEnabled = true;
            this.comboBox3.Location = new System.Drawing.Point(128, 43);
            this.comboBox3.Name = "comboBox3";
            this.comboBox3.Size = new System.Drawing.Size(248, 21);
            this.comboBox3.TabIndex = 66;
            this.comboBox3.SelectedIndexChanged += new System.EventHandler(this.comboBox3_SelectedIndexChanged);
            // 
            // comboBox2
            // 
            this.comboBox2.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBox2.ForeColor = System.Drawing.SystemColors.InactiveCaptionText;
            this.comboBox2.FormattingEnabled = true;
            this.comboBox2.Items.AddRange(new object[] {
            "192.168.0.151",
            "192.168.0.200\\SQL_SERVER",
            "192.168.0.200\\SQLSERVER",
            "Other",
            "Select"});
            this.comboBox2.Location = new System.Drawing.Point(128, 17);
            this.comboBox2.Name = "comboBox2";
            this.comboBox2.Size = new System.Drawing.Size(248, 21);
            this.comboBox2.TabIndex = 65;
            this.comboBox2.SelectedIndexChanged += new System.EventHandler(this.comboBox2_SelectedIndexChanged);
            // 
            // textBox6
            // 
            this.textBox6.Location = new System.Drawing.Point(128, 71);
            this.textBox6.Name = "textBox6";
            this.textBox6.Size = new System.Drawing.Size(162, 20);
            this.textBox6.TabIndex = 64;
            this.textBox6.Text = "NcxPerso";
            // 
            // db_password
            // 
            this.db_password.Location = new System.Drawing.Point(128, 97);
            this.db_password.Name = "db_password";
            this.db_password.Size = new System.Drawing.Size(162, 20);
            this.db_password.TabIndex = 63;
            this.db_password.Text = "NcxPerso";
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Location = new System.Drawing.Point(20, 104);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(102, 13);
            this.label17.TabIndex = 62;
            this.label17.Text = "Database Password";
            // 
            // db_user
            // 
            this.db_user.AutoSize = true;
            this.db_user.Location = new System.Drawing.Point(21, 78);
            this.db_user.Name = "db_user";
            this.db_user.Size = new System.Drawing.Size(104, 13);
            this.db_user.TabIndex = 61;
            this.db_user.Text = "Database Username";
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Location = new System.Drawing.Point(21, 51);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(84, 13);
            this.label15.TabIndex = 60;
            this.label15.Text = "Database Name";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(21, 25);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(90, 13);
            this.label14.TabIndex = 59;
            this.label14.Text = "Database Server ";
            // 
            // flowLayoutPanel1
            // 
            this.flowLayoutPanel1.Controls.Add(this.OpenSessionButton);
            this.flowLayoutPanel1.Controls.Add(this.EjectCardButton);
            this.flowLayoutPanel1.Controls.Add(this.FlipCardButton);
            this.flowLayoutPanel1.Controls.Add(this.PrintTestCardButton);
            this.flowLayoutPanel1.Controls.Add(this.FeedCardButton);
            this.flowLayoutPanel1.Controls.Add(this.RestartButton);
            this.flowLayoutPanel1.Location = new System.Drawing.Point(23, 335);
            this.flowLayoutPanel1.Name = "flowLayoutPanel1";
            this.flowLayoutPanel1.Size = new System.Drawing.Size(200, 100);
            this.flowLayoutPanel1.TabIndex = 58;
            this.flowLayoutPanel1.Visible = false;
            // 
            // OpenSessionButton
            // 
            this.OpenSessionButton.Location = new System.Drawing.Point(3, 3);
            this.OpenSessionButton.Name = "OpenSessionButton";
            this.OpenSessionButton.Size = new System.Drawing.Size(87, 23);
            this.OpenSessionButton.TabIndex = 49;
            this.OpenSessionButton.Text = "OpenSession";
            this.OpenSessionButton.UseVisualStyleBackColor = true;
            this.OpenSessionButton.Visible = false;
            this.OpenSessionButton.Click += new System.EventHandler(this.OpenSessionButton_Click);
            // 
            // EjectCardButton
            // 
            this.EjectCardButton.Location = new System.Drawing.Point(96, 3);
            this.EjectCardButton.Name = "EjectCardButton";
            this.EjectCardButton.Size = new System.Drawing.Size(90, 24);
            this.EjectCardButton.TabIndex = 51;
            this.EjectCardButton.Text = "EjectCard";
            this.EjectCardButton.UseVisualStyleBackColor = true;
            this.EjectCardButton.Visible = false;
            this.EjectCardButton.Click += new System.EventHandler(this.EjectCardButton_Click);
            // 
            // FlipCardButton
            // 
            this.FlipCardButton.Location = new System.Drawing.Point(3, 33);
            this.FlipCardButton.Name = "FlipCardButton";
            this.FlipCardButton.Size = new System.Drawing.Size(90, 24);
            this.FlipCardButton.TabIndex = 52;
            this.FlipCardButton.Text = "FlipCard";
            this.FlipCardButton.UseVisualStyleBackColor = true;
            this.FlipCardButton.Visible = false;
            this.FlipCardButton.Click += new System.EventHandler(this.FlipCardButton_Click);
            // 
            // PrintTestCardButton
            // 
            this.PrintTestCardButton.Location = new System.Drawing.Point(99, 33);
            this.PrintTestCardButton.Name = "PrintTestCardButton";
            this.PrintTestCardButton.Size = new System.Drawing.Size(90, 24);
            this.PrintTestCardButton.TabIndex = 55;
            this.PrintTestCardButton.Text = "PrintTestCard";
            this.PrintTestCardButton.UseVisualStyleBackColor = true;
            this.PrintTestCardButton.Visible = false;
            this.PrintTestCardButton.Click += new System.EventHandler(this.PrintButton_Click);
            // 
            // FeedCardButton
            // 
            this.FeedCardButton.Location = new System.Drawing.Point(3, 63);
            this.FeedCardButton.Name = "FeedCardButton";
            this.FeedCardButton.Size = new System.Drawing.Size(90, 24);
            this.FeedCardButton.TabIndex = 50;
            this.FeedCardButton.Text = "FeedCard";
            this.FeedCardButton.UseVisualStyleBackColor = true;
            this.FeedCardButton.Visible = false;
            this.FeedCardButton.Click += new System.EventHandler(this.FeedCardButton_Click);
            // 
            // RestartButton
            // 
            this.RestartButton.Location = new System.Drawing.Point(99, 63);
            this.RestartButton.Name = "RestartButton";
            this.RestartButton.Size = new System.Drawing.Size(90, 24);
            this.RestartButton.TabIndex = 56;
            this.RestartButton.Text = "Reset Printer";
            this.RestartButton.UseVisualStyleBackColor = true;
            this.RestartButton.Visible = false;
            this.RestartButton.Click += new System.EventHandler(this.RestartButton_Click);
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(290, 17);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(0, 13);
            this.label12.TabIndex = 57;
            this.label12.Visible = false;
            // 
            // SessionConfigBox
            // 
            this.SessionConfigBox.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.SessionConfigBox.FormattingEnabled = true;
            this.SessionConfigBox.Location = new System.Drawing.Point(229, 414);
            this.SessionConfigBox.Name = "SessionConfigBox";
            this.SessionConfigBox.Size = new System.Drawing.Size(147, 21);
            this.SessionConfigBox.TabIndex = 39;
            this.SessionConfigBox.Visible = false;
            // 
            // PrinterMsgBox
            // 
            this.PrinterMsgBox.Location = new System.Drawing.Point(18, 311);
            this.PrinterMsgBox.Multiline = true;
            this.PrinterMsgBox.Name = "PrinterMsgBox";
            this.PrinterMsgBox.ReadOnly = true;
            this.PrinterMsgBox.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.PrinterMsgBox.Size = new System.Drawing.Size(519, 124);
            this.PrinterMsgBox.TabIndex = 49;
            this.PrinterMsgBox.Visible = false;
            this.PrinterMsgBox.WordWrap = false;
            // 
            // FeedCardBox
            // 
            this.FeedCardBox.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.FeedCardBox.FormattingEnabled = true;
            this.FeedCardBox.Location = new System.Drawing.Point(260, 311);
            this.FeedCardBox.Name = "FeedCardBox";
            this.FeedCardBox.Size = new System.Drawing.Size(149, 21);
            this.FeedCardBox.TabIndex = 54;
            this.FeedCardBox.Visible = false;
            // 
            // tabPage2
            // 
            this.tabPage2.Controls.Add(this.groupBox3);
            this.tabPage2.Controls.Add(this.Get_Info);
            this.tabPage2.Controls.Add(this.label8);
            this.tabPage2.Controls.Add(this.label7);
            this.tabPage2.Location = new System.Drawing.Point(4, 22);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage2.Size = new System.Drawing.Size(541, 441);
            this.tabPage2.TabIndex = 1;
            this.tabPage2.Text = "Printer Information";
            this.tabPage2.UseVisualStyleBackColor = true;
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.ClearPrinterMsgButton);
            this.groupBox3.Controls.Add(this.textBox2);
            this.groupBox3.Controls.Add(this.HandFeedBox);
            this.groupBox3.Controls.Add(this.HorzEjectBox);
            this.groupBox3.Controls.Add(this.HorzEjectButton);
            this.groupBox3.Controls.Add(this.HandFeedButton);
            this.groupBox3.Controls.Add(this.label11);
            this.groupBox3.Controls.Add(this.PrinterSetRadio);
            this.groupBox3.Controls.Add(this.PrinterGetRadio);
            this.groupBox3.Controls.Add(this.groupBox7);
            this.groupBox3.Controls.Add(this.SmartOffsetBox);
            this.groupBox3.Controls.Add(this.SmartOffsetButton);
            this.groupBox3.Controls.Add(this.SmartModeButton);
            this.groupBox3.Controls.Add(this.comboBox1);
            this.groupBox3.Controls.Add(this.EraseSpeedButton);
            this.groupBox3.Controls.Add(this.EraseSpeedBox);
            this.groupBox3.Controls.Add(this.EjectModeButton);
            this.groupBox3.Controls.Add(this.EjectModeBox);
            this.groupBox3.Location = new System.Drawing.Point(24, 54);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(527, 352);
            this.groupBox3.TabIndex = 12;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "Printer Config";
            // 
            // ClearPrinterMsgButton
            // 
            this.ClearPrinterMsgButton.Location = new System.Drawing.Point(287, 322);
            this.ClearPrinterMsgButton.Name = "ClearPrinterMsgButton";
            this.ClearPrinterMsgButton.Size = new System.Drawing.Size(90, 24);
            this.ClearPrinterMsgButton.TabIndex = 36;
            this.ClearPrinterMsgButton.Text = "Clear";
            this.ClearPrinterMsgButton.UseVisualStyleBackColor = true;
            // 
            // textBox2
            // 
            this.textBox2.Location = new System.Drawing.Point(219, 11);
            this.textBox2.Multiline = true;
            this.textBox2.Name = "textBox2";
            this.textBox2.ReadOnly = true;
            this.textBox2.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.textBox2.Size = new System.Drawing.Size(227, 305);
            this.textBox2.TabIndex = 35;
            this.textBox2.WordWrap = false;
            // 
            // HandFeedBox
            // 
            this.HandFeedBox.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.HandFeedBox.FormattingEnabled = true;
            this.HandFeedBox.Location = new System.Drawing.Point(96, 43);
            this.HandFeedBox.Name = "HandFeedBox";
            this.HandFeedBox.Size = new System.Drawing.Size(106, 21);
            this.HandFeedBox.TabIndex = 34;
            // 
            // HorzEjectBox
            // 
            this.HorzEjectBox.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.HorzEjectBox.FormattingEnabled = true;
            this.HorzEjectBox.Location = new System.Drawing.Point(96, 91);
            this.HorzEjectBox.Name = "HorzEjectBox";
            this.HorzEjectBox.Size = new System.Drawing.Size(106, 21);
            this.HorzEjectBox.TabIndex = 33;
            // 
            // HorzEjectButton
            // 
            this.HorzEjectButton.Enabled = false;
            this.HorzEjectButton.Location = new System.Drawing.Point(3, 89);
            this.HorzEjectButton.Name = "HorzEjectButton";
            this.HorzEjectButton.Size = new System.Drawing.Size(90, 24);
            this.HorzEjectButton.TabIndex = 32;
            this.HorzEjectButton.Text = "HorzEject";
            this.HorzEjectButton.UseVisualStyleBackColor = true;
            // 
            // HandFeedButton
            // 
            this.HandFeedButton.Enabled = false;
            this.HandFeedButton.Location = new System.Drawing.Point(3, 41);
            this.HandFeedButton.Name = "HandFeedButton";
            this.HandFeedButton.Size = new System.Drawing.Size(90, 24);
            this.HandFeedButton.TabIndex = 31;
            this.HandFeedButton.Text = "HandFeed";
            this.HandFeedButton.UseVisualStyleBackColor = true;
            this.HandFeedButton.Click += new System.EventHandler(this.HandFeedButton_Click);
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(6, 23);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(40, 13);
            this.label11.TabIndex = 30;
            this.label11.Text = "Action:";
            // 
            // PrinterSetRadio
            // 
            this.PrinterSetRadio.AutoSize = true;
            this.PrinterSetRadio.Checked = true;
            this.PrinterSetRadio.Enabled = false;
            this.PrinterSetRadio.Location = new System.Drawing.Point(88, 21);
            this.PrinterSetRadio.Name = "PrinterSetRadio";
            this.PrinterSetRadio.Size = new System.Drawing.Size(41, 17);
            this.PrinterSetRadio.TabIndex = 29;
            this.PrinterSetRadio.TabStop = true;
            this.PrinterSetRadio.Text = "Set";
            this.PrinterSetRadio.UseVisualStyleBackColor = true;
            // 
            // PrinterGetRadio
            // 
            this.PrinterGetRadio.AutoSize = true;
            this.PrinterGetRadio.Enabled = false;
            this.PrinterGetRadio.Location = new System.Drawing.Point(46, 21);
            this.PrinterGetRadio.Name = "PrinterGetRadio";
            this.PrinterGetRadio.Size = new System.Drawing.Size(42, 17);
            this.PrinterGetRadio.TabIndex = 28;
            this.PrinterGetRadio.Text = "Get";
            this.PrinterGetRadio.UseVisualStyleBackColor = true;
            // 
            // groupBox7
            // 
            this.groupBox7.Controls.Add(this.IPGatewayLabel);
            this.groupBox7.Controls.Add(this.IPSubnetLabel);
            this.groupBox7.Controls.Add(this.IPAddrLabel);
            this.groupBox7.Controls.Add(this.IPGatewayBox);
            this.groupBox7.Controls.Add(this.IPSubnetBox);
            this.groupBox7.Controls.Add(this.IPAddrBox);
            this.groupBox7.Controls.Add(this.IPSettingsButton);
            this.groupBox7.Controls.Add(this.IPModeLabel);
            this.groupBox7.Controls.Add(this.IPModeBox);
            this.groupBox7.Location = new System.Drawing.Point(3, 185);
            this.groupBox7.Name = "groupBox7";
            this.groupBox7.Size = new System.Drawing.Size(210, 156);
            this.groupBox7.TabIndex = 27;
            this.groupBox7.TabStop = false;
            // 
            // IPGatewayLabel
            // 
            this.IPGatewayLabel.AutoSize = true;
            this.IPGatewayLabel.Location = new System.Drawing.Point(6, 98);
            this.IPGatewayLabel.Name = "IPGatewayLabel";
            this.IPGatewayLabel.Size = new System.Drawing.Size(49, 13);
            this.IPGatewayLabel.TabIndex = 44;
            this.IPGatewayLabel.Text = "Gateway";
            // 
            // IPSubnetLabel
            // 
            this.IPSubnetLabel.AutoSize = true;
            this.IPSubnetLabel.Location = new System.Drawing.Point(6, 71);
            this.IPSubnetLabel.Name = "IPSubnetLabel";
            this.IPSubnetLabel.Size = new System.Drawing.Size(41, 13);
            this.IPSubnetLabel.TabIndex = 43;
            this.IPSubnetLabel.Text = "Subnet";
            // 
            // IPAddrLabel
            // 
            this.IPAddrLabel.AutoSize = true;
            this.IPAddrLabel.Location = new System.Drawing.Point(6, 44);
            this.IPAddrLabel.Name = "IPAddrLabel";
            this.IPAddrLabel.Size = new System.Drawing.Size(42, 13);
            this.IPAddrLabel.TabIndex = 42;
            this.IPAddrLabel.Text = "IP Addr";
            // 
            // IPGatewayBox
            // 
            this.IPGatewayBox.Enabled = false;
            this.IPGatewayBox.Location = new System.Drawing.Point(68, 94);
            this.IPGatewayBox.Name = "IPGatewayBox";
            this.IPGatewayBox.Size = new System.Drawing.Size(131, 20);
            this.IPGatewayBox.TabIndex = 41;
            this.IPGatewayBox.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // IPSubnetBox
            // 
            this.IPSubnetBox.Enabled = false;
            this.IPSubnetBox.Location = new System.Drawing.Point(68, 67);
            this.IPSubnetBox.Name = "IPSubnetBox";
            this.IPSubnetBox.Size = new System.Drawing.Size(131, 20);
            this.IPSubnetBox.TabIndex = 40;
            this.IPSubnetBox.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // IPAddrBox
            // 
            this.IPAddrBox.Enabled = false;
            this.IPAddrBox.Location = new System.Drawing.Point(68, 40);
            this.IPAddrBox.Name = "IPAddrBox";
            this.IPAddrBox.Size = new System.Drawing.Size(131, 20);
            this.IPAddrBox.TabIndex = 26;
            this.IPAddrBox.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // IPSettingsButton
            // 
            this.IPSettingsButton.Enabled = false;
            this.IPSettingsButton.Location = new System.Drawing.Point(63, 126);
            this.IPSettingsButton.Name = "IPSettingsButton";
            this.IPSettingsButton.Size = new System.Drawing.Size(90, 24);
            this.IPSettingsButton.TabIndex = 39;
            this.IPSettingsButton.Text = "IP Settings";
            this.IPSettingsButton.UseVisualStyleBackColor = true;
            // 
            // IPModeLabel
            // 
            this.IPModeLabel.AutoSize = true;
            this.IPModeLabel.Location = new System.Drawing.Point(6, 16);
            this.IPModeLabel.Name = "IPModeLabel";
            this.IPModeLabel.Size = new System.Drawing.Size(34, 13);
            this.IPModeLabel.TabIndex = 37;
            this.IPModeLabel.Text = "Mode";
            // 
            // IPModeBox
            // 
            this.IPModeBox.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.IPModeBox.Enabled = false;
            this.IPModeBox.FormattingEnabled = true;
            this.IPModeBox.Location = new System.Drawing.Point(68, 12);
            this.IPModeBox.Name = "IPModeBox";
            this.IPModeBox.Size = new System.Drawing.Size(131, 21);
            this.IPModeBox.TabIndex = 38;
            // 
            // SmartOffsetBox
            // 
            this.SmartOffsetBox.Location = new System.Drawing.Point(96, 139);
            this.SmartOffsetBox.Maximum = new decimal(new int[] {
            99,
            0,
            0,
            0});
            this.SmartOffsetBox.Name = "SmartOffsetBox";
            this.SmartOffsetBox.Size = new System.Drawing.Size(106, 20);
            this.SmartOffsetBox.TabIndex = 17;
            this.SmartOffsetBox.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // SmartOffsetButton
            // 
            this.SmartOffsetButton.Enabled = false;
            this.SmartOffsetButton.Location = new System.Drawing.Point(3, 137);
            this.SmartOffsetButton.Name = "SmartOffsetButton";
            this.SmartOffsetButton.Size = new System.Drawing.Size(90, 24);
            this.SmartOffsetButton.TabIndex = 25;
            this.SmartOffsetButton.Text = "SmartOffset";
            this.SmartOffsetButton.UseVisualStyleBackColor = true;
            // 
            // SmartModeButton
            // 
            this.SmartModeButton.Enabled = false;
            this.SmartModeButton.Location = new System.Drawing.Point(3, 113);
            this.SmartModeButton.Name = "SmartModeButton";
            this.SmartModeButton.Size = new System.Drawing.Size(90, 24);
            this.SmartModeButton.TabIndex = 23;
            this.SmartModeButton.Text = "SmartMode";
            this.SmartModeButton.UseVisualStyleBackColor = true;
            // 
            // comboBox1
            // 
            this.comboBox1.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBox1.Enabled = false;
            this.comboBox1.FormattingEnabled = true;
            this.comboBox1.Location = new System.Drawing.Point(96, 115);
            this.comboBox1.Name = "comboBox1";
            this.comboBox1.Size = new System.Drawing.Size(106, 21);
            this.comboBox1.TabIndex = 22;
            // 
            // EraseSpeedButton
            // 
            this.EraseSpeedButton.Enabled = false;
            this.EraseSpeedButton.Location = new System.Drawing.Point(3, 161);
            this.EraseSpeedButton.Name = "EraseSpeedButton";
            this.EraseSpeedButton.Size = new System.Drawing.Size(90, 24);
            this.EraseSpeedButton.TabIndex = 26;
            this.EraseSpeedButton.Text = "EraseSpeed";
            this.EraseSpeedButton.UseVisualStyleBackColor = true;
            // 
            // EraseSpeedBox
            // 
            this.EraseSpeedBox.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.EraseSpeedBox.FormattingEnabled = true;
            this.EraseSpeedBox.Location = new System.Drawing.Point(96, 163);
            this.EraseSpeedBox.Name = "EraseSpeedBox";
            this.EraseSpeedBox.Size = new System.Drawing.Size(106, 21);
            this.EraseSpeedBox.TabIndex = 26;
            // 
            // EjectModeButton
            // 
            this.EjectModeButton.Location = new System.Drawing.Point(3, 65);
            this.EjectModeButton.Name = "EjectModeButton";
            this.EjectModeButton.Size = new System.Drawing.Size(90, 24);
            this.EjectModeButton.TabIndex = 21;
            this.EjectModeButton.Text = "EjectMode";
            this.EjectModeButton.UseVisualStyleBackColor = true;
            this.EjectModeButton.Click += new System.EventHandler(this.EjectModeButton_Click);
            // 
            // EjectModeBox
            // 
            this.EjectModeBox.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.EjectModeBox.FormattingEnabled = true;
            this.EjectModeBox.Location = new System.Drawing.Point(96, 67);
            this.EjectModeBox.Name = "EjectModeBox";
            this.EjectModeBox.Size = new System.Drawing.Size(106, 21);
            this.EjectModeBox.TabIndex = 15;
            // 
            // Get_Info
            // 
            this.Get_Info.Location = new System.Drawing.Point(208, 6);
            this.Get_Info.Name = "Get_Info";
            this.Get_Info.Size = new System.Drawing.Size(136, 23);
            this.Get_Info.TabIndex = 4;
            this.Get_Info.Text = "Get Information";
            this.Get_Info.UseVisualStyleBackColor = true;
            this.Get_Info.Click += new System.EventHandler(this.Get_Info_Click);
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(117, 12);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(69, 13);
            this.label8.TabIndex = 1;
            this.label8.Text = "Printer Model";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(33, 12);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(64, 13);
            this.label7.TabIndex = 0;
            this.label7.Text = "Printer Type";
            // 
            // tabPage4
            // 
            this.tabPage4.Controls.Add(this.btn_ChipTest);
            this.tabPage4.Controls.Add(this.textBox4);
            this.tabPage4.Controls.Add(this.label10);
            this.tabPage4.Controls.Add(this.label9);
            this.tabPage4.Controls.Add(this.textBox3);
            this.tabPage4.Location = new System.Drawing.Point(4, 22);
            this.tabPage4.Name = "tabPage4";
            this.tabPage4.Size = new System.Drawing.Size(541, 441);
            this.tabPage4.TabIndex = 3;
            this.tabPage4.Text = "Chip Test";
            this.tabPage4.UseVisualStyleBackColor = true;
            // 
            // btn_ChipTest
            // 
            this.btn_ChipTest.Location = new System.Drawing.Point(37, 135);
            this.btn_ChipTest.Name = "btn_ChipTest";
            this.btn_ChipTest.Size = new System.Drawing.Size(100, 23);
            this.btn_ChipTest.TabIndex = 4;
            this.btn_ChipTest.Text = "Personalize Card";
            this.btn_ChipTest.UseVisualStyleBackColor = true;
            this.btn_ChipTest.Click += new System.EventHandler(this.btn_ChipTest_Click);
            // 
            // textBox4
            // 
            this.textBox4.Location = new System.Drawing.Point(140, 91);
            this.textBox4.Name = "textBox4";
            this.textBox4.Size = new System.Drawing.Size(180, 20);
            this.textBox4.TabIndex = 3;
            this.textBox4.Text = "3000";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(34, 94);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(50, 13);
            this.label10.TabIndex = 2;
            this.label10.Text = "Time Out";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(34, 62);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(100, 13);
            this.label9.TabIndex = 1;
            this.label9.Text = "Enter Card Number ";
            // 
            // textBox3
            // 
            this.textBox3.Location = new System.Drawing.Point(140, 55);
            this.textBox3.Name = "textBox3";
            this.textBox3.Size = new System.Drawing.Size(180, 20);
            this.textBox3.TabIndex = 0;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(566, 470);
            this.Controls.Add(this.tabControl1);
            this.MaximizeBox = false;
            this.MaximumSize = new System.Drawing.Size(582, 508);
            this.Name = "Form1";
            this.Text = "Form1";
            this.tabControl1.ResumeLayout(false);
            this.tabPage3.ResumeLayout(false);
            this.groupBox4.ResumeLayout(false);
            this.groupBox4.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.cvvsize)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.exprysize)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.validsize)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.namesize)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.cvvy)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.cvvx)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.expryy)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.expryx)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.validy)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.validx)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.namey)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.namex)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.cardnosize)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.TextFrontYUpDown)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.TextFrontXUpDown)).EndInit();
            this.tabPage1.ResumeLayout(false);
            this.tabPage1.PerformLayout();
            this.groupBox1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgv_Records)).EndInit();
            this.flowLayoutPanel1.ResumeLayout(false);
            this.tabPage2.ResumeLayout(false);
            this.tabPage2.PerformLayout();
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            this.groupBox7.ResumeLayout(false);
            this.groupBox7.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.SmartOffsetBox)).EndInit();
            this.tabPage4.ResumeLayout(false);
            this.tabPage4.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion
        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.TabPage tabPage3;
        private System.Windows.Forms.GroupBox groupBox4;
        private System.Windows.Forms.ComboBox TextFrontColourBox;
        private System.Windows.Forms.NumericUpDown cardnosize;
        private System.Windows.Forms.Label label125;
        private System.Windows.Forms.TextBox txt_CardNumber;
        private System.Windows.Forms.NumericUpDown TextFrontYUpDown;
        private System.Windows.Forms.Label label126;
        private System.Windows.Forms.NumericUpDown TextFrontXUpDown;
        private System.Windows.Forms.Label label127;
        private System.Windows.Forms.Label label128;
        private System.Windows.Forms.CheckBox MagDataEnabled;
        private System.Windows.Forms.TextBox txt_CVV;
        private System.Windows.Forms.Label lblcvv;
        private System.Windows.Forms.Button PrintButton;
        private System.Windows.Forms.TextBox txt_Track2;
        private System.Windows.Forms.TextBox txt_Track1;
        private System.Windows.Forms.TextBox txt_Exp;
        private System.Windows.Forms.TextBox txt_Valid;
        private System.Windows.Forms.TextBox txt_Name;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TabPage tabPage4;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Button Get_Info;
        private System.Windows.Forms.NumericUpDown validy;
        private System.Windows.Forms.NumericUpDown validx;
        private System.Windows.Forms.NumericUpDown namey;
        private System.Windows.Forms.NumericUpDown namex;
        private System.Windows.Forms.NumericUpDown cvvsize;
        private System.Windows.Forms.NumericUpDown exprysize;
        private System.Windows.Forms.NumericUpDown validsize;
        private System.Windows.Forms.NumericUpDown namesize;
        private System.Windows.Forms.NumericUpDown cvvy;
        private System.Windows.Forms.NumericUpDown cvvx;
        private System.Windows.Forms.NumericUpDown expryy;
        private System.Windows.Forms.NumericUpDown expryx;
        private System.Windows.Forms.ComboBox EncodingTypeBox;
        private System.Windows.Forms.ComboBox CoercivityBox;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.ComboBox T1_BPCBox;
        private System.Windows.Forms.ComboBox T1_BPIBox;
        private System.Windows.Forms.ComboBox T1_ParityBox;
        private System.Windows.Forms.ComboBox T1_LRCBox;
        private System.Windows.Forms.ComboBox T2_BPCBox;
        private System.Windows.Forms.ComboBox T2_BPIBox;
        private System.Windows.Forms.ComboBox T2_ParityBox;
        private System.Windows.Forms.ComboBox T2_LRCBox;
        private System.Windows.Forms.ComboBox SmartModeBox;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.Button ClearPrinterMsgButton;
        private System.Windows.Forms.TextBox textBox2;
        private System.Windows.Forms.ComboBox HandFeedBox;
        private System.Windows.Forms.ComboBox HorzEjectBox;
        private System.Windows.Forms.Button HorzEjectButton;
        private System.Windows.Forms.Button HandFeedButton;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.RadioButton PrinterSetRadio;
        private System.Windows.Forms.RadioButton PrinterGetRadio;
        private System.Windows.Forms.GroupBox groupBox7;
        private System.Windows.Forms.Label IPGatewayLabel;
        private System.Windows.Forms.Label IPSubnetLabel;
        private System.Windows.Forms.Label IPAddrLabel;
        private System.Windows.Forms.TextBox IPGatewayBox;
        private System.Windows.Forms.TextBox IPSubnetBox;
        private System.Windows.Forms.TextBox IPAddrBox;
        private System.Windows.Forms.Button IPSettingsButton;
        private System.Windows.Forms.Label IPModeLabel;
        private System.Windows.Forms.ComboBox IPModeBox;
        private System.Windows.Forms.NumericUpDown SmartOffsetBox;
        private System.Windows.Forms.Button SmartOffsetButton;
        private System.Windows.Forms.Button SmartModeButton;
        private System.Windows.Forms.ComboBox comboBox1;
        private System.Windows.Forms.Button EraseSpeedButton;
        private System.Windows.Forms.ComboBox EraseSpeedBox;
        private System.Windows.Forms.Button EjectModeButton;
        private System.Windows.Forms.ComboBox EjectModeBox;
        private System.Windows.Forms.TextBox textBox4;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.TextBox textBox3;
        private System.Windows.Forms.Button btn_ChipTest;
		private System.Windows.Forms.Button button2;
		private System.Windows.Forms.Button button3;
		private System.Windows.Forms.TabPage tabPage1;
		private System.Windows.Forms.FlowLayoutPanel flowLayoutPanel1;
		private System.Windows.Forms.Label label12;
		private System.Windows.Forms.Button RestartButton;
		private System.Windows.Forms.ComboBox SessionConfigBox;
		private System.Windows.Forms.TextBox PrinterMsgBox;
		private System.Windows.Forms.Button PrintTestCardButton;
		private System.Windows.Forms.ComboBox FeedCardBox;
		private System.Windows.Forms.Button FlipCardButton;
		private System.Windows.Forms.Button EjectCardButton;
		private System.Windows.Forms.Button FeedCardButton;
		private System.Windows.Forms.Button OpenSessionButton;
		private System.Windows.Forms.Button button4;
		private System.Windows.Forms.ComboBox comboBox3;
		private System.Windows.Forms.TextBox textBox6;
		private System.Windows.Forms.TextBox db_password;
		private System.Windows.Forms.Label label17;
		private System.Windows.Forms.Label db_user;
		private System.Windows.Forms.Label label15;
		private System.Windows.Forms.Label label14;
		private System.Windows.Forms.Button button5;
		private System.Windows.Forms.GroupBox groupBox1;
		private System.Windows.Forms.DataGridView dgv_Records;
		private System.Windows.Forms.Label label16;
		private System.Windows.Forms.ComboBox comboBox2;
        private System.Windows.Forms.RichTextBox richTextBox1;
    }
}

