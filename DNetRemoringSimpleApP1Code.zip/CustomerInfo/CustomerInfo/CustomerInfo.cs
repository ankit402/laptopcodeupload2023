using System;
using System.Text;
using System.IO ;
using System.Data.SqlClient;

namespace CustomerInfo
{
	public class CustomerLoader : System.MarshalByRefObject
	{
		private SqlConnection myConnection = null ; 
		private SqlDataReader myReader ;

		public CustomerLoader()
		{
			Console.WriteLine("New Customer Instance Created");
		}

		public void Init(string userid , string password)
		{
			try
			{
				string myConnectString = "user id="+userid+";password="+password+
					";Database=Northwind;Server=SKYWALKER;Connect Timeout=30";
				myConnection = new SqlConnection(myConnectString);
				myConnection.Open();

				if ( myConnection == null ) 
				{
					Console.WriteLine("OPEN NULL VALUE =====================");
					return ;
				}

			}
			catch(Exception es)
			{
				Console.WriteLine("[Error WITH DB CONNECT...] " + es.Message);
			}
		}

		public bool ExecuteSelectCommand(string selCommand)
		{
			try
			{
				Console.WriteLine("EXECUTING .. " + selCommand);
				SqlCommand myCommand = new SqlCommand(selCommand);
				if ( myConnection == null ) 
				{
					Console.WriteLine("NULL VALUE =====================");
					return false ;
				}

				myCommand.Connection = myConnection;
				myCommand.ExecuteNonQuery();
				myReader = myCommand.ExecuteReader();
				return true ;
			}
			catch ( Exception e ) 
			{
				return false ;
			}
		}

		public string GetRow()
		{
			if ( ! myReader.Read() ) 
			{
				myReader.Close();
				return "" ;
			}

			int nCol = myReader.FieldCount ;
			string outstr ="";

			object [] values = new Object[nCol];
			myReader.GetValues(values);
			for ( int i=0; i < values.Length ; i ++)
			{
				string coldata = values[i].ToString();
				coldata = coldata.TrimEnd();
				outstr +=  coldata + "," ;
			}
			return outstr;
		}

	}
}
